# DOGMA OS v2 — OpenClaw Integration Architecture

## Overview

DOGMA OS v2 replaces the hardcoded 20-agent system (which was just different system prompts sent to the same Claude API) with **real computer-executing agents** powered by OpenClaw Gateway.

**Before (v1):** DOGMA Dashboard → Claude API (different system prompts) → text responses only

**After (v2):** DOGMA Dashboard → OpenClaw Gateway (local) → agent executes on user's machine (shell, browser, files, canvas)

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    User's Machine                            │
│                                                              │
│  ┌──────────────────────┐     ┌───────────────────────────┐ │
│  │   DOGMA Control OS   │     │    OpenClaw Gateway       │ │
│  │   (Next.js :3000)    │────▶│    (ws://127.0.0.1:18789) │ │
│  │                      │     │                           │ │
│  │  ┌────────────────┐  │     │  ┌─────────────────────┐  │ │
│  │  │ Dashboard UI   │  │     │  │ Agent Runtime       │  │ │
│  │  │ (React)        │  │     │  │  • Shell (bash)     │  │ │
│  │  └───────┬────────┘  │     │  │  • Browser (CDP)    │  │ │
│  │          │            │     │  │  • File R/W         │  │ │
│  │  ┌───────▼────────┐  │     │  │  • Canvas (A2UI)    │  │ │
│  │  │ API Routes     │  │     │  │  • Network (HTTP)   │  │ │
│  │  │ /api/chat      │──┼────▶│  │  • Cron (heartbeat) │  │ │
│  │  │ /api/orchestrate│──┼────▶│  └─────────────────────┘  │ │
│  │  │ /api/sessions  │──┼────▶│                           │ │
│  │  └───────┬────────┘  │     │  ┌─────────────────────┐  │ │
│  │          │            │     │  │ Workspace           │  │ │
│  │  ┌───────▼────────┐  │     │  │  SOUL.md (identity) │  │ │
│  │  │ Supabase       │  │     │  │  AGENTS.md (rules)  │  │ │
│  │  │ (domain data)  │  │     │  │  .skills/ (modules) │  │ │
│  │  └────────────────┘  │     │  │  MEMORY.md (context) │  │ │
│  └──────────────────────┘     │  └─────────────────────┘  │ │
│                               └───────────────────────────┘ │
│                                          │                   │
│                                          ▼                   │
│                               ┌───────────────────┐         │
│                               │ Claude API         │         │
│                               │ (reasoning engine) │         │
│                               └───────────────────┘         │
└─────────────────────────────────────────────────────────────┘
```

## What Changed

### Removed
- `agents.ts` (old): 20 hardcoded agents with fake `OPENCLAW_REF` string in prompts
- `chat-route.ts` (old): Direct Anthropic API calls with tool simulation
- `orchestrate-route.ts` (old): Swarm orchestrator that chained API calls
- Fake tool definitions (generate_html_report, generate_csv, etc.)
- In-process file generation (storeFileLocally, buildHtmlReport)

### Added
- `src/lib/openclaw.ts` — **Gateway client** (WebSocket + REST, session management, tool invocation, streaming, fallback)
- `src/lib/agents.ts` — **OpenClaw-native agent definitions** (SOUL prompts, skill references, tool policies, computer access declarations)
- `src/app/api/chat/route.ts` — **Gateway-proxied chat** (routes messages through OpenClaw, falls back to direct API)
- `src/app/api/orchestrate/route.ts` — **Multi-agent workflows** (same stage/pipeline model, but agents execute on machine)
- `src/app/api/sessions/route.ts` — **Session management** (list sessions, get history from OpenClaw)
- `workspace/SOUL.md` — **Agent identity** (who DOGMA agents are)
- `workspace/.skills/` — **Modular skills** (dogma-context, report-generator)
- `workspace/AGENTS.md` — **Coding guidelines**
- `workspace/MEMORY.md` — **Persistent memory**
- `scripts/setup-openclaw.sh` — **One-command setup**

### Unchanged
- `src/lib/auth.ts` — Auth & RBAC (same)
- `src/lib/commands.ts` — Domain commands (same)
- `src/lib/services.ts` — MCP services (same)
- `src/app/api/dashboard/summary/route.ts` — Dashboard data (same)
- `src/app/api/entities/route.ts` — Entity CRUD (same)
- `src/app/api/artifacts/[name]/route.ts` — File serving (same)
- `src/app/api/commands/route.ts` — Command execution (same)
- `src/app/api/data/route.ts` — Backward compat (same)
- `src/app/api/migrate/route.ts` — Migration (same)
- SQL schema (001 + 002) — Database (same)
- Dashboard UI (page.tsx / dashboard-page.tsx) — Frontend (minor changes needed, see below)

---

## Agent Capabilities Matrix

| Agent | Shell | File R/W | Browser | Canvas | Network | Tool Policy |
|-------|-------|----------|---------|--------|---------|-------------|
| Planner | ✅ | ✅ R/W | ✅ | ✅ | ✅ | record |
| Architect | ✅ | ✅ R/W | ✅ | ✅ | ✅ | record |
| Researcher | ✅ | ✅ R/W | ✅ | ❌ | ✅ | record |
| Coder | ✅ | ✅ R/W | ✅ | ✅ | ✅ | record |
| Data Engineer | ✅ | ✅ R/W | ❌ | ❌ | ✅ | ask |
| Tester | ✅ | ✅ R/W | ✅ | ❌ | ✅ | record |
| Reviewer | ✅ | ✅ R only | ❌ | ❌ | ❌ | record |
| Security | ✅ | ✅ R only | ✅ | ❌ | ✅ | ask |
| Documenter | ✅ | ✅ R/W | ✅ | ✅ | ❌ | record |
| Coordinator | ✅ | ✅ R/W | ❌ | ✅ | ❌ | record |
| DevOps | ✅ | ✅ R/W | ❌ | ❌ | ✅ | ask |

**Tool Policies:**
- `record`: Agent can use tools freely, all actions are logged
- `ask`: Agent must request approval before executing sensitive tools
- `ignore`: Agent cannot use tools (read-only mode)

---

## Fallback Behavior

When the OpenClaw gateway is not running:

1. Chat route detects gateway is unreachable (`ECONNREFUSED`)
2. Falls back to direct Anthropic API call (same as v1 behavior)
3. **No computer access** in fallback mode — agents can only reason and generate text
4. Dashboard shows gateway status indicator: 🔴 Offline / 🟢 Connected

This means DOGMA OS works with or without OpenClaw installed. Users get the full experience (computer-executing agents) when gateway is running, and a degraded-but-functional experience when it's not.

---

## Dashboard Changes Required

The frontend (`dashboard-page.tsx`) needs minor updates to show:

1. **Gateway status indicator** in the header (🟢/🔴)
2. **Tool execution log** in the chat panel (shows what commands agents ran)
3. **Computer access badges** on agent cards (shell, browser, files icons)
4. **Session persistence** — resume previous conversations
5. **Approval queue** — approve/deny pending tool executions

These are additive changes to the existing 2400-line dashboard. The modularization plan in `MODULARIZATION_PLAN.md` should be executed in parallel to make these changes sustainable.

---

## Setup Flow

```bash
# 1. Install OpenClaw
sudo npm i -g openclaw@latest

# 2. Run setup script (from DOGMA project root)
bash scripts/setup-openclaw.sh .

# 3. Start OpenClaw gateway
openclaw gateway run

# 4. Start DOGMA OS
npm run dev

# 5. Open dashboard
open http://localhost:3000/dashboard
```

---

## Security Model

| Layer | Mechanism |
|-------|-----------|
| Gateway auth | Shared-token or password (configurable) |
| Agent sandboxing | Tool allowlists/denylists per agent |
| Approval flow | `ask` policy requires human approval for sensitive tools |
| Audit trail | All tool executions logged in Supabase audit_events |
| RBAC | Existing role-based permissions (founder_admin, ops_admin, etc.) |
| Network | Gateway binds to loopback (127.0.0.1) by default |

---

## Migration Checklist

- [ ] Run `bash scripts/setup-openclaw.sh .` from project root
- [ ] Add OpenClaw env vars to `.env.local`
- [ ] Install OpenClaw: `sudo npm i -g openclaw@latest`
- [ ] Configure API key: `openclaw config set provider.anthropic.apiKey sk-ant-...`
- [ ] Start gateway: `openclaw gateway run`
- [ ] Test: `curl http://127.0.0.1:18789/api/status`
- [ ] Restart DOGMA OS: `npm run dev`
- [ ] Verify gateway indicator shows 🟢 in dashboard
- [ ] Test agent chat — should see tool executions in response
- [ ] Run a workflow — verify multi-agent pipeline works
