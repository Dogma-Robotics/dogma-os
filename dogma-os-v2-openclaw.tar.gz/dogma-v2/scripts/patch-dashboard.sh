#!/bin/bash
# ══════════════════════════════════════════════════════════════════
# DOGMA OS v2 — Apply Dashboard Patches
# 
# Applies OpenClaw integration patches to dashboard-page.tsx
# Run from project root: bash scripts/patch-dashboard.sh
# ══════════════════════════════════════════════════════════════════
set -e

DASH="src/app/dashboard/page.tsx"

if [ ! -f "$DASH" ]; then
  echo "❌ Cannot find $DASH — run from project root"
  exit 1
fi

echo "🔧 Patching dashboard for OpenClaw integration..."

# Backup
cp "$DASH" "$DASH.bak"
echo "  📦 Backed up to $DASH.bak"

# ── PATCH 1: Replace AGENTS array ──
# Use Python for reliable multi-line replacements
python3 << 'PYEOF'
import re

with open("src/app/dashboard/page.tsx", "r") as f:
    content = f.read()

# Patch 1: Replace AGENTS array
old_agents = r'var AGENTS=\[\s*// ── CORE AGENTS.*?\];\s*var AGENT_CATEGORIES=\[.*?\];'
new_agents = '''var AGENTS=[
  // ── STRATEGY ──
  {id:"planner",name:"Planner",icon:"📐",color:C.gold,cat:"strategy",desc:"Creates phased implementation blueprints",access:{shell:true,files:true,browser:true,canvas:true}},
  {id:"architect",name:"Architect",icon:"🏗️",color:C.b,cat:"strategy",desc:"Technology decisions and system boundaries",access:{shell:true,files:true,browser:true,canvas:true}},
  {id:"researcher",name:"Researcher",icon:"🔍",color:C.c,cat:"strategy",desc:"Deep research with real browser access",access:{shell:true,files:true,browser:true,canvas:false}},
  // ── IMPLEMENTATION ──
  {id:"coder",name:"Coder",icon:"💻",color:C.g,cat:"implementation",desc:"Full-stack dev with shell + file + browser access",access:{shell:true,files:true,browser:true,canvas:true}},
  {id:"data-engineer",name:"Data Eng",icon:"🗄️",color:C.c,cat:"implementation",desc:"Schemas, migrations, queries — can run psql",access:{shell:true,files:true,browser:false,canvas:false}},
  // ── QUALITY ──
  {id:"tester",name:"Tester",icon:"🧪",color:C.r,cat:"quality",desc:"Writes and runs tests on your machine",access:{shell:true,files:true,browser:true,canvas:false}},
  {id:"reviewer",name:"Reviewer",icon:"👁️",color:C.a,cat:"quality",desc:"Code review with codebase access (read-only)",access:{shell:true,files:false,browser:false,canvas:false}},
  {id:"security-scanner",name:"Security",icon:"🔒",color:C.r,cat:"quality",desc:"Security audit with scanning tools",access:{shell:true,files:false,browser:true,canvas:false}},
  // ── OPERATIONS ──
  {id:"documenter",name:"Documenter",icon:"📄",color:C.b,cat:"operations",desc:"Generates polished reports and docs as real files",access:{shell:true,files:true,browser:true,canvas:true}},
  {id:"coordinator",name:"Coordinator",icon:"🎯",color:C.gold,cat:"operations",desc:"Synthesizes multi-agent outputs",access:{shell:true,files:true,browser:false,canvas:true}},
  {id:"devops",name:"DevOps",icon:"🚀",color:C.g,cat:"operations",desc:"CI/CD, deployment, Docker, infrastructure",access:{shell:true,files:true,browser:false,canvas:false}},
];
var AGENT_CATEGORIES=[
  {id:"strategy",label:"Strategy",color:C.gold},
  {id:"implementation",label:"Implementation",color:C.g},
  {id:"quality",label:"Quality",color:C.r},
  {id:"operations",label:"Operations",color:C.b},
];'''

content = re.sub(old_agents, new_agents, content, flags=re.DOTALL)

# Patch 2: Add gateway state after _mode useState
gateway_state = '''var _gateway=useState({connected:false,version:'',model:''}),gateway=_gateway[0],setGateway=_gateway[1];
var _toolLog=useState([]),toolLog=_toolLog[0],setToolLog=_toolLog[1];
var _sessionId=useState(null),sessionId=_sessionId[0],setSessionId=_sessionId[1];
var _mode=useState("chat"),mode=_mode[0],setMode=_mode[1];'''

content = content.replace(
    'var _mode=useState("chat"),mode=_mode[0],setMode=_mode[1];',
    gateway_state
)

# Patch 3: Replace SWARM_WORKFLOWS
old_workflows = r'var SWARM_WORKFLOWS=\[.*?\];'
new_workflows = '''var SWARM_WORKFLOWS=[
  {id:"build-feature",name:"Build Feature",desc:"Research → Plan → Code → Test → Review → Document",agents:6,icon:"⚡"},
  {id:"code-review",name:"Code Review",desc:"Security + Quality + Tests → Synthesize",agents:4,icon:"👁️"},
  {id:"research-sprint",name:"Research Sprint",desc:"Research → Architect → Plan → Document",agents:4,icon:"🔍"},
  {id:"deploy",name:"Deploy",desc:"Build → Test → Security → Deploy",agents:4,icon:"🚀"},
  {id:"incident-response",name:"Incident Response",desc:"Diagnose → Fix → Test → Post-mortem",agents:6,icon:"🚨"},
];'''

content = re.sub(old_workflows, new_workflows, content, count=1, flags=re.DOTALL)

# Patch 4: Add sessionId to sendAgent fetch body
content = content.replace(
    'body:JSON.stringify({message:userTxt,agentId:agentId,dataContext:dataSnap,mode:approvalMode})',
    'body:JSON.stringify({message:userTxt,agentId:agentId,sessionId:sessionId,dataContext:dataSnap,mode:approvalMode})'
)

# Patch 5: Add gateway status update in chat response handler
# Find "if(data.mcpConnected" and prepend gateway update
content = content.replace(
    'if(data.mcpConnected&&data.mcpConnected.length>0)setMcpConn(data.mcpConnected);',
    '''if(data.gateway)setGateway(data.gateway);
    if(data.sessionId)setSessionId(data.sessionId);
    if(data.mcpConnected&&data.mcpConnected.length>0)setMcpConn(data.mcpConnected);'''
)

# Patch 6: Add tool calls to message object
# Find the setMsgs call that creates AI messages and add toolCalls
content = content.replace(
    'n[agentId]=(n[agentId]||[]).concat([{role:"ai",text:text,files:files,mutations:mutations}]);',
    '''var toolCalls=(data.toolCalls||[]).map(function(tc){return{tool:tc.tool,input:typeof tc.input==="string"?tc.input:JSON.stringify(tc.input||{}).slice(0,100),output:(tc.output||"").slice(0,200),status:tc.status||"executed"};});
    if(toolCalls.length>0)setToolLog(function(prev){return toolCalls.concat(prev).slice(0,50);});
    n[agentId]=(n[agentId]||[]).concat([{role:"ai",text:text,files:files,toolCalls:toolCalls,mutations:mutations}]);'''
)

with open("src/app/dashboard/page.tsx", "w") as f:
    f.write(content)

print("  ✅ Applied 6 patches to dashboard")
PYEOF

echo ""
echo "  ✅ Dashboard patched for OpenClaw integration"
echo ""
echo "  Changes applied:"
echo "  • 11 agents with computer access declarations"
echo "  • 4 agent categories (Strategy, Implementation, Quality, Operations)"
echo "  • Gateway connection state (auto-polls every 30s)"
echo "  • Session persistence across messages"  
echo "  • Tool execution tracking in messages"
echo "  • 5 OpenClaw-native workflows"
echo ""
echo "  Manual patches still needed (see DASHBOARD_PATCHES.js):"
echo "  • Gateway status indicator in header bar"
echo "  • Computer access badges on agent cards"
echo "  • Tools panel tab and body"
echo "  • Agent info panel with LIVE/API ONLY badge"
echo ""
echo "  These manual patches are UI-only additions that depend on"
echo "  your specific layout. Copy the JSX from DASHBOARD_PATCHES.js"
echo "  into the right spots."
