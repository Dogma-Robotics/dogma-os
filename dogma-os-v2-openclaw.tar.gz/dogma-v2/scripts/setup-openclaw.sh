#!/bin/bash
# ══════════════════════════════════════════════════════════════════
# DOGMA OS v2 — OpenClaw Integration Setup
# 
# This script:
# 1. Checks/installs OpenClaw
# 2. Creates the DOGMA workspace with SOUL.md + skills
# 3. Configures agents with proper tool policies
# 4. Sets up the gateway connection
# 5. Copies v2 source files into the DOGMA OS project
#
# Usage: bash scripts/setup-openclaw.sh [dogma-os-project-path]
# ══════════════════════════════════════════════════════════════════
set -e

DOGMA_PROJECT="${1:-.}"  # Default to current directory
OPENCLAW_WORKSPACE="$HOME/.openclaw/workspaces/dogma"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
V2_DIR="$(dirname "$SCRIPT_DIR")"

echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║  🤖 DOGMA OS v2 — OpenClaw Integration      ║"
echo "  ╚══════════════════════════════════════════════╝"
echo ""

# ── 1. Check for OpenClaw ──

echo "① Checking OpenClaw installation..."

if command -v openclaw &>/dev/null; then
  CLAW_VERSION=$(openclaw --version 2>/dev/null || echo "unknown")
  echo "  ✅ OpenClaw found: $CLAW_VERSION"
else
  echo "  ⚠️  OpenClaw not found. Installing..."
  echo ""
  echo "  Choose installation method:"
  echo "    a) npm (recommended): sudo npm i -g openclaw@latest"
  echo "    b) Onboard wizard:    npx openclaw onboard"
  echo ""
  read -p "  Install now with npm? [Y/n] " -n 1 -r
  echo ""
  if [[ ! $REPLY =~ ^[Nn]$ ]]; then
    sudo npm i -g openclaw@latest
    echo "  ✅ OpenClaw installed"
  else
    echo "  ⏭️  Skipping install. Run 'sudo npm i -g openclaw@latest' manually."
    echo "     Then re-run this script."
    exit 1
  fi
fi

# ── 2. Create DOGMA Workspace ──

echo ""
echo "② Setting up DOGMA workspace at $OPENCLAW_WORKSPACE..."

mkdir -p "$OPENCLAW_WORKSPACE"
mkdir -p "$OPENCLAW_WORKSPACE/.skills/dogma-context"
mkdir -p "$OPENCLAW_WORKSPACE/.skills/report-generator"
mkdir -p "$OPENCLAW_WORKSPACE/agents"

# Copy SOUL.md
if [ -f "$V2_DIR/workspace/SOUL.md" ]; then
  cp "$V2_DIR/workspace/SOUL.md" "$OPENCLAW_WORKSPACE/SOUL.md"
  echo "  ✅ SOUL.md (agent identity)"
fi

# Copy skills
if [ -d "$V2_DIR/workspace/.skills" ]; then
  cp -r "$V2_DIR/workspace/.skills/"* "$OPENCLAW_WORKSPACE/.skills/"
  echo "  ✅ Skills: dogma-context, report-generator"
fi

# Create AGENTS.md (coding guidelines)
cat > "$OPENCLAW_WORKSPACE/AGENTS.md" << 'AGENTS_EOF'
# DOGMA Robotics — Agent Guidelines

## Code Standards
- TypeScript strict mode, no `any` types
- Immutable data structures preferred
- Pure functions where possible
- React: functional components with hooks only
- CSS: Tailwind or inline styles (no CSS modules in dashboard)
- Testing: Vitest for unit, Playwright for e2e

## Project Structure
```
src/
  app/
    api/          # Next.js API routes
    dashboard/    # Main dashboard page
  lib/
    openclaw.ts   # OpenClaw gateway client
    agents.ts     # Agent definitions
    auth.ts       # Auth & RBAC
    commands.ts   # Domain commands
    services.ts   # MCP services
  components/     # React components (when modularized)
```

## Database
- Supabase (PostgreSQL) with organization-scoped RLS
- All queries must filter by `organization_id`
- Migrations go in `supabase/migrations/`

## Git
- Conventional commits: feat:, fix:, refactor:, docs:
- Never commit secrets or .env files
- Rebase onto main, no merge commits
AGENTS_EOF
echo "  ✅ AGENTS.md (coding guidelines)"

# Create USER.md (user preferences)
cat > "$OPENCLAW_WORKSPACE/USER.md" << 'USER_EOF'
# User Preferences

- Language: English for code, Spanish for casual conversation
- Reports: DOGMA branding (navy/gold palette)
- Communication: Technical, precise, specific numbers
- When in doubt, show the work — run commands and show output
- Flag risks explicitly with severity levels
USER_EOF
echo "  ✅ USER.md (user preferences)"

# Create MEMORY.md (persistent context)
cat > "$OPENCLAW_WORKSPACE/MEMORY.md" << 'MEMORY_EOF'
# DOGMA Agent Memory

## Active Context
- Project: DOGMA Control OS (Next.js + ROS 2 + Supabase)
- Current focus: v2 restructure with OpenClaw integration
- Database: Supabase with normalized schema (see 001_full_schema.sql)
- Dashboard: 2400-line monolith at src/app/dashboard/page.tsx — needs modularization

## Key Decisions
- OpenClaw gateway provides computer access (shell, browser, files)
- Fallback to direct Anthropic API when gateway is down (no computer access)
- All agent actions are audited via activity_log and audit_events tables
- Tool policy: 'ask' for sensitive agents, 'record' for standard agents
MEMORY_EOF
echo "  ✅ MEMORY.md (persistent memory)"

# ── 3. Configure OpenClaw ──

echo ""
echo "③ Configuring OpenClaw gateway..."

# Set DOGMA as the active workspace
openclaw config set workspace.default "$OPENCLAW_WORKSPACE" 2>/dev/null || true
openclaw config set gateway.mode local 2>/dev/null || true
openclaw config set gateway.port 18789 2>/dev/null || true

# Configure model (default to Claude Sonnet)
openclaw config set model.default "claude-sonnet-4-20250514" 2>/dev/null || true
openclaw config set model.fallback "claude-haiku-4-5-20251001" 2>/dev/null || true

echo "  ✅ Gateway configured (port 18789, local mode)"

# ── 4. Copy v2 source files ──

echo ""
echo "④ Installing DOGMA OS v2 files..."

if [ -d "$DOGMA_PROJECT/src" ]; then
  # Backup existing files
  BACKUP_DIR="$DOGMA_PROJECT/.dogma-backup-$(date +%Y%m%d%H%M%S)"
  mkdir -p "$BACKUP_DIR"
  
  for f in src/lib/agents.ts src/lib/openclaw.ts src/app/api/chat/route.ts src/app/api/orchestrate/route.ts src/app/api/sessions/route.ts; do
    if [ -f "$DOGMA_PROJECT/$f" ]; then
      mkdir -p "$BACKUP_DIR/$(dirname $f)"
      cp "$DOGMA_PROJECT/$f" "$BACKUP_DIR/$f"
    fi
  done
  echo "  📦 Backed up existing files to $BACKUP_DIR"
  
  # Copy new files
  mkdir -p "$DOGMA_PROJECT/src/lib"
  mkdir -p "$DOGMA_PROJECT/src/app/api/chat"
  mkdir -p "$DOGMA_PROJECT/src/app/api/orchestrate"
  mkdir -p "$DOGMA_PROJECT/src/app/api/sessions"
  
  cp "$V2_DIR/src/lib/openclaw.ts" "$DOGMA_PROJECT/src/lib/openclaw.ts"
  echo "  ✅ src/lib/openclaw.ts (gateway client)"
  
  cp "$V2_DIR/src/lib/agents.ts" "$DOGMA_PROJECT/src/lib/agents.ts"
  echo "  ✅ src/lib/agents.ts (OpenClaw-native agents)"
  
  cp "$V2_DIR/src/app/api/chat/route.ts" "$DOGMA_PROJECT/src/app/api/chat/route.ts"
  echo "  ✅ src/app/api/chat/route.ts (gateway-proxied)"
  
  cp "$V2_DIR/src/app/api/orchestrate/route.ts" "$DOGMA_PROJECT/src/app/api/orchestrate/route.ts"
  echo "  ✅ src/app/api/orchestrate/route.ts (multi-agent workflows)"
  
  cp "$V2_DIR/src/app/api/sessions/route.ts" "$DOGMA_PROJECT/src/app/api/sessions/route.ts"
  echo "  ✅ src/app/api/sessions/route.ts (session management)"
else
  echo "  ⚠️  Cannot find $DOGMA_PROJECT/src — skipping file copy."
  echo "     Run this script from your DOGMA OS project root, or pass the path as argument."
fi

# ── 5. Environment variables ──

echo ""
echo "⑤ Environment setup..."

ENV_FILE="$DOGMA_PROJECT/.env.local"
if [ -f "$ENV_FILE" ]; then
  # Add OpenClaw vars if not present
  grep -q "OPENCLAW_GATEWAY" "$ENV_FILE" 2>/dev/null || {
    echo "" >> "$ENV_FILE"
    echo "# OpenClaw Gateway" >> "$ENV_FILE"
    echo "OPENCLAW_GATEWAY_WS=ws://127.0.0.1:18789" >> "$ENV_FILE"
    echo "OPENCLAW_GATEWAY_HTTP=http://127.0.0.1:18789" >> "$ENV_FILE"
    echo "OPENCLAW_WORKSPACE=$OPENCLAW_WORKSPACE" >> "$ENV_FILE"
    echo "OPENCLAW_MODEL=claude-sonnet-4-20250514" >> "$ENV_FILE"
    echo "# OPENCLAW_API_TOKEN=  # Set if using shared-token auth" >> "$ENV_FILE"
    echo "  ✅ Added OpenClaw env vars to .env.local"
  }
else
  echo "  ⚠️  No .env.local found. Create one with:"
  echo "     OPENCLAW_GATEWAY_WS=ws://127.0.0.1:18789"
  echo "     OPENCLAW_GATEWAY_HTTP=http://127.0.0.1:18789"
  echo "     OPENCLAW_WORKSPACE=$OPENCLAW_WORKSPACE"
fi

# ── Done ──

echo ""
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║  ✅ DOGMA OS v2 Setup Complete               ║"
echo "  ╚══════════════════════════════════════════════╝"
echo ""
echo "  What changed:"
echo "  • Agents now route through OpenClaw gateway (ws://127.0.0.1:18789)"
echo "  • Agents have REAL computer access: shell, browser, files, canvas"
echo "  • SOUL.md + SKILL.md files define agent identity (version-controllable)"
echo "  • Sessions persist in OpenClaw (JSONL transcripts + MEMORY.md)"
echo "  • Fallback to direct Anthropic API when gateway is offline"
echo ""
echo "  To start:"
echo "    1. Start OpenClaw gateway:"
echo "       openclaw gateway run"
echo ""
echo "    2. Start DOGMA OS:"
echo "       cd $DOGMA_PROJECT && npm run dev"
echo ""
echo "    3. Open dashboard:"
echo "       http://localhost:3000/dashboard"
echo ""
echo "  The gateway status indicator in the dashboard will show 🟢 when connected."
echo ""
