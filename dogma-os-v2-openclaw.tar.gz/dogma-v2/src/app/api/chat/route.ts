// ══════════════════════════════════════════════════════════════════
// DOGMA OS v2 — Chat Route (OpenClaw Gateway Integration)
//
// Flow: DOGMA Dashboard → this route → OpenClaw Gateway → user's machine
// Fallback: if gateway is down, falls back to direct Anthropic API
// ══════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server'
import { resolveSession, canUseAgent, getAgentTier, logActivity } from '@/lib/auth'
import { sendMessage, checkGateway, listSessions, type SendMessageResult } from '@/lib/openclaw'
import { AGENTS } from '@/lib/agents'
import { getSupabase } from '@/lib/auth'

// ── POST: Send message to agent via OpenClaw ──

export async function POST(req: NextRequest) {
  try {
    // 1. Auth
    const auth = await resolveSession()
    if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status })
    const ctx = auth.ctx

    const { message, agentId = 'coder', sessionId, dataContext } = await req.json()
    if (!message) return NextResponse.json({ error: 'Missing message' }, { status: 400 })

    // 2. Agent validation
    const agent = AGENTS[agentId]
    if (!agent) {
      return NextResponse.json({
        text: `Unknown agent: ${agentId}`,
        files: [], toolCalls: [], gateway: { connected: false },
      })
    }

    if (!canUseAgent(ctx, agentId)) {
      return NextResponse.json({
        text: `❌ Permission denied: your role (${ctx.role}) cannot use agent ${agent.name}`,
        files: [], toolCalls: [], gateway: { connected: false },
      })
    }

    // 3. Build DOGMA context (domain data snapshot)
    const domainContext = dataContext || await buildDomainContext(ctx.organizationId)

    // 4. Check gateway status
    const gwStatus = await checkGateway()

    // 5. Send message through OpenClaw gateway (or fallback)
    const startTime = Date.now()
    let result: SendMessageResult

    if (gwStatus.running) {
      result = await sendMessage(agentId, message, {
        sessionId,
        context: domainContext,
        skills: agent.skills,
        toolPolicy: agent.toolPolicy,
        approvedTools: agent.allowedTools,
      })
    } else {
      // Fallback to direct API (no computer access)
      result = await sendMessage(agentId, message, {
        sessionId,
        context: domainContext,
        skills: agent.skills,
      })
    }

    const duration = Date.now() - startTime

    // 6. Log activity
    await logActivity(ctx, 'agent_chat', 'agent', agentId, {
      agent: agentId,
      tier: getAgentTier(agentId),
      message: message.slice(0, 100),
      files: result.files.length,
      toolCalls: result.toolCalls.length,
      duration_ms: duration,
      gateway: gwStatus.running,
      model: result.model,
    })

    // 7. Response
    return NextResponse.json({
      text: result.text,
      files: result.files,
      toolCalls: result.toolCalls,
      sessionId: result.sessionId,
      tokenUsage: result.tokenUsage,
      agent: {
        id: agentId,
        name: agent.name,
        icon: agent.icon,
        tier: getAgentTier(agentId),
        computerAccess: agent.computerAccess,
      },
      gateway: {
        connected: gwStatus.running,
        version: gwStatus.version,
        model: result.model,
      },
      user: { name: ctx.name, role: ctx.role },
    })
  } catch (e: any) {
    console.error('[CHAT ERROR]', e.message)
    return NextResponse.json({
      text: `❌ ${e.message}`,
      files: [], toolCalls: [],
      gateway: { connected: false },
    })
  }
}

// ── GET: Agent list + gateway status ──

export async function GET() {
  const auth = await resolveSession()
  if (!auth.ok) return NextResponse.json({ error: auth.error })
  const ctx = auth.ctx

  const gwStatus = await checkGateway()

  const agents = Object.entries(AGENTS).map(([id, a]) => ({
    id,
    name: a.name,
    icon: a.icon,
    color: a.color,
    category: a.category,
    description: a.description,
    tier: getAgentTier(id),
    canUse: canUseAgent(ctx, id),
    computerAccess: a.computerAccess,
    skills: a.skills,
    toolPolicy: a.toolPolicy,
  }))

  // Get active sessions from OpenClaw
  const sessions = gwStatus.running ? await listSessions() : []

  return NextResponse.json({
    agents,
    gateway: {
      connected: gwStatus.running,
      version: gwStatus.version,
      activeAgents: gwStatus.activeAgents,
      activeSessions: gwStatus.activeSessions,
      model: gwStatus.model,
    },
    sessions,
    user: { name: ctx.name, role: ctx.role },
  })
}

// ── Build domain context from Supabase ──

async function buildDomainContext(orgId: string): Promise<string> {
  const sb = getSupabase()
  if (!sb) return '(No database connected)'

  try {
    const [
      { data: subsystems },
      { data: tasks },
      { data: pilots },
      { data: incidents },
      { data: milestones },
      { data: finance },
    ] = await Promise.all([
      sb.from('subsystems').select('name, maturity_level, status, version').eq('organization_id', orgId).order('created_at'),
      sb.from('tasks').select('title, status, priority, workspace').eq('organization_id', orgId).neq('status', 'done').order('priority', { ascending: false }).limit(20),
      sb.from('pilots').select('company_name, stage, viability_score').eq('organization_id', orgId).order('viability_score', { ascending: false }).limit(10),
      sb.from('incidents').select('title, severity, status').eq('organization_id', orgId).eq('status', 'open').limit(10),
      sb.from('milestones').select('title, progress, target_date, risk_level').eq('organization_id', orgId).order('target_date').limit(10),
      sb.from('finance_snapshots').select('burn_rate, cash_on_hand, runway_months').eq('organization_id', orgId).order('month', { ascending: false }).limit(1),
    ])

    const parts: string[] = ['DOGMA Robotics — Current State\n']

    if (subsystems?.length) {
      parts.push('SUBSYSTEMS:')
      for (const s of subsystems) {
        parts.push(`  ${s.name}: maturity ${s.maturity_level}%, status ${s.status}, ${s.version}`)
      }
    }

    if (tasks?.length) {
      parts.push('\nOPEN TASKS:')
      for (const t of tasks) {
        parts.push(`  [${t.priority}] ${t.title} (${t.status}) — ${t.workspace}`)
      }
    }

    if (pilots?.length) {
      parts.push('\nPILOT PIPELINE:')
      for (const p of pilots) {
        parts.push(`  ${p.company_name}: stage ${p.stage}, viability ${p.viability_score}%`)
      }
    }

    if (incidents?.length) {
      parts.push('\nOPEN INCIDENTS:')
      for (const i of incidents) {
        parts.push(`  [${i.severity}] ${i.title} (${i.status})`)
      }
    }

    if (milestones?.length) {
      parts.push('\nMILESTONES:')
      for (const m of milestones) {
        parts.push(`  ${m.title}: ${m.progress}% (target: ${m.target_date}, risk: ${m.risk_level})`)
      }
    }

    if (finance?.[0]) {
      const f = finance[0]
      parts.push(`\nFINANCE: Burn $${f.burn_rate}/mo, Cash $${f.cash_on_hand}, Runway ${f.runway_months}mo`)
    }

    return parts.join('\n')
  } catch {
    return '(Error loading domain context)'
  }
}
