// GET /api/sessions — List OpenClaw sessions and gateway status
import { NextRequest, NextResponse } from 'next/server'
import { resolveSession } from '@/lib/auth'
import { checkGateway, listSessions, getSessionHistory } from '@/lib/openclaw'

export async function GET(req: NextRequest) {
  try {
    const auth = await resolveSession()
    if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status })

    const url = new URL(req.url)
    const sessionId = url.searchParams.get('id')
    const agentId = url.searchParams.get('agent')

    // If requesting specific session history
    if (sessionId) {
      const history = await getSessionHistory(sessionId)
      return NextResponse.json({ sessionId, messages: history })
    }

    // Otherwise return gateway status + session list
    const [gwStatus, sessions] = await Promise.all([
      checkGateway(),
      listSessions(agentId || undefined),
    ])

    return NextResponse.json({
      gateway: {
        connected: gwStatus.running,
        version: gwStatus.version,
        uptime: gwStatus.uptime,
        activeAgents: gwStatus.activeAgents,
        activeSessions: gwStatus.activeSessions,
        model: gwStatus.model,
        channels: gwStatus.channels,
      },
      sessions,
    })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
