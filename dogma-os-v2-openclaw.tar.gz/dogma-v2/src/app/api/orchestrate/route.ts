// ══════════════════════════════════════════════════════════════════
// DOGMA OS v2 — Orchestrate Route (Multi-Agent via OpenClaw)
//
// Runs workflow templates: each stage sends messages to OpenClaw agents
// that execute on the user's machine. Previous agent outputs are
// chained as context to the next stage.
// ══════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server'
import { resolveSession, hasPermission, logActivity, type SessionContext } from '@/lib/auth'
import { sendMessage, checkGateway, type SendMessageResult } from '@/lib/openclaw'
import { AGENTS, WORKFLOWS, getAgentList, getWorkflowList } from '@/lib/agents'
import { getSupabase } from '@/lib/auth'

// ── Role-based limits ──

const SWARM_LIMITS: Record<string, { maxAgents: number; maxStages: number }> = {
  founder_admin:      { maxAgents: 20, maxStages: 10 },
  ops_admin:          { maxAgents: 12, maxStages: 8 },
  engineer:           { maxAgents: 6,  maxStages: 5 },
  finance:            { maxAgents: 3,  maxStages: 3 },
  advisor_readonly:   { maxAgents: 0,  maxStages: 0 },
  contractor_limited: { maxAgents: 0,  maxStages: 0 },
}

// ── POST: Run a workflow or single agent task ──

export async function POST(req: NextRequest) {
  try {
    const auth = await resolveSession()
    if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status })
    const ctx = auth.ctx

    if (!hasPermission(ctx, 'agent:swarm.basic') && !hasPermission(ctx, 'agent:*')) {
      return NextResponse.json({ error: 'Permission denied: swarm access required' }, { status: 403 })
    }

    const { workflow, agent, objective, dataContext, mode = 'advisory' } = await req.json()
    if (!objective) return NextResponse.json({ error: 'Missing objective' }, { status: 400 })

    const limits = SWARM_LIMITS[ctx.role] || { maxAgents: 0, maxStages: 0 }
    if (limits.maxAgents === 0) {
      return NextResponse.json({ error: 'Your role does not have swarm access' }, { status: 403 })
    }

    // Build domain context
    const domainContext = dataContext || await buildDomainContext(ctx.organizationId)

    // Check gateway
    const gwStatus = await checkGateway()

    // ── Single agent mode ──
    if (agent) {
      const agentDef = AGENTS[agent]
      if (!agentDef) return NextResponse.json({ error: `Unknown agent: ${agent}` })

      const result = await callAgent(ctx, agent, objective, domainContext, '', gwStatus.running, mode)

      return NextResponse.json({
        type: 'single',
        agent: { id: agent, name: agentDef.name, icon: agentDef.icon, color: agentDef.color },
        output: result.text,
        files: result.files,
        toolCalls: result.toolCalls,
        mode,
        gateway: { connected: gwStatus.running },
      })
    }

    // ── Multi-agent workflow ──
    const wf = WORKFLOWS[workflow]
    if (!wf) {
      return NextResponse.json({
        error: 'Unknown workflow',
        available: Object.keys(WORKFLOWS),
      })
    }

    const totalAgents = wf.stages.reduce((a, s) => a + s.agents.length, 0)
    if (totalAgents > limits.maxAgents) {
      return NextResponse.json({
        error: `Workflow needs ${totalAgents} agents but your role allows max ${limits.maxAgents}`,
      })
    }

    console.log(`🐝 SWARM [${mode}]: ${wf.name} | ${objective?.slice(0, 60)} | by ${ctx.name} (${ctx.role}) | gateway: ${gwStatus.running}`)

    const startTime = Date.now()
    const stageResults: StageResult[] = []
    const allFiles: any[] = []
    const allToolCalls: any[] = []
    let accumulated = ''

    // Execute stages
    for (let i = 0; i < wf.stages.length; i++) {
      const stage = wf.stages[i]
      console.log(`  Stage ${i + 1}/${wf.stages.length}: ${stage.name} [${stage.strategy}]`)

      const agentOutputs: AgentOutput[] = []

      if (stage.strategy === 'parallel') {
        // Run all agents in this stage simultaneously
        const promises = stage.agents.map(async (agentId) => {
          const task = `[${wf.name} → ${stage.name}] ${objective}`
          const result = await callAgent(ctx, agentId, task, domainContext, accumulated, gwStatus.running, mode)
          return { agentId, result }
        })

        const results = await Promise.all(promises)
        for (const { agentId, result } of results) {
          const def = AGENTS[agentId]
          agentOutputs.push({
            id: agentId,
            name: def?.name || agentId,
            icon: def?.icon || '🤖',
            color: def?.color || '#888',
            output: result.text,
            files: result.files,
            toolCalls: result.toolCalls,
          })
          allFiles.push(...result.files)
          allToolCalls.push(...result.toolCalls)
        }
      } else {
        // Sequential: each agent gets previous agent's output as context
        let chain = accumulated
        for (const agentId of stage.agents) {
          const task = `[${wf.name} → ${stage.name}] ${objective}`
          const result = await callAgent(ctx, agentId, task, domainContext, chain, gwStatus.running, mode)
          const def = AGENTS[agentId]
          agentOutputs.push({
            id: agentId,
            name: def?.name || agentId,
            icon: def?.icon || '🤖',
            color: def?.color || '#888',
            output: result.text,
            files: result.files,
            toolCalls: result.toolCalls,
          })
          allFiles.push(...result.files)
          allToolCalls.push(...result.toolCalls)
          chain += `\n\n### ${def?.name || agentId}:\n${result.text}`
        }
      }

      // Accumulate stage output for next stage
      const stageText = agentOutputs.map(a => `### ${a.name}:\n${a.output}`).join('\n\n')
      accumulated += `\n\n## STAGE: ${stage.name}\n${stageText}`

      stageResults.push({
        stage: i + 1,
        name: stage.name,
        strategy: stage.strategy,
        description: stage.description,
        agents: agentOutputs,
      })
    }

    // Final synthesis by coordinator
    const summary = await callAgent(
      ctx, 'coordinator',
      'Synthesize all agent outputs into a 5-7 bullet executive summary. Key decisions, risks, next actions.',
      domainContext, accumulated, gwStatus.running, mode
    )
    allFiles.push(...summary.files)

    const duration = Date.now() - startTime

    // Log
    await logActivity(ctx, 'swarm_run', 'workflow', workflow, {
      workflow, mode, objective: objective?.slice(0, 100),
      stages: stageResults.length, files: allFiles.length,
      toolCalls: allToolCalls.length, duration_ms: duration,
      gateway: gwStatus.running,
    })

    return NextResponse.json({
      type: 'swarm',
      workflow: wf.name,
      topology: wf.topology,
      objective,
      mode,
      stages: stageResults,
      summary: summary.text,
      files: allFiles,
      toolCalls: allToolCalls,
      totalAgents: stageResults.reduce((a, s) => a + s.agents.length, 0),
      totalStages: stageResults.length,
      duration_ms: duration,
      gateway: { connected: gwStatus.running, version: gwStatus.version },
      user: { name: ctx.name, role: ctx.role },
    })
  } catch (e: any) {
    console.error('[SWARM ERROR]', e.message)
    return NextResponse.json({ error: e.message })
  }
}

// ── GET: List available agents and workflows ──

export async function GET() {
  const gwStatus = await checkGateway()
  return NextResponse.json({
    agents: getAgentList(),
    workflows: getWorkflowList(),
    gateway: {
      connected: gwStatus.running,
      version: gwStatus.version,
      model: gwStatus.model,
    },
  })
}

// ── Helpers ──

interface AgentOutput {
  id: string
  name: string
  icon: string
  color: string
  output: string
  files: any[]
  toolCalls: any[]
}

interface StageResult {
  stage: number
  name: string
  strategy: string
  description: string
  agents: AgentOutput[]
}

async function callAgent(
  ctx: SessionContext,
  agentId: string,
  task: string,
  domainContext: string,
  previousOutputs: string,
  gatewayConnected: boolean,
  mode: string,
): Promise<SendMessageResult> {
  const agent = AGENTS[agentId]
  if (!agent) {
    return { text: `Unknown agent: ${agentId}`, toolCalls: [], files: [], sessionId: '', model: 'unknown' }
  }

  const policyNote = mode === 'advisory'
    ? '\n\nPOLICY: ADVISORY MODE — analyze and recommend. You CAN use your computer tools to research and inspect, but do NOT make destructive changes.'
    : '\n\nPOLICY: EXECUTE MODE — you may make changes, create files, run commands. All actions are audited.'

  const fullMessage = [
    task,
    policyNote,
    previousOutputs ? `\n\n--- PREVIOUS AGENT OUTPUTS ---\n${previousOutputs}` : '',
  ].filter(Boolean).join('\n')

  return sendMessage(agentId, fullMessage, {
    context: domainContext,
    skills: agent.skills,
    toolPolicy: mode === 'advisory' ? 'ask' : agent.toolPolicy,
  })
}

async function buildDomainContext(orgId: string): Promise<string> {
  const sb = getSupabase()
  if (!sb) return '(No database connected)'

  try {
    const [
      { data: subsystems },
      { data: tasks },
      { data: pilots },
      { data: incidents },
    ] = await Promise.all([
      sb.from('subsystems').select('name, maturity_level, status').eq('organization_id', orgId),
      sb.from('tasks').select('title, status, priority').eq('organization_id', orgId).neq('status', 'done').limit(15),
      sb.from('pilots').select('company_name, stage, viability_score').eq('organization_id', orgId).limit(5),
      sb.from('incidents').select('title, severity, status').eq('organization_id', orgId).eq('status', 'open').limit(5),
    ])

    const parts = ['DOGMA Robotics — Context Snapshot\n']
    if (subsystems?.length) parts.push('Subsystems: ' + subsystems.map(s => `${s.name}(${s.maturity_level}%/${s.status})`).join(', '))
    if (tasks?.length) parts.push('Open tasks: ' + tasks.map(t => `[${t.priority}] ${t.title}`).join(', '))
    if (pilots?.length) parts.push('Pilots: ' + pilots.map(p => `${p.company_name}(${p.stage})`).join(', '))
    if (incidents?.length) parts.push('Incidents: ' + incidents.map(i => `[${i.severity}] ${i.title}`).join(', '))
    return parts.join('\n')
  } catch {
    return '(Error loading context)'
  }
}
