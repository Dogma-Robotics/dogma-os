// ══════════════════════════════════════════════════════════════════
// DOGMA OS v2 — OpenClaw Gateway Client
// Bridges DOGMA's Next.js backend to a local OpenClaw instance
// running on the user's machine (ws://127.0.0.1:18789)
// ══════════════════════════════════════════════════════════════════

// ── Types ──

export interface OpenClawConfig {
  gatewayUrl: string       // WebSocket URL: ws://127.0.0.1:18789
  httpUrl: string          // REST URL:      http://127.0.0.1:18789
  apiToken?: string        // Shared-token auth (from openclaw config)
  workspace: string        // Path to DOGMA workspace on user's machine
  defaultModel: string     // e.g. 'claude-sonnet-4-20250514'
  fallbackModel?: string   // e.g. 'claude-haiku-4-5-20251001'
}

export interface ClawMessage {
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp?: string
  toolCalls?: ClawToolCall[]
  files?: ClawFile[]
}

export interface ClawToolCall {
  tool: string
  input: Record<string, any>
  output?: string
  status: 'pending' | 'approved' | 'executed' | 'denied'
  requiresApproval: boolean
}

export interface ClawFile {
  name: string
  path: string
  mime: string
  size?: number
  url?: string
}

export interface ClawSession {
  id: string
  agentId: string
  channel: string
  createdAt: string
  lastActive: string
  messageCount: number
  model: string
}

export interface ClawAgentConfig {
  id: string
  name: string
  icon: string
  color: string
  category: string
  workspace: string
  skills: string[]
  toolPolicy: 'ask' | 'record' | 'ignore'
  allowedTools: string[]
  deniedTools: string[]
  model?: string
}

export interface ClawGatewayStatus {
  running: boolean
  version: string
  uptime: number
  activeAgents: string[]
  activeSessions: number
  model: string
  channels: string[]
}

export interface SendMessageResult {
  text: string
  toolCalls: ClawToolCall[]
  files: ClawFile[]
  sessionId: string
  tokenUsage?: { input: number; output: number; cost?: number }
  model: string
}

// ── Default Configuration ──

const DEFAULT_CONFIG: OpenClawConfig = {
  gatewayUrl: process.env.OPENCLAW_GATEWAY_WS || 'ws://127.0.0.1:18789',
  httpUrl: process.env.OPENCLAW_GATEWAY_HTTP || 'http://127.0.0.1:18789',
  apiToken: process.env.OPENCLAW_API_TOKEN || '',
  workspace: process.env.OPENCLAW_WORKSPACE || '~/.openclaw/workspaces/dogma',
  defaultModel: process.env.OPENCLAW_MODEL || 'claude-sonnet-4-20250514',
  fallbackModel: process.env.OPENCLAW_FALLBACK_MODEL || 'claude-haiku-4-5-20251001',
}

// ── Gateway Health Check ──

export async function checkGateway(config?: Partial<OpenClawConfig>): Promise<ClawGatewayStatus> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/status`, {
      headers: authHeaders(cfg),
      signal: AbortSignal.timeout(3000),
    })
    if (!res.ok) throw new Error(`Gateway returned ${res.status}`)
    const data = await res.json()
    return {
      running: true,
      version: data.version || 'unknown',
      uptime: data.uptime || 0,
      activeAgents: data.agents || [],
      activeSessions: data.sessions?.active || 0,
      model: data.model || cfg.defaultModel,
      channels: data.channels || [],
    }
  } catch (e: any) {
    return {
      running: false,
      version: 'unreachable',
      uptime: 0,
      activeAgents: [],
      activeSessions: 0,
      model: cfg.defaultModel,
      channels: [],
    }
  }
}

// ── Send Message to Agent ──

export async function sendMessage(
  agentId: string,
  message: string,
  options: {
    sessionId?: string
    context?: string          // DOGMA domain data injected as context
    skills?: string[]         // Additional skills to load for this turn
    toolPolicy?: 'ask' | 'record' | 'ignore'
    approvedTools?: string[]  // Pre-approved tool calls (from DOGMA approval queue)
    model?: string
    maxTokens?: number
    config?: Partial<OpenClawConfig>
  } = {}
): Promise<SendMessageResult> {
  const cfg = { ...DEFAULT_CONFIG, ...options.config }

  // Build the message payload for OpenClaw gateway
  const payload: Record<string, any> = {
    agent: agentId,
    message,
    session: options.sessionId || undefined,
    model: options.model || cfg.defaultModel,
    max_tokens: options.maxTokens || 8192,
  }

  // Inject DOGMA context as a skill-style context block
  if (options.context) {
    payload.context = options.context
  }

  // Specify which skills to activate for this turn
  if (options.skills?.length) {
    payload.skills = options.skills
  }

  // Tool execution policy
  if (options.toolPolicy) {
    payload.tool_policy = options.toolPolicy
  }

  // Pre-approved tools (bypass approval for these)
  if (options.approvedTools?.length) {
    payload.approved_tools = options.approvedTools
  }

  try {
    const res = await fetch(`${cfg.httpUrl}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...authHeaders(cfg),
      },
      body: JSON.stringify(payload),
    })

    if (!res.ok) {
      const err = await res.text().catch(() => 'Unknown error')
      throw new Error(`OpenClaw gateway error (${res.status}): ${err}`)
    }

    const data = await res.json()

    return {
      text: extractText(data),
      toolCalls: extractToolCalls(data),
      files: extractFiles(data),
      sessionId: data.session_id || options.sessionId || '',
      tokenUsage: data.usage || undefined,
      model: data.model || cfg.defaultModel,
    }
  } catch (e: any) {
    // If gateway is down, fall back to direct Anthropic API call
    if (e.message.includes('ECONNREFUSED') || e.message.includes('unreachable')) {
      console.warn('[OpenClaw] Gateway unreachable — falling back to direct API')
      return fallbackDirectCall(agentId, message, options, cfg)
    }
    throw e
  }
}

// ── Stream Message (SSE) ──

export async function streamMessage(
  agentId: string,
  message: string,
  options: {
    sessionId?: string
    context?: string
    skills?: string[]
    onText?: (chunk: string) => void
    onToolCall?: (call: ClawToolCall) => void
    onFile?: (file: ClawFile) => void
    onDone?: (result: SendMessageResult) => void
    config?: Partial<OpenClawConfig>
  } = {}
): Promise<void> {
  const cfg = { ...DEFAULT_CONFIG, ...options.config }

  const payload = {
    agent: agentId,
    message,
    session: options.sessionId,
    model: cfg.defaultModel,
    stream: true,
  }

  if (options.context) (payload as any).context = options.context
  if (options.skills?.length) (payload as any).skills = options.skills

  const res = await fetch(`${cfg.httpUrl}/api/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'text/event-stream',
      ...authHeaders(cfg),
    },
    body: JSON.stringify(payload),
  })

  if (!res.ok || !res.body) {
    throw new Error(`Stream failed: ${res.status}`)
  }

  const reader = res.body.getReader()
  const decoder = new TextDecoder()
  let fullText = ''
  const allToolCalls: ClawToolCall[] = []
  const allFiles: ClawFile[] = []

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    const chunk = decoder.decode(value, { stream: true })
    const lines = chunk.split('\n')

    for (const line of lines) {
      if (!line.startsWith('data: ')) continue
      const data = line.slice(6)
      if (data === '[DONE]') continue

      try {
        const event = JSON.parse(data)
        if (event.type === 'text' && event.text) {
          fullText += event.text
          options.onText?.(event.text)
        }
        if (event.type === 'tool_call') {
          const tc: ClawToolCall = {
            tool: event.tool,
            input: event.input,
            output: event.output,
            status: event.status || 'executed',
            requiresApproval: event.requires_approval || false,
          }
          allToolCalls.push(tc)
          options.onToolCall?.(tc)
        }
        if (event.type === 'file') {
          const f: ClawFile = {
            name: event.name,
            path: event.path,
            mime: event.mime,
            size: event.size,
            url: event.url,
          }
          allFiles.push(f)
          options.onFile?.(f)
        }
      } catch {}
    }
  }

  options.onDone?.({
    text: fullText,
    toolCalls: allToolCalls,
    files: allFiles,
    sessionId: options.sessionId || '',
    model: cfg.defaultModel,
  })
}

// ── Session Management ──

export async function listSessions(agentId?: string, config?: Partial<OpenClawConfig>): Promise<ClawSession[]> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const url = agentId
      ? `${cfg.httpUrl}/api/sessions?agent=${agentId}`
      : `${cfg.httpUrl}/api/sessions`
    const res = await fetch(url, { headers: authHeaders(cfg) })
    if (!res.ok) return []
    const data = await res.json()
    return (data.sessions || []).map((s: any) => ({
      id: s.id,
      agentId: s.agent_id || s.agent,
      channel: s.channel || 'dogma-os',
      createdAt: s.created_at,
      lastActive: s.last_active,
      messageCount: s.message_count || 0,
      model: s.model || cfg.defaultModel,
    }))
  } catch { return [] }
}

export async function getSessionHistory(sessionId: string, config?: Partial<OpenClawConfig>): Promise<ClawMessage[]> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/sessions/${sessionId}/history`, {
      headers: authHeaders(cfg),
    })
    if (!res.ok) return []
    const data = await res.json()
    return (data.messages || []).map((m: any) => ({
      role: m.role,
      content: m.content,
      timestamp: m.timestamp,
      toolCalls: m.tool_calls,
      files: m.files,
    }))
  } catch { return [] }
}

// ── Agent Management ──

export async function listAgents(config?: Partial<OpenClawConfig>): Promise<ClawAgentConfig[]> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/agents`, { headers: authHeaders(cfg) })
    if (!res.ok) return []
    const data = await res.json()
    return data.agents || []
  } catch { return [] }
}

// ── Tool Approval Queue ──

export async function getPendingApprovals(config?: Partial<OpenClawConfig>): Promise<ClawToolCall[]> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/approvals/pending`, {
      headers: authHeaders(cfg),
    })
    if (!res.ok) return []
    const data = await res.json()
    return data.pending || []
  } catch { return [] }
}

export async function approveToolCall(callId: string, config?: Partial<OpenClawConfig>): Promise<boolean> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/approvals/${callId}/approve`, {
      method: 'POST',
      headers: authHeaders(cfg),
    })
    return res.ok
  } catch { return false }
}

export async function denyToolCall(callId: string, config?: Partial<OpenClawConfig>): Promise<boolean> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/approvals/${callId}/deny`, {
      method: 'POST',
      headers: authHeaders(cfg),
    })
    return res.ok
  } catch { return false }
}

// ── File Operations (via OpenClaw) ──

export async function readFile(path: string, config?: Partial<OpenClawConfig>): Promise<string | null> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/files/read`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders(cfg) },
      body: JSON.stringify({ path }),
    })
    if (!res.ok) return null
    const data = await res.json()
    return data.content || null
  } catch { return null }
}

export async function writeFile(path: string, content: string, config?: Partial<OpenClawConfig>): Promise<boolean> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/files/write`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders(cfg) },
      body: JSON.stringify({ path, content }),
    })
    return res.ok
  } catch { return false }
}

// ── Execute Shell Command (via OpenClaw) ──

export async function executeShell(
  command: string,
  options: {
    cwd?: string
    timeout?: number
    requireApproval?: boolean
    config?: Partial<OpenClawConfig>
  } = {}
): Promise<{ stdout: string; stderr: string; exitCode: number }> {
  const cfg = { ...DEFAULT_CONFIG, ...options.config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/tools/invoke`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders(cfg) },
      body: JSON.stringify({
        tool: 'system.run',
        input: {
          command,
          cwd: options.cwd,
          timeout: options.timeout || 30000,
        },
        require_approval: options.requireApproval ?? true,
      }),
    })
    if (!res.ok) throw new Error(`Shell exec failed: ${res.status}`)
    const data = await res.json()
    return {
      stdout: data.stdout || '',
      stderr: data.stderr || '',
      exitCode: data.exit_code ?? -1,
    }
  } catch (e: any) {
    return { stdout: '', stderr: e.message, exitCode: -1 }
  }
}

// ── Browser Control (via OpenClaw) ──

export async function browserNavigate(url: string, config?: Partial<OpenClawConfig>): Promise<{ title: string; content: string }> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/tools/invoke`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders(cfg) },
      body: JSON.stringify({
        tool: 'browser.navigate',
        input: { url },
      }),
    })
    if (!res.ok) throw new Error(`Browser navigate failed`)
    const data = await res.json()
    return { title: data.title || '', content: data.content || '' }
  } catch (e: any) {
    return { title: 'Error', content: e.message }
  }
}

// ── Canvas (A2UI) ──

export async function pushCanvas(html: string, config?: Partial<OpenClawConfig>): Promise<boolean> {
  const cfg = { ...DEFAULT_CONFIG, ...config }
  try {
    const res = await fetch(`${cfg.httpUrl}/api/canvas/push`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders(cfg) },
      body: JSON.stringify({ html }),
    })
    return res.ok
  } catch { return false }
}

// ── Internal Helpers ──

function authHeaders(cfg: OpenClawConfig): Record<string, string> {
  const headers: Record<string, string> = {}
  if (cfg.apiToken) {
    headers['Authorization'] = `Bearer ${cfg.apiToken}`
  }
  return headers
}

function extractText(data: any): string {
  if (typeof data.text === 'string') return data.text
  if (Array.isArray(data.content)) {
    return data.content
      .filter((b: any) => b.type === 'text')
      .map((b: any) => b.text)
      .join('\n')
  }
  return data.message || data.reply || ''
}

function extractToolCalls(data: any): ClawToolCall[] {
  const calls: ClawToolCall[] = []
  if (Array.isArray(data.tool_calls)) {
    for (const tc of data.tool_calls) {
      calls.push({
        tool: tc.tool || tc.name,
        input: tc.input || tc.args || {},
        output: tc.output || tc.result,
        status: tc.status || 'executed',
        requiresApproval: tc.requires_approval || false,
      })
    }
  }
  if (Array.isArray(data.content)) {
    for (const block of data.content) {
      if (block.type === 'tool_use' || block.type === 'mcp_tool_use') {
        calls.push({
          tool: block.name,
          input: block.input || {},
          status: 'executed',
          requiresApproval: false,
        })
      }
    }
  }
  return calls
}

function extractFiles(data: any): ClawFile[] {
  if (Array.isArray(data.files)) {
    return data.files.map((f: any) => ({
      name: f.name,
      path: f.path,
      mime: f.mime || f.type || 'application/octet-stream',
      size: f.size,
      url: f.url,
    }))
  }
  return []
}

// ── Fallback: Direct Anthropic API (when gateway is down) ──

async function fallbackDirectCall(
  agentId: string,
  message: string,
  options: any,
  cfg: OpenClawConfig
): Promise<SendMessageResult> {
  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    return {
      text: '⚠️ OpenClaw gateway is not running and no ANTHROPIC_API_KEY is set.\n\nTo use DOGMA OS agents, start OpenClaw:\n```\nopenclaw gateway run\n```\n\nOr set ANTHROPIC_API_KEY in .env.local for direct API fallback.',
      toolCalls: [],
      files: [],
      sessionId: '',
      model: 'fallback',
    }
  }

  // Import agent definition for system prompt
  const { AGENTS } = await import('./agents')
  const agent = AGENTS[agentId]
  if (!agent) {
    return { text: `Unknown agent: ${agentId}`, toolCalls: [], files: [], sessionId: '', model: 'fallback' }
  }

  const systemPrompt = agent.soulPrompt + (options.context ? `\n\n--- DOGMA CONTEXT ---\n${options.context}` : '')

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: cfg.defaultModel,
      max_tokens: options.maxTokens || 4096,
      system: systemPrompt,
      messages: [{ role: 'user', content: message }],
    }),
  })

  if (!res.ok) {
    const err = await res.text().catch(() => 'unknown')
    return { text: `❌ API Error: ${err.slice(0, 300)}`, toolCalls: [], files: [], sessionId: '', model: cfg.defaultModel }
  }

  const data = await res.json()
  const text = (data.content || []).filter((b: any) => b.type === 'text').map((b: any) => b.text).join('\n')

  return {
    text: text || '(no response)',
    toolCalls: [],
    files: [],
    sessionId: '',
    tokenUsage: data.usage ? { input: data.usage.input_tokens, output: data.usage.output_tokens } : undefined,
    model: data.model || cfg.defaultModel,
  }
}

// ── Export config helper ──

export function getConfig(overrides?: Partial<OpenClawConfig>): OpenClawConfig {
  return { ...DEFAULT_CONFIG, ...overrides }
}
