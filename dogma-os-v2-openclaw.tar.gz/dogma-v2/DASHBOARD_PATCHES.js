// ══════════════════════════════════════════════════════════════════
// DOGMA OS v2 — Dashboard Patch (OpenClaw Integration)
//
// Apply these changes to src/app/dashboard/page.tsx
// Each section below shows FIND → REPLACE with context
// ══════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════
// PATCH 1: Replace AGENTS array (line ~978)
// ═══════════════════════════════════════════
// FIND (line 978-991):
/*
var AGENTS=[
  // ── CORE AGENTS (production-ready for DOGMA) ──
  {id:"planner",name:"Planner",icon:"📐",color:C.gold,cat:"core",desc:"Implementation planner — ..."},
  ... (7 agents)
];
var AGENT_CATEGORIES=[
  {id:"core",label:"Core",color:C.gold},
  {id:"build",label:"Build & Review",color:C.g},
];
*/
// REPLACE WITH:

var AGENTS=[
  // ── STRATEGY ──
  {id:"planner",name:"Planner",icon:"📐",color:C.gold,cat:"strategy",desc:"Creates phased implementation blueprints",access:{shell:true,files:true,browser:true,canvas:true}},
  {id:"architect",name:"Architect",icon:"🏗️",color:C.b,cat:"strategy",desc:"Technology decisions and system boundaries",access:{shell:true,files:true,browser:true,canvas:true}},
  {id:"researcher",name:"Researcher",icon:"🔍",color:C.c,cat:"strategy",desc:"Deep research with real browser access",access:{shell:true,files:true,browser:true,canvas:false}},
  // ── IMPLEMENTATION ──
  {id:"coder",name:"Coder",icon:"💻",color:C.g,cat:"implementation",desc:"Full-stack dev with shell + file + browser access on your machine",access:{shell:true,files:true,browser:true,canvas:true}},
  {id:"data-engineer",name:"Data Eng",icon:"🗄️",color:C.c,cat:"implementation",desc:"Schemas, migrations, queries — can run psql",access:{shell:true,files:true,browser:false,canvas:false}},
  // ── QUALITY ──
  {id:"tester",name:"Tester",icon:"🧪",color:C.r,cat:"quality",desc:"Writes and runs tests on your machine",access:{shell:true,files:true,browser:true,canvas:false}},
  {id:"reviewer",name:"Reviewer",icon:"👁️",color:C.a,cat:"quality",desc:"Code review with actual codebase access (read-only)",access:{shell:true,files:false,browser:false,canvas:false}},
  {id:"security-scanner",name:"Security",icon:"🔒",color:C.r,cat:"quality",desc:"Security audit with scanning tools — npm audit, grep secrets",access:{shell:true,files:false,browser:true,canvas:false}},
  // ── OPERATIONS ──
  {id:"documenter",name:"Documenter",icon:"📄",color:C.b,cat:"operations",desc:"Generates polished HTML reports and docs as real files",access:{shell:true,files:true,browser:true,canvas:true}},
  {id:"coordinator",name:"Coordinator",icon:"🎯",color:C.gold,cat:"operations",desc:"Synthesizes multi-agent outputs into executive summaries",access:{shell:true,files:true,browser:false,canvas:true}},
  {id:"devops",name:"DevOps",icon:"🚀",color:C.g,cat:"operations",desc:"CI/CD, deployment, Docker, infrastructure",access:{shell:true,files:true,browser:false,canvas:false}},
];
var AGENT_CATEGORIES=[
  {id:"strategy",label:"Strategy",color:C.gold},
  {id:"implementation",label:"Implementation",color:C.g},
  {id:"quality",label:"Quality",color:C.r},
  {id:"operations",label:"Operations",color:C.b},
];


// ═══════════════════════════════════════════
// PATCH 2: Add gateway state (after line ~1047)
// ═══════════════════════════════════════════
// FIND (line ~1048):
/*
var _mode=useState("chat"),mode=_mode[0],setMode=_mode[1];
*/
// ADD BEFORE:

var _gateway=useState({connected:false,version:'',model:''}),gateway=_gateway[0],setGateway=_gateway[1];
var _toolLog=useState([]),toolLog=_toolLog[0],setToolLog=_toolLog[1];
var _sessionId=useState(null),sessionId=_sessionId[0],setSessionId=_sessionId[1];

// Check gateway status on mount + every 30s
useEffect(function(){
  var checkGW=function(){
    fetch("/api/sessions").then(function(r){return r.json();}).then(function(data){
      if(data.gateway)setGateway(data.gateway);
    }).catch(function(){setGateway({connected:false,version:'',model:''});});
  };
  checkGW();
  var iv=setInterval(checkGW,30000);
  return function(){clearInterval(iv);};
},[]);


// ═══════════════════════════════════════════
// PATCH 3: Update SWARM_WORKFLOWS (line ~1055)
// ═══════════════════════════════════════════
// FIND (line 1055-1061):
/*
var SWARM_WORKFLOWS=[
  {id:"pilot-analysis",...},
  ... (old workflows)
];
*/
// REPLACE WITH:

var SWARM_WORKFLOWS=[
  {id:"build-feature",name:"Build Feature",desc:"Research → Plan → Code → Test → Review → Document",agents:6,icon:"⚡"},
  {id:"code-review",name:"Code Review",desc:"Security + Quality + Tests → Synthesize",agents:4,icon:"👁️"},
  {id:"research-sprint",name:"Research Sprint",desc:"Research → Architect → Plan → Document",agents:4,icon:"🔍"},
  {id:"deploy",name:"Deploy",desc:"Build → Test → Security → Deploy",agents:4,icon:"🚀"},
  {id:"incident-response",name:"Incident Response",desc:"Diagnose → Fix → Test → Post-mortem",agents:6,icon:"🚨"},
];


// ═══════════════════════════════════════════
// PATCH 4: Update sendAgent function (line ~1510)
// ═══════════════════════════════════════════
// FIND (line 1530-1565):
/*
  fetch("/api/chat",{
    method:"POST",
    ... (existing fetch call)
  })
  .then(function(r){return r.json();})
  .then(function(data){
    var text=data.text||"(empty)";
    if(data.mcpConnected ...
*/
// REPLACE THE .then(function(data){...}) HANDLER WITH:

  .then(function(data){
    var text=data.text||"(empty)";
    // Gateway status update
    if(data.gateway)setGateway(data.gateway);
    // Session persistence
    if(data.sessionId)setSessionId(data.sessionId);
    // MCP connections (backward compat)
    if(data.mcpConnected&&data.mcpConnected.length>0)setMcpConn(data.mcpConnected);
    if(data.user&&data.user.role&&!userInfo.loaded)setUserInfo({name:data.user.name||'',role:data.user.role||'',loaded:true});
    // Files from agent
    var files=(data.files||[]).map(function(f){return{name:f.name,icon:f.type==="csv"?"\uD83D\uDCC8":f.type==="html"?"\uD83D\uDCC4":f.type==="json"?"\uD83D\uDCCB":f.type==="md"?"\uD83D\uDCDD":"\uD83D\uDCC1",url:f.url||f.path,at:nw()};});
    // Tool calls from OpenClaw (shell commands, browser, etc.)
    var toolCalls=(data.toolCalls||[]).map(function(tc){return{tool:tc.tool,input:typeof tc.input==='string'?tc.input:JSON.stringify(tc.input||{}).slice(0,100),output:(tc.output||'').slice(0,200),status:tc.status||'executed'};});
    if(toolCalls.length>0){
      setToolLog(function(prev){return toolCalls.concat(prev).slice(0,50);});
    }
    // Mutations
    var mutations=data.mutations||[];
    if(approvalMode==="advisory"&&mutations.length>0){
      setPendingMuts(function(prev){return prev.concat(mutations.map(function(m){return Object.assign({},m,{status:"pending",at:nw(),agent:agentId});}));});
      text+="\\n\\n\uD83D\uDD12 "+mutations.length+" mutation(s) proposed (advisory mode). Review in approval queue.";
    }
    setMsgs(function(prev){var n=Object.assign({},prev);n[agentId]=(n[agentId]||[]).concat([{role:"ai",text:text,files:files,toolCalls:toolCalls,mutations:mutations,model:data.gateway?.model||''}]);return n;});
    // Refresh data if mutations were applied
    if(mutations.length>0){
      fetch("/api/dashboard/summary").then(function(r){return r.json();}).then(function(data){
        if(data&&data.ss){
          var fin=data.fin||D.fin;
          setD(function(prev){return Object.assign({},prev,{
            tasks:(data.tasks||[]).map(function(t){return{id:t.id,pct:t.progress||t.pct||0,title:t.title,ws:t.workspace||'General',status:t.status||'todo',pri:t.priority||'medium',due:'',owner:'Jero',created:'',notes:[],blocked:t.blocked_by||'',sb:t.sub_tasks||[],impact:t.impact||''};}),
            pilots:(data.pilots||[]).map(function(p){return{id:p.id,name:p.company_name,stage:p.stage||'Identified',viab:p.viability_score||0,roi:p.roi_estimate||'',champ:p.champion_name||'',champStr:p.champion_strength||'None',plant:'',plc:'',pain:'',skills:[],comp:[],risk:p.risk_level||'medium',qs:[],nextStep:'',fu:'',meetings:[],blockers:[],notes:[]};}),
            incidents:(data.incidents||[]).map(function(i){return{id:i.id,sev:i.severity||'low',desc:i.title||'',down:i.downtime||'',root:i.root_cause||'',status:i.status||'open',reported:'',notes:[],acts:i.actions||[],timeline:i.timeline||[]};}),
            fin:{burn:fin.burn||prev.fin.burn,cash:fin.cash||prev.fin.cash,runway:fin.runway||prev.fin.runway,bom:fin.bom||prev.fin.bom,spend:fin.spend||prev.fin.spend},
          });});
        }
      }).catch(function(){});
    }
  })


// ═══════════════════════════════════════════
// PATCH 5: Add Gateway Status Bar to header
// ═══════════════════════════════════════════
// FIND the top bar / header area, typically the first <div> after the return statement
// In the header area, ADD this gateway indicator component.
// Look for where user info is displayed and add nearby:

// JSX to insert in the header bar:
/*
<div style={{display:"flex",alignItems:"center",gap:6,padding:"4px 10px",borderRadius:4,
  background:gateway.connected?"rgba(45,122,93,0.08)":"rgba(138,51,51,0.08)",
  border:"1px solid "+(gateway.connected?"rgba(45,122,93,0.2)":"rgba(138,51,51,0.2)")}}>
  <span style={{width:6,height:6,borderRadius:"50%",
    background:gateway.connected?C.g:C.r,
    boxShadow:gateway.connected?"0 0 6px rgba(45,122,93,0.5)":"none"}}/>
  <span style={{fontSize:10,fontWeight:600,color:gateway.connected?C.g:C.r,fontFamily:"'JetBrains Mono',monospace"}}>
    {gateway.connected?"OpenClaw "+gateway.version:"Gateway offline"}
  </span>
  {gateway.connected&&gateway.model&&<span style={{fontSize:9,color:C.tx3}}>{gateway.model.replace("claude-","").replace("-20250514","")}</span>}
</div>
*/


// ═══════════════════════════════════════════
// PATCH 6: Update agent card rendering (in chat mode)
// ═══════════════════════════════════════════
// FIND the agent card rendering inside AGENT_CATEGORIES.map (line ~1863-1868)
// Replace the agent card with one that shows computer access badges:

// In the catAgents.map section, replace the agent button with:
/*
{catAgents.map(function(ag){var isA=agentId===ag.id;return <div key={ag.id} onClick={function(){setAgentId(ag.id);}} title={ag.desc} style={{display:"flex",alignItems:"center",gap:3,padding:"3px 6px",borderRadius:3,cursor:"pointer",background:isA?ag.color+"15":"transparent",border:"1px solid "+(isA?ag.color+"30":C.bd+"50"),transition:"all 0.15s"}}>
  <span style={{fontSize:11}}>{ag.icon}</span>
  <span style={{fontSize:9,fontWeight:600,color:isA?ag.color:C.tx3}}>{ag.name}</span>
  {ag.access&&<span style={{display:"flex",gap:1,marginLeft:2}}>
    {ag.access.shell&&<span title="Shell access" style={{fontSize:7,opacity:0.5}}>⌨</span>}
    {ag.access.browser&&<span title="Browser access" style={{fontSize:7,opacity:0.5}}>🌐</span>}
    {ag.access.files&&<span title="File write" style={{fontSize:7,opacity:0.5}}>📁</span>}
  </span>}
</div>;})}
*/


// ═══════════════════════════════════════════
// PATCH 7: Update agent info panel (line ~1870)
// ═══════════════════════════════════════════
// FIND the agent info section that shows curAgent.desc (line ~1870-1873)
// REPLACE WITH:

/*
<div style={{padding:"8px 10px",borderBottom:"1px solid "+C.bd,flexShrink:0}}>
  <div style={{display:"flex",alignItems:"center",gap:6}}>
    <div style={{fontSize:13,fontWeight:700,color:curAgent.color}}>{curAgent.icon} {curAgent.name}</div>
    {gateway.connected&&<span style={{fontSize:8,padding:"1px 5px",borderRadius:2,background:C.g+"15",color:C.g,border:"1px solid "+C.g+"25",fontWeight:600}}>LIVE</span>}
    {!gateway.connected&&<span style={{fontSize:8,padding:"1px 5px",borderRadius:2,background:C.r+"15",color:C.r,border:"1px solid "+C.r+"25",fontWeight:600}}>API ONLY</span>}
  </div>
  <div style={{fontSize:11,color:C.tx2,lineHeight:1.4,marginTop:2}}>{curAgent.desc}</div>
  {curAgent.access&&<div style={{display:"flex",flexWrap:"wrap",gap:3,marginTop:4}}>
    {curAgent.access.shell&&<span style={{fontSize:9,padding:"2px 6px",borderRadius:3,background:C.gold+"10",color:C.gold,border:"1px solid "+C.gold+"20"}}>⌨ Shell</span>}
    {curAgent.access.browser&&<span style={{fontSize:9,padding:"2px 6px",borderRadius:3,background:C.b+"10",color:C.b,border:"1px solid "+C.b+"20"}}>🌐 Browser</span>}
    {curAgent.access.files&&<span style={{fontSize:9,padding:"2px 6px",borderRadius:3,background:C.g+"10",color:C.g,border:"1px solid "+C.g+"20"}}>📁 Files</span>}
    {curAgent.access.canvas&&<span style={{fontSize:9,padding:"2px 6px",borderRadius:3,background:C.c+"10",color:C.c,border:"1px solid "+C.c+"20"}}>🖼 Canvas</span>}
  </div>}
  {mcpConn.length>0&&<div style={{display:"flex",flexWrap:"wrap",gap:3,marginTop:4}}>{mcpConn.map(function(s,i){return <span key={i} style={{fontSize:9,padding:"2px 6px",borderRadius:3,background:C.g+"15",color:C.g,border:"1px solid "+C.g+"30",fontWeight:600}}>🔗 {s}</span>;})}</div>}
  {sessionId&&<div style={{fontSize:9,color:C.tx3,marginTop:3,fontFamily:"'JetBrains Mono',monospace"}}>Session: {sessionId.slice(0,8)}...</div>}
</div>
*/


// ═══════════════════════════════════════════
// PATCH 8: Update chat message rendering (line ~1877)
// ═══════════════════════════════════════════
// FIND the chat message rendering (curMsgs.map, line ~1877-1883)
// After the file cards, ADD tool call display:

// Inside the msg.files rendering block, after the files loop, add:
/*
{msg.toolCalls&&msg.toolCalls.length>0&&<div style={{marginTop:4}}>
  <div style={{fontSize:9,color:C.gold,textTransform:"uppercase",letterSpacing:"0.08em",fontWeight:700,marginBottom:2}}>Tool executions ({msg.toolCalls.length})</div>
  {msg.toolCalls.map(function(tc,k){return <div key={k} style={{padding:"4px 8px",background:C.bg,borderRadius:3,marginBottom:2,border:"1px solid "+(tc.status==="executed"?C.g+"25":tc.status==="denied"?C.r+"25":C.a+"25"),fontSize:11}}>
    <div style={{display:"flex",alignItems:"center",gap:4}}>
      <span style={{color:tc.status==="executed"?C.g:tc.status==="denied"?C.r:C.a,fontWeight:600,fontFamily:"'JetBrains Mono',monospace"}}>{tc.tool}</span>
      <span style={{color:C.tx3,fontSize:9}}>{tc.status}</span>
    </div>
    {tc.input&&<div style={{fontSize:10,color:C.tx3,marginTop:1,fontFamily:"'JetBrains Mono',monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{tc.input}</div>}
    {tc.output&&<div style={{fontSize:10,color:C.tx2,marginTop:1,fontFamily:"'JetBrains Mono',monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:"100%"}}>{tc.output}</div>}
  </div>;})}
</div>}
*/


// ═══════════════════════════════════════════
// PATCH 9: Remove old tool definitions (lines ~1456-1491)
// ═══════════════════════════════════════════
// The FILE_TOOLS and DATA_TOOLS arrays plus genCSV, genDOCX, genPDF, genPPTX,
// genLatex, dlAndStore, and execLocal functions can be REMOVED.
// They are replaced by OpenClaw's native tool execution.
// The backend now handles all tool execution through the gateway.
//
// Keep the FileCard component — it still renders files from the API response.


// ═══════════════════════════════════════════
// PATCH 10: Update the sendAgent fetch body (line ~1529-1532)
// ═══════════════════════════════════════════
// FIND:
/*
body:JSON.stringify({message:userTxt,agentId:agentId,dataContext:dataSnap,mode:approvalMode})
*/
// REPLACE WITH (adds sessionId for persistence):
/*
body:JSON.stringify({message:userTxt,agentId:agentId,sessionId:sessionId,dataContext:dataSnap,mode:approvalMode})
*/


// ═══════════════════════════════════════════
// PATCH 11: Add "Tools" mode tab (line ~1850-1858)
// ═══════════════════════════════════════════
// In the mode tabs row, ADD a new tab before the Queue tab:
/*
<div onClick={function(){setMode("tools");}} style={{flex:1,padding:"8px 0",textAlign:"center",fontSize:11,fontWeight:600,cursor:"pointer",color:mode==="tools"?C.gold:C.tx3,borderBottom:mode==="tools"?"2px solid "+C.gold:"2px solid transparent",background:mode==="tools"?C.gold+"08":"transparent"}}>⚡ Tools{toolLog.length>0?" ("+toolLog.length+")":""}</div>
*/


// ═══════════════════════════════════════════
// PATCH 12: Add Tools panel body (after swarm mode, before timeline)
// ═══════════════════════════════════════════
// ADD this new mode panel:

/*
{mode==="tools"&&<>
<div style={{flex:1,overflowY:"auto",padding:10}}>
  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:12}}>
    <div style={{width:8,height:8,borderRadius:"50%",background:gateway.connected?C.g:C.r,boxShadow:gateway.connected?"0 0 8px rgba(45,122,93,0.5)":"none"}}/>
    <div>
      <div style={{fontSize:13,fontWeight:700,color:gateway.connected?C.g:C.r}}>{gateway.connected?"OpenClaw Gateway Connected":"Gateway Offline"}</div>
      {gateway.connected&&<div style={{fontSize:10,color:C.tx3}}>v{gateway.version} • {gateway.model} • {gateway.activeSessions||0} sessions</div>}
      {!gateway.connected&&<div style={{fontSize:10,color:C.tx3}}>Start with: openclaw gateway run</div>}
    </div>
  </div>

  {gateway.connected&&<div style={{marginBottom:16}}>
    <div style={{fontSize:10,color:C.gold,textTransform:"uppercase",letterSpacing:"0.08em",fontWeight:700,marginBottom:6}}>Agent Capabilities</div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:4}}>
      {AGENTS.map(function(ag){return <div key={ag.id} style={{padding:"6px 8px",background:C.bg,borderRadius:4,border:"1px solid "+C.bd}}>
        <div style={{fontSize:11,fontWeight:600,color:ag.color}}>{ag.icon} {ag.name}</div>
        <div style={{display:"flex",gap:3,marginTop:3}}>
          {ag.access.shell&&<span style={{fontSize:8,padding:"1px 4px",borderRadius:2,background:C.gold+"10",color:C.gold}}>shell</span>}
          {ag.access.browser&&<span style={{fontSize:8,padding:"1px 4px",borderRadius:2,background:C.b+"10",color:C.b}}>browser</span>}
          {ag.access.files&&<span style={{fontSize:8,padding:"1px 4px",borderRadius:2,background:C.g+"10",color:C.g}}>files</span>}
          {ag.access.canvas&&<span style={{fontSize:8,padding:"1px 4px",borderRadius:2,background:C.c+"10",color:C.c}}>canvas</span>}
        </div>
      </div>;})}
    </div>
  </div>}

  <div style={{fontSize:10,color:C.gold,textTransform:"uppercase",letterSpacing:"0.08em",fontWeight:700,marginBottom:6}}>Tool Execution Log ({toolLog.length})</div>
  {toolLog.length===0&&<div style={{fontSize:12,color:C.tx3,textAlign:"center",padding:20}}>No tool executions yet. Chat with an agent to see their actions here.</div>}
  {toolLog.map(function(tc,i){return <div key={i} style={{padding:"6px 8px",background:C.bg,borderRadius:3,marginBottom:3,border:"1px solid "+(tc.status==="executed"?C.g+"20":tc.status==="denied"?C.r+"20":C.a+"20")}}>
    <div style={{display:"flex",alignItems:"center",gap:6}}>
      <span style={{width:5,height:5,borderRadius:"50%",background:tc.status==="executed"?C.g:tc.status==="denied"?C.r:C.a}}/>
      <span style={{fontSize:12,fontWeight:600,color:C.tx,fontFamily:"'JetBrains Mono',monospace"}}>{tc.tool}</span>
      <span style={{fontSize:9,color:C.tx3}}>{tc.status}</span>
    </div>
    {tc.input&&<div style={{fontSize:10,color:C.tx2,marginTop:2,fontFamily:"'JetBrains Mono',monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{tc.input}</div>}
    {tc.output&&<div style={{fontSize:10,color:C.tx3,marginTop:1,fontFamily:"'JetBrains Mono',monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{tc.output}</div>}
  </div>;})}
</div>
</>}
*/
