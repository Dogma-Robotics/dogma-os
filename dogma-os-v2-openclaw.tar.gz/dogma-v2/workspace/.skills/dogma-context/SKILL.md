---
name: dogma-context
description: Injects DOGMA Robotics domain data (subsystems, tasks, pilots, etc.) into the agent context
version: 1.0.0
---

# DOGMA Context Skill

When this skill is active, the agent has access to DOGMA Robotics' operational data.

## Data Sources

The DOGMA Control OS exposes a REST API at the configured base URL:

- `GET /api/dashboard/summary` — Full dashboard snapshot (subsystems, tasks, pilots, investors, incidents, fleet, milestones, experiments, finance, supply chain)
- `GET /api/entities?type=tasks` — List entities by type
- `POST /api/entities` — CRUD operations on entities
- `POST /api/commands` — Execute domain commands (create_task, update_task_status, etc.)

## Entity Types

| Entity | Description | Key Fields |
|--------|-------------|------------|
| subsystems | Hardware components (Bone Structure, Tendon Network, etc.) | name, maturity_level (0-100), status, version |
| skills | Grasp primitives (Pinch, Power, Precision, etc.) | name, success_rate, tests_count, gaps |
| tasks | Work items across workspaces | title, status (todo/progress/blocked/done), priority, workspace |
| pilots | Manufacturing company pipeline | company_name, stage, viability_score, champion_name |
| investors | Fundraising pipeline | fund_name, stage, probability, check_size |
| incidents | Issues and outages | title, severity, status, root_cause |
| fleet | Robot units | unit_name, status, health, hours |
| milestones | Project milestones | title, progress, target_date, risk_level |
| experiments | R&D experiments | title, outcome, confidence, parameters |

## Usage

When answering questions about DOGMA, reference the injected context data. When making changes, use the commands API.

For file-based operations, the DOGMA OS codebase is typically at `~/Projects/dogma-os/` or the current working directory.
