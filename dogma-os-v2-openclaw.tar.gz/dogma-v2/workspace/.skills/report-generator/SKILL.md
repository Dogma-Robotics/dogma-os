---
name: report-generator
description: Generate richly styled HTML reports, CSV exports, and JSON data files with DOGMA branding
version: 1.0.0
---

# Report Generator Skill

Generate professional documents with DOGMA Robotics branding.

## HTML Reports

When creating HTML reports, use this CSS palette:

```css
:root {
  --gold: #C8A74B;
  --bg: #0A0A18;
  --bg2: #0E0E20;
  --bg3: #141428;
  --bd: #1A1A35;
  --tx: #E8E6E0;
  --tx2: #9994B0;
  --green: #2D7A5D;
  --red: #8A3333;
  --amber: #A78530;
  --blue: #3A5A7A;
}
```

Fonts: `Inter` for body, `JetBrains Mono` for code and data.

### Available CSS Classes

- `<span class="badge pass">` / `fail` / `warn` / `info` — Status badges
- `<div class="metric-grid"><div class="metric-card">` — KPI grid
- `<div class="progress-bar"><div class="progress-fill" style="width:75%">` — Progress bars
- `<div class="callout critical">` / `success` / `info` / `warning` — Callout boxes
- `<div class="kpi-row"><div class="kpi">` — KPI row
- `<div class="card">` — Content cards

### File Naming

Save reports to the project's `public/generated/` directory or use the artifacts API:

```bash
# Save locally
echo "$HTML_CONTENT" > public/generated/report_$(date +%s).html

# Or use the DOGMA artifacts API
curl -X POST http://localhost:3000/api/artifacts \
  -H "Content-Type: application/json" \
  -d '{"title": "My Report", "content": "...", "visibility": "internal"}'
```

## CSV Exports

Use UTF-8 BOM prefix for Excel compatibility:

```bash
echo -e '\xEF\xBB\xBF'"Header1,Header2\nVal1,Val2" > export.csv
```

## JSON Data

Pretty-print with 2-space indentation. Include metadata:

```json
{
  "generated_at": "2026-03-22T12:00:00Z",
  "generated_by": "dogma-agent",
  "data": { ... }
}
```
