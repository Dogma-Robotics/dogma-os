'use client'
import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import dynamic from "next/dynamic";
var THREE = typeof window !== "undefined" ? require("three") : null;

var C={bg:"#030308",bg1:"#060610",bg2:"#0A0A18",bg3:"#0E0E20",bd:"#1A1A35",gold:"#C8A74B",gD:"rgba(200,167,75,0.06)",tx:"#C8C4BC",tx2:"#6E6A84",tx3:"#444060",g:"#2D7A5D",r:"#8A3333",a:"#A78530",b:"#3A5A7A",c:"#3A7A7A"};
var nw=function(){return new Date().toLocaleString("en-US",{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"});};
var dy=function(){return new Date().toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"});};
function dc(s){return"pass validated active resolved low done".split(" ").indexOf(s)>=0?C.g:"fail blocked critical open high".split(" ").indexOf(s)>=0?C.r:"partial testing progress medium investigating iterating dev build progressing".split(" ").indexOf(s)>=0?C.a:C.b;}
function Dot({s}){return <span style={{display:"inline-block",width:8,height:8,borderRadius:"50%",background:dc(s),flexShrink:0}}/>;}
function Tag({children,color}){var c=color||C.tx2;return <span style={{display:"inline-flex",padding:"3px 8px",fontSize:12,fontFamily:"'JetBrains Mono',monospace",borderRadius:3,background:c+"0C",color:c,border:"1px solid "+c+"15",whiteSpace:"nowrap"}}>{children}</span>;}
function PB({val,w,color}){return <div style={{width:w||60,height:6,background:C.bd,borderRadius:3,overflow:"hidden",display:"inline-block",verticalAlign:"middle"}}><div style={{width:Math.min(val||0,100)+"%",height:"100%",background:color||C.gold,borderRadius:3}}/></div>;}
function Btn({children,onClick,v}){var m={default:[C.bg3,C.tx2,C.bd],gold:[C.gD,C.gold,C.gold+"22"],success:["rgba(45,122,93,0.08)",C.g,C.g+"22"]};var s=m[v||"default"]||m["default"];return <button onClick={onClick} style={{padding:"6px 16px",fontSize:13,fontWeight:600,textTransform:"uppercase",background:s[0],color:s[1],border:"1px solid "+s[2],borderRadius:3,cursor:"pointer"}}>{children}</button>;}
function Sec({children}){return <div style={{fontSize:11,color:C.gold,textTransform:"uppercase",letterSpacing:"0.12em",fontWeight:700,marginTop:14,marginBottom:6,borderBottom:"1px solid "+C.bd,paddingBottom:4}}>{children}</div>;}
function Row({label,value,color,canEdit,onSave}){
  var _e=useState(false),editing=_e[0],setEditing=_e[1];
  var _v=useState(String(value||"")),val=_v[0],setVal=_v[1];
  useEffect(function(){setVal(String(value||""));},[value]);
  var save=function(){if(onSave)onSave(val);setEditing(false);};
  return <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"5px 0",fontSize:14,borderBottom:"1px solid "+C.bd+"40",gap:8}}>
    <span style={{color:C.tx2,flexShrink:0}}>{label}</span>
    {editing?<div style={{display:"flex",gap:3,flex:1,justifyContent:"flex-end"}}><input value={val} onChange={function(e){setVal(e.target.value);}} onKeyDown={function(e){if(e.key==="Enter")save();if(e.key==="Escape")setEditing(false);}} autoFocus style={{width:"100%",maxWidth:180,padding:"2px 6px",fontSize:13,background:C.bg,border:"1px solid "+C.gold+"40",borderRadius:2,color:C.tx,outline:"none",fontFamily:"'JetBrains Mono',monospace",textAlign:"right"}}/><span onClick={save} style={{cursor:"pointer",color:C.g,fontSize:11}}>OK</span></div>
    :<div style={{display:"flex",alignItems:"center",gap:4}}>
      <span style={{color:color||C.tx,fontFamily:"'JetBrains Mono',monospace"}}>{value}</span>
      {canEdit&&onSave&&<span onClick={function(){setEditing(true);}} style={{cursor:"pointer",color:C.tx3,fontSize:10,opacity:0.6}}>&#9998;</span>}
    </div>}
  </div>;
}
function EList({items,canEdit,onUpdate,color}){
  var _adding=useState(false),adding=_adding[0],setAdding=_adding[1];
  var _nv=useState(""),nv=_nv[0],setNv=_nv[1];
  var addItem=function(){if(nv.trim()&&onUpdate){onUpdate(items.concat([nv.trim()]));setNv("");setAdding(false);}};
  var removeItem=function(idx){if(onUpdate){var a=items.slice();a.splice(idx,1);onUpdate(a);}};
  var editItem=function(idx,val){if(onUpdate){var a=items.slice();a[idx]=val;onUpdate(a);}};
  return <div>{(items||[]).map(function(x,i){return <EListItem key={i} text={x} color={color} canEdit={canEdit} onEdit={function(v){editItem(i,v);}} onRemove={function(){removeItem(i);}}/>;})}{canEdit&&!adding&&<div onClick={function(){setAdding(true);}} style={{fontSize:12,color:C.gold,cursor:"pointer",padding:"3px 0",opacity:0.7}}>+ Add item</div>}{canEdit&&adding&&<div style={{display:"flex",gap:3,marginTop:2}}><input value={nv} onChange={function(e){setNv(e.target.value);}} onKeyDown={function(e){if(e.key==="Enter")addItem();if(e.key==="Escape")setAdding(false);}} autoFocus placeholder="New item..." style={{flex:1,padding:"3px 6px",fontSize:13,background:C.bg,border:"1px solid "+C.gold+"40",borderRadius:2,color:C.tx,outline:"none"}}/><span onClick={addItem} style={{cursor:"pointer",color:C.g,fontSize:12}}>OK</span></div>}</div>;
}
function EListItem({text,color,canEdit,onEdit,onRemove}){
  var _e=useState(false),ed=_e[0],setEd=_e[1];
  var _v=useState(text),v=_v[0],setV=_v[1];
  useEffect(function(){setV(text);},[text]);
  if(ed)return <div style={{display:"flex",gap:3,padding:"2px 0"}}><input value={v} onChange={function(e){setV(e.target.value);}} onKeyDown={function(e){if(e.key==="Enter"){onEdit(v);setEd(false);}if(e.key==="Escape")setEd(false);}} autoFocus style={{flex:1,padding:"2px 6px",fontSize:13,background:C.bg,border:"1px solid "+C.gold+"40",borderRadius:2,color:C.tx,outline:"none"}}/><span onClick={function(){onEdit(v);setEd(false);}} style={{cursor:"pointer",color:C.g,fontSize:11}}>OK</span></div>;
  return <div style={{display:"flex",alignItems:"center",gap:4,padding:"3px 0",fontSize:14,color:color||C.tx}}>
    <span style={{flex:1}}>- {text}</span>
    {canEdit&&<span onClick={function(){setEd(true);}} style={{cursor:"pointer",color:C.tx3,fontSize:10,opacity:0.6}}>&#9998;</span>}
    {canEdit&&<span onClick={onRemove} style={{cursor:"pointer",color:C.r,fontSize:10,opacity:0.6}}>x</span>}
  </div>;
}
function EText({text,canEdit,onSave}){
  var _e=useState(false),ed=_e[0],setEd=_e[1];
  var _v=useState(text||""),v=_v[0],setV=_v[1];
  useEffect(function(){setV(text||"");},[text]);
  if(ed)return <div><textarea value={v} onChange={function(e){setV(e.target.value);}} rows={3} style={{width:"100%",padding:"6px 8px",fontSize:13,background:C.bg,border:"1px solid "+C.gold+"40",borderRadius:3,color:C.tx,outline:"none",resize:"vertical",fontFamily:"inherit"}}/><div style={{display:"flex",gap:4,marginTop:2}}><span onClick={function(){if(onSave)onSave(v);setEd(false);}} style={{cursor:"pointer",color:C.g,fontSize:12}}>Save</span><span onClick={function(){setV(text||"");setEd(false);}} style={{cursor:"pointer",color:C.tx3,fontSize:12}}>Cancel</span></div></div>;
  return <div style={{position:"relative"}}><div style={{fontSize:14,color:C.tx,lineHeight:1.6}}>{text}</div>{canEdit&&<span onClick={function(){setEd(true);}} style={{position:"absolute",top:0,right:0,cursor:"pointer",color:C.tx3,fontSize:10,opacity:0.6}}>&#9998;</span>}</div>;
}
function NoteBox({notes,onAdd}){var ref=useRef(null);var go=function(){if(ref.current&&ref.current.value.trim()){onAdd(ref.current.value.trim());ref.current.value="";}};return <div style={{marginTop:10}}><Sec>Notes ({(notes||[]).length})</Sec>{(notes||[]).map(function(n,i){return <div key={i} style={{padding:"6px 8px",background:C.bg,borderRadius:3,marginBottom:3,borderLeft:"2px solid "+C.gold+"20",fontSize:13,color:C.tx,lineHeight:1.5}}>{n.t}<div style={{fontSize:11,color:C.tx3,marginTop:2}}>{n.by} - {n.at}</div></div>;})}<div style={{display:"flex",gap:4,marginTop:4}}><input ref={ref} placeholder="Add note..." style={{flex:1,padding:"6px 10px",fontSize:13,background:C.bg,border:"1px solid "+C.bd,borderRadius:3,color:C.tx,outline:"none"}} onKeyDown={function(e){if(e.key==="Enter")go();}}/><Btn v="gold" onClick={go}>+</Btn></div></div>;}

// File upload component per node
function FileUpload({nodeId,files,onUpload,onRemove}){
  var nodeFiles=(files[nodeId]||[]);
  var inputRef=useRef(null);
  var handleFile=function(e){
    var f=e.target.files;if(!f||!f.length)return;
    for(var i=0;i<f.length;i++){
      var file=f[i];var reader=new FileReader();
      reader.onload=function(ev){
        onUpload(nodeId,{name:file.name,size:file.size,type:file.type,data:ev.target.result,at:nw()});
      };
      reader.readAsDataURL(file);
    }
    e.target.value="";
  };
  return(<div style={{marginTop:10}}>
    <Sec>Files ({nodeFiles.length})</Sec>
    {nodeFiles.map(function(f,i){return <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"6px 8px",background:C.bg,borderRadius:3,marginBottom:3,border:"1px solid "+C.bd}}>
      <span style={{fontSize:16}}>{f.type&&f.type.indexOf("image")>=0?"\uD83D\uDDBC":f.type&&f.type.indexOf("pdf")>=0?"\uD83D\uDCC4":"\uD83D\uDCC1"}</span>
      <div style={{flex:1}}><div style={{fontSize:13,color:C.tx}}>{f.name}</div><div style={{fontSize:10,color:C.tx3}}>{(f.size/1024).toFixed(1)}KB - {f.at}</div></div>
      {f.type&&f.type.indexOf("image")>=0&&<img src={f.data} style={{width:40,height:40,objectFit:"cover",borderRadius:3,border:"1px solid "+C.bd}}/>}
      <span onClick={function(){onRemove(nodeId,i);}} style={{cursor:"pointer",color:C.tx3,fontSize:14}}>x</span>
    </div>;})}
    <input ref={inputRef} type="file" multiple style={{display:"none"}} onChange={handleFile}/>
    <div onClick={function(){inputRef.current.click();}} style={{padding:"8px 12px",border:"1px dashed "+C.bd,borderRadius:3,textAlign:"center",cursor:"pointer",fontSize:13,color:C.tx3,marginTop:4}}>+ Upload files</div>
  </div>);
}

function seed(){return{
ss:[
{id:"ss1",name:"Bone Structure",mat:82,status:"validated",ver:"v3.2",owner:"Jero",issues:1,lastTest:"Mar 7",d:["Joint tolerance 0.1mm","PLA+ material, optimized for injection molding","10K cycle fatigue tested - all joints passed","27 phalanges across 5 fingers","DFM analysis complete - mold cost estimated $12K","Weight per phalanx: 2.3g average"],risks:["Material fatigue at sustained >45C operation","Injection mold tooling lead time 8 weeks","PLA+ not suitable for food-contact applications"],notes:[{t:"DFM review with Protolabs completed. Ready for quoting.",by:"JM",at:"Mar 5"}]},
{id:"ss2",name:"Tendon Network",mat:68,status:"testing",ver:"v2.8",owner:"Jero",issues:3,lastTest:"Mar 14",d:["Dyneema PE 0.5mm braided line","108 tendon routes mapped across hand","PTFE pulley sleeves on all contact points","Crimped terminations rated to 30N","Max operational tension 25N per tendon","Tendon routing jig designed for repeatability"],risks:["Pulley contact wear observable at 500+ cycles","Routing complexity increases assembly time to 4hr/hand","Dyneema stretch under sustained load not characterized"],notes:[]},
{id:"ss3",name:"Ligament System",mat:55,status:"iterating",ver:"v2.1",owner:"Jero",issues:5,lastTest:"Mar 6",d:["Silicone elastomer bands for passive joint limits","Ecoflex 00-30 Shore A material","Tension calibration per-joint required","Provides natural return force on all joints"],risks:["Stiffness variance 15% batch-to-batch","UV degradation after 6mo exposure","Calibration not yet automated"],notes:[]},
{id:"ss4",name:"McKibben Actuators",mat:74,status:"validated",ver:"v4.0",owner:"Jero",issues:2,lastTest:"Mar 13",d:["6mm outer diameter pneumatic muscle","40 PSI maximum operating pressure","27 actuators per hand assembly","Rubber bladder inner tube","Braided nylon mesh sleeve","Contraction ratio 22% at 40PSI","Response time <50ms to 90% force"],risks:["Single-source bladder supplier in Shenzhen","Fatigue failure observed at 800+ cycles on 3 units","Hysteresis 3% - within spec but monitor"],notes:[{t:"Batch #4 received. 2 units failed incoming QC.",by:"JM",at:"Mar 10"}]},
{id:"ss5",name:"Tactile Sensors",mat:61,status:"testing",ver:"v2.5",owner:"Jero",issues:4,lastTest:"Mar 11",d:["FSR 402 force-sensing resistors","Per-phalanx coverage - 27 sensors total","EWMA smoothing filter in firmware","I2C bus multiplexed via TCA9548A","Range: 0.2N to 20N","Resolution: ~0.1N at 5N midpoint"],risks:["Temperature drift 8% over 4hr at 22-28C","FSR 402 backordered 2 weeks from Interlink","No redundancy - single sensor failure = blind phalanx"],notes:[{t:"Drift confirmed correlating with PCB temp rise.",by:"JM",at:"Mar 11"}]},
{id:"ss6",name:"Wrist Assembly",mat:45,status:"iterating",ver:"v1.9",owner:"Jero",issues:6,lastTest:"Mar 9",d:["2-DOF wrist: flexion/extension + radial/ulnar","Current flexion range: 40deg (target: 65deg)","Central cable passthrough for tendon routing","Coupled ligament mechanism for stability"],risks:["Flexion range 38% below target","Ligament coupling adds unwanted constraint","Cable routing through wrist is assembly bottleneck"],notes:[{t:"EXP-044 failed. Need v2.2 ligament design.",by:"JM",at:"Mar 9"}]},
{id:"ss7",name:"Control M0-M4",mat:78,status:"validated",ver:"v5.1",owner:"Jero",issues:2,lastTest:"Mar 8",d:["Force-first control architecture","Position fallback mode for non-contact moves","1KHz real-time control loop","ROS 2 Jazzy integration via rosbridge","5 grasp primitives implemented","Impedance control on all fingers"],risks:["Latency spikes to 3ms under full sensor load","ROS 2 bridge adds 0.5ms overhead"],notes:[]},
{id:"ss8",name:"Control M5-M9",mat:52,status:"dev",ver:"v3.0",owner:"Jero",issues:8,lastTest:"Mar 3",d:["Predictive grasp planning layer","Sensor fusion input pipeline","Reinforcement learning module prototype","Sim-to-real transfer pipeline (Isaac Gym)","Grasp quality prediction from tactile"],risks:["Sim-to-real gap not quantified","Training data insufficient for generalization","Compute requirements may exceed edge budget"],notes:[]},
{id:"ss9",name:"Firmware",mat:70,status:"testing",ver:"v2.3",owner:"Jero",issues:3,lastTest:"Mar 3",d:["ESP32-S3 dual-core platform","I2C bus master for all sensors","1KHz ADC sampling on force channels","OTA firmware update capability","Watchdog timer for safety","CAN bus interface for arm communication"],risks:["OTA update reliability in production unclear","Memory usage at 78% - limited headroom"],notes:[]},
{id:"ss10",name:"Sensor Fusion",mat:38,status:"dev",ver:"v1.4",owner:"Jero",issues:7,lastTest:"Mar 5",d:["Multi-modal: tactile + force + position + current","Target end-to-end latency: 5ms","Kalman filter for state estimation","Currently measuring 8ms average","3-modality fusion operational","Contact detection confidence: 85%"],risks:["3ms above latency target","Per-unit calibration required","No online recalibration capability"],notes:[]}
],
skills:[
{id:"sk1",name:"Pinch Grasp",success:92,status:"validated",tests:48,lastTest:"Mar 10",protocol:"10 object types (sphere, cylinder, cube, irregular), force range 5-15N, slip detection active, 3 trials per object",gaps:["Small objects <5mm diameter untested","Wet/slippery surfaces not characterized"],notes:[]},
{id:"sk2",name:"Power Grasp",success:96,status:"validated",tests:62,lastTest:"Mar 8",protocol:"Cylinders 40-120mm diameter, 25N sustained force, dynamic force adjustment, hold duration 30s min",gaps:[],notes:[]},
{id:"sk3",name:"Key Grasp",success:68,status:"testing",tests:24,lastTest:"Mar 9",protocol:"Standard key insertion into lock, lateral pinch force 8N, torque application for turning",gaps:["Wrist flexion limits approach angle for horizontal locks","Alignment reliability 72% on first attempt"],notes:[]},
{id:"sk4",name:"Pick-Place",success:88,status:"validated",tests:55,lastTest:"Mar 7",protocol:"Structured bin (sorted) and unstructured bin (random), target speed 12 picks/min, accuracy >95%",gaps:["Unstructured bin accuracy only 78%","Speed drops to 8/min for irregular objects"],notes:[]},
{id:"sk5",name:"Screw Drive",success:45,status:"dev",tests:12,lastTest:"Mar 4",protocol:"M3-M6 machine screws, torque control 0.1-1.5 Nm, alignment verification via force feedback",gaps:["Wrist blocks optimal approach angle for vertical screws","Torque sensing noise floor too high for M3"],notes:[]},
{id:"sk6",name:"Assembly",success:38,status:"dev",tests:8,lastTest:"Mar 1",protocol:"Snap fit connectors, press fit bearings, multi-step assembly sequences up to 5 operations",gaps:["Multi-step sequencing fails at step 3+","Force feedback latency causes overshoot on press fits"],notes:[]}
],
exps:[
{id:"EXP-047",title:"Tendon tension calibration under cyclic load",outcome:"pass",conf:4,date:"Mar 14",notes:[],p:["Load range: 0-25N sinusoidal","Cycles: 500 at 2Hz","Temperature: 22C controlled","Measurement: inline load cell"],conclusion:"All 108 tendons maintained tension within 5% of target after 500 cycles. No observable wear on PTFE sleeves. Crimps held at 30N proof load."},
{id:"EXP-046",title:"McKibben pressure response characterization",outcome:"pass",conf:5,date:"Mar 13",notes:[],p:["Pressure: 0-40 PSI ramp","Response time measurement","Hysteresis quantification"],conclusion:"Response time 42ms to 90% force. Hysteresis 3.1%. Both within spec. Ready for integration testing."},
{id:"EXP-045",title:"Tactile sensor drift over 4hr continuous contact",outcome:"partial",conf:3,date:"Mar 11",notes:[{t:"Drift correlates strongly with PCB temperature rise from 22C to 28C over 4 hours.",by:"JM",at:"Mar 11"}],p:["Duration: 4 hours continuous","Contact: static 10N load","Temp: ambient start 22C, measured 28C at 4hr","Sensor: FSR 402 on phalanx 3"],conclusion:"PARTIAL. Drift exceeds 8% after 2hr mark. Root cause identified as temperature coefficient of FSR resistance. EWMA thermal compensation algorithm designed but not yet implemented."},
{id:"EXP-044",title:"Wrist flexion range with v2.1 ligament",outcome:"fail",conf:4,date:"Mar 9",notes:[{t:"Ligament v2.1 too stiff. Need softer durometer or different geometry.",by:"JM",at:"Mar 9"}],p:["Range: flexion/extension measurement","Ligament: v2.1 Ecoflex 00-30","Load: none (free motion)","Measurement: goniometer"],conclusion:"FAIL. Achieved 40deg flexion vs 65deg target. Ligament v2.1 excessively constrains motion. Recommend redesign with lower durometer (00-20) or reduced cross-section."},
{id:"EXP-043",title:"Force-first grasp on cylinder test set",outcome:"pass",conf:5,date:"Mar 8",notes:[],p:["Objects: 10 cylinders 50-120mm diameter","Force: 5-25N adaptive range","Controller: M0-M4 force-first mode"],conclusion:"All 10 objects grasped successfully on first attempt. Force profiles clean with <5% overshoot. Slip detection triggered correctly on 2 objects."},
{id:"EXP-041",title:"Sensor fusion end-to-end latency",outcome:"partial",conf:3,date:"Mar 5",notes:[],p:["Target latency: 5ms end-to-end","Modalities: tactile + force + position","Fusion: Kalman filter v1.4"],conclusion:"PARTIAL. Measured 8.2ms average, 3.2ms above target. Bottleneck identified in I2C read cycle. Optimization path: batch sensor reads + DMA transfer. Estimated improvement: 2-3ms."}
],
tasks:[
{id:"t1",title:"Tactile sensor drift root cause + fix",ws:"R&D",status:"progress",pri:"critical",due:"Mar 16",owner:"Jero",created:"Mar 13",notes:[{t:"Suspect temp coefficient of FSR. Need controlled thermal test.",by:"JM",at:"Mar 14"}],blocked:"",sb:["Build thermal test chamber with Peltier control","Run 4hr baseline at fixed 22C","Implement EWMA thermal compensation in FW","Validate drift <2% over 4hr with compensation"],impact:"Blocks tactile sensor validation -> blocks QC skill -> blocks Modelo and Amazon pilots -> blocks first proposal"},
{id:"t2",title:"Finalize pitch deck v3 for Eclipse",ws:"Fund",status:"progress",pri:"high",due:"Mar 15",owner:"Jero",created:"Mar 12",notes:[],blocked:"",sb:["Update traction metrics with latest experiment results","Record 30-second grasp demo video","Add Mexico nearshoring market size slide","Review with Residency mentor"],impact:"Required for Eclipse Ventures meeting on Mar 16. They requested live demo evidence."},
{id:"t3",title:"ISO/TS 15066 gap analysis",ws:"Safety",status:"todo",pri:"critical",due:"Mar 18",owner:"Jero",created:"Mar 10",notes:[],blocked:"",sb:["Purchase and download ISO/TS 15066:2016","Map all collaborative robot requirements","Cross-reference with current DOGMA capabilities","Write gap report with remediation timeline"],impact:"Blocks Amazon MX pilot (requires cobot compliance) -> blocks first pilot proposal -> weakens fundraising narrative"},
{id:"t4",title:"Order McKibben actuator batch #5",ws:"Builds",status:"todo",pri:"high",due:"Mar 17",owner:"Jero",created:"Mar 14",notes:[],blocked:"",sb:["Finalize updated spec sheet with 500-cycle inspection","Send PO to Shenzhen supplier","Track 4-week shipping timeline"],impact:"Blocks v0.7 Genesis Hand assembly -> blocks 6-skill validation milestone"},
{id:"t5",title:"Modelo factory bottleneck analysis",ws:"Pilots",status:"todo",pri:"high",due:"Mar 18",owner:"Jero",created:"Mar 11",notes:[],blocked:"",sb:["Map all bottleneck stations on Line 3","Measure cycle times for palletizing operations","Document conveyor layout and dimensions","Draft preliminary ROI estimate"],impact:"Required for first pilot proposal to Modelo"},
{id:"t6",title:"GH-DEV-B actuator #4 replacement",ws:"Fleet",status:"blocked",pri:"medium",due:"Mar 15",owner:"Jero",created:"Mar 12",notes:[],blocked:"Replacement bladders on order. ETA 5 business days from Mar 13.",sb:["Remove failed actuator #4 assembly","Install new bladder","Run 40PSI pressure test for 1hr","Return to service"],impact:"DEV-B offline reduces test throughput by 50%. Blocking tactile drift experiments."},
{id:"t7",title:"Validate lateral key grasp skill",ws:"Skills",status:"todo",pri:"high",due:"Mar 19",owner:"Jero",created:"Mar 13",notes:[],blocked:"",sb:["Build key insertion test fixture","Record force profile during insertion","Run 10-trial validation protocol","Document success rate and failure modes"],impact:"Required for 6-skill validation milestone (ms2)"},
{id:"t8",title:"Build pilot ROI model template",ws:"Pilots",status:"todo",pri:"high",due:"Mar 20",owner:"Jero",created:"Mar 14",notes:[],blocked:"",sb:["Design spreadsheet with labor cost inputs","Build payback period calculator","Add sensitivity analysis for utilization rate"],impact:"Required template for all pilot proposals"}
],
pilots:[
{id:"p1",name:"Cerveceria Modelo",stage:"Line Analysis",viab:82,roi:"$180K/yr",champ:"Carlos Vega - Operations Director",champStr:"Strong",plant:"GDL Brewery #2",plc:"Siemens S7-1500",pain:"Manual palletizing creates bottleneck on Line 3. 3 operators per shift, high turnover. QC inconsistency on final inspection.",skills:["Palletize","QC Inspection"],comp:["ISO 10218-1","NOM-004 STPS"],notes:[{t:"Strong internal champion. Budget authority confirmed. 3 shifts = 9 operator positions addressable.",by:"JM",at:"Mar 12"},{t:"Conveyor layout mapped. 3 palletizing stations on Line 3. Speed: 12 boxes/min per station.",by:"JM",at:"Mar 5"}],risk:"medium",qs:["Union approval process and timeline?","Shift transition protocol?","Conveyor speed adjustment capability?","Budget cycle - when is next capex window?"],nextStep:"Complete bottleneck mapping and cycle time analysis for Line 3",fu:"Mar 18",meetings:[{d:"Mar 5",n:"Initial plant tour with Carlos. 3 stations identified on Line 3."},{d:"Mar 12",n:"Detailed line walk. Conveyor layout and dimensions documented."}],blockers:[]},
{id:"p2",name:"Amazon MX - Cuautitlan",stage:"Site Visit",viab:88,roi:"$250K/yr",champ:"TBD - pursuing via introduction",champStr:"Weak",plant:"Cuautitlan Fulfillment Center",plc:"Proprietary / Kiva",pain:"Mixed SKU variety in pick stations causing 4.2% error rate. 55% annual picker turnover drives retraining costs.",skills:["Unstructured Pick","QC Tactile Inspection"],comp:["ISO 10218-1","ISO/TS 15066"],notes:[{t:"Highest ROI opportunity in pipeline. Key blocker is cobot safety compliance for human proximity zones.",by:"JM",at:"Mar 10"}],risk:"high",qs:["Human proximity zone layout and dimensions?","Kiva system integration path?","Pick error tolerance threshold?","Safety pre-assessment process and timeline?"],nextStep:"Conduct ISO/TS 15066 pre-assessment before requesting line access",fu:"Mar 17",meetings:[],blockers:["ISO/TS 15066 compliance gap unresolved","No internal champion identified yet"]},
{id:"p3",name:"Foxconn - Juarez",stage:"Identified",viab:90,roi:"$400K+/yr",champ:"TBD",champStr:"None",plant:"Juarez Electronics Assembly",plc:"Siemens / Mitsubishi",pain:"Precision PCB component assembly at volume. Current 2.1% defect rate on fine-pitch placements.",skills:["Precision Pinch","Screw Drive","Snap Fit Assembly"],comp:["ISO 10218-1","ISO 10218-2"],notes:[],risk:"high",qs:["Contact pathway - CAINTRA introduction or Residency network?","Monthly production volume?","PCB form factors and component sizes?","Current defect tolerance vs target?"],nextStep:"Establish initial contact through CAINTRA or Residency",fu:"Mar 25",meetings:[],blockers:["No contact established","Requires screw drive skill (currently 45% success)","Requires assembly skill (currently 38% success)"]},
{id:"p4",name:"Grupo Bimbo - Toluca",stage:"Auto Score",viab:71,roi:"$95K/yr",champ:"Luis Mendez - Production Lead",champStr:"Medium",plant:"Toluca Bakery #1",plc:"Allen-Bradley",pain:"Packaging line product damage rate of 3.5%. Manual handling of fragile baked goods causes deformation.",skills:["Gentle Pick-Place"],comp:["ISO 10218-1","NOM-004 STPS"],notes:[],risk:"low",qs:["Food-safe material certification requirements?","Line speed target for automated packaging?"],nextStep:"Prepare preliminary proposal with ROI model",fu:"Mar 19",meetings:[{d:"Feb 28",n:"Initial call with Luis. Interest confirmed."},{d:"Mar 10",n:"Packaging line flow mapped. 3.5% damage rate confirmed."}],blockers:[]}
],
investors:[
{id:"inv1",name:"Y Combinator",stage:"Researched",prob:15,check:"$500K",next:"Apply for S25 batch",nextDate:"Mar 20",notes:[],tp:["YC website and thesis review","S25 batch timeline confirmed: apply by Apr 15","Partner research: Jared Friedman covers hardware"],thesis:"Deep tech hardware + Mexico nearshoring angle aligns with international expansion thesis",objections:["Pre-revenue stage concern","Hardware company risk profile","Small team size"]},
{id:"inv2",name:"Khosla Ventures",stage:"Warm Intro",prob:20,check:"$1-2M",next:"Follow up on deck review",nextDate:"Mar 18",notes:[{t:"Intro email sent via Residency SF contact. Deck v2 attached.",by:"JM",at:"Mar 8"}],tp:["Intro email sent Mar 8","Pitch deck v2 shared","Awaiting partner response"],thesis:"Industrial automation and workforce transformation thesis. Strong interest in manufacturing robotics.",objections:["Stage too early for typical Khosla check","Want to see working demo before meeting"]},
{id:"inv3",name:"Eclipse Ventures",stage:"1st Meeting",prob:35,check:"$500K-1M",next:"Prepare live demo for follow-up",nextDate:"Mar 16",notes:[{t:"Strong interest in nearshoring thesis. Partner asked for live grasp demonstration at next meeting.",by:"JM",at:"Mar 12"}],tp:["Intro call - 15 min overview","30-min technical deep dive with partner","Live demo requested for next meeting","Pitch deck v2 sent"],thesis:"Industrial deep tech thesis match. Nearshoring angle resonates strongly with their Mexico investment thesis.",objections:["Need to see live hardware demonstration","Want evidence of pilot LOI or strong interest"]},
{id:"inv4",name:"The Residency SF",stage:"Active",prob:40,check:"Strategic intros",next:"Weekly office hours + new VC intros",nextDate:"Mar 21",notes:[{t:"2 new VC introductions generated from last office hours session.",by:"JM",at:"Mar 14"}],tp:["Attended 4 weekly office hours","Generated 2 direct VC introductions","Paired with hardware startup mentor","Access to demo day pipeline"],thesis:"Network acceleration and intro generation. Not a direct investor but highest-value relationship for pipeline building.",objections:[]},
{id:"inv5",name:"Angel Syndicate MX",stage:"Warm Intro",prob:25,check:"$100-250K",next:"Send deck + schedule call",nextDate:"Mar 17",notes:[],tp:["CAINTRA business council introduction","Added to WhatsApp investor group"],thesis:"Mexico-based manufacturing innovation. Local ecosystem building.",objections:["Want to see Mexico-based customer traction before committing","Prefer post-revenue companies"]}
],
fleet:[
{id:"fl1",unit:"GH-001",type:"Genesis Hand v0.6 - Primary Prototype",status:"active",hours:342,health:92,loc:"DOGMA Lab - Main Workbench",config:"Full 27-DOF hand + UR10e arm mount",sys:["Bone structure: All joints within spec","Tendon network: All 108 routes tensioned","Tactile sensors: Phalanx 3 showing drift (INC-002)","Firmware: v2.3 running stable","McKibben actuators: All 27 operational","Wrist: v1.9 assembled, limited flexion"],lastMaint:"Mar 5 - Full tendon tension check",nextMaint:"Mar 20 - Scheduled sensor recalibration"},
{id:"fl2",unit:"GH-002",type:"Genesis Hand v0.7 - Assembly In Progress",status:"build",hours:0,health:0,loc:"DOGMA Lab - Assembly Station",config:"Updated bone design + new tendon routing",sys:["Assembly progress: 72% complete","Bone structure: All 27 phalanges printed and assembled","Tendon routing: 64/108 routes complete","Actuator installation: Waiting for batch #5","Wrist: v2.0 design pending"],lastMaint:"-",nextMaint:"-"},
{id:"fl3",unit:"DEV-A",type:"Development Rig - Actuator Testing",status:"active",hours:1240,health:78,loc:"Test Bench A",config:"4-finger subset with full actuator bank",sys:["McKibben actuators: All operational","PTFE pulley sleeves: Installed post-INC-001","High mileage: 1240 hours - approaching maintenance","Tendon inspection: Due at 1300 hours"],lastMaint:"Mar 2 - PTFE sleeve installation after INC-001",nextMaint:"Mar 16 - 1300hr tendon + pulley inspection"},
{id:"fl4",unit:"DEV-B",type:"Development Rig - Tactile Sensor Testing",status:"maintenance",hours:890,health:65,loc:"Test Bench B - Offline",config:"Full sensor array with test load fixtures",sys:["Actuator #4: Pressure leak detected (INC-003)","Awaiting replacement bladder parts - ETA Mar 18","Sensor calibration: Due when unit returns to service","Operating at 3/4 actuator capacity if needed for emergency"],lastMaint:"Mar 12 - Taken offline for INC-003",nextMaint:"Pending replacement parts arrival"}
],
incidents:[
{id:"INC-003",sev:"medium",desc:"Actuator #4 sustained pressure leak under load on DEV-B",down:"8h",root:"Rubber bladder fatigue after 800+ actuation cycles. Micro-tear at fold point.",status:"open",reported:"Mar 12 4:00 PM",notes:[{t:"Replacement bladders ordered from Shenzhen supplier. ETA 5 business days. Unit offline until repair.",by:"JM",at:"Mar 13 9:00 AM"}],acts:["Remove and replace bladder on actuator #4","Run 40PSI sustained pressure test for 1 hour","Update preventive inspection interval from 1000 to 500 cycles","Order batch of 10 spare bladders for inventory"],timeline:["Mar 12 4:00 PM - Leak detected during force calibration test","Mar 12 4:30 PM - Unit pressure tested, leak confirmed on act #4","Mar 12 5:00 PM - DEV-B taken offline, root cause investigation started","Mar 13 9:00 AM - Bladder micro-tear identified under magnification","Mar 13 2:00 PM - Replacement parts ordered, PO sent to supplier"]},
{id:"INC-002",sev:"low",desc:"Tactile sensor drift on phalanx 3 of GH-001 after 4hr continuous operation",down:"2h",root:"Temperature coefficient of FSR 402 resistance not compensated in firmware. PCB temp rises from 22C to 28C.",status:"investigating",reported:"Mar 8",notes:[],acts:["Run controlled thermal test at fixed temperature to isolate variable","Design and implement EWMA thermal compensation algorithm in firmware","Add thermal drift test to standard sensor validation protocol","Evaluate alternative sensor (FSR 406) with lower temp coefficient"],timeline:["Mar 8 - Drift first observed during EXP-045 4hr test","Mar 11 - Temperature correlation confirmed with IR thermometer","Mar 14 - Thermal compensation algorithm designed, implementation started"]},
{id:"INC-001",sev:"high",desc:"Dyneema tendon snap during 25N force test on DEV-A index finger",down:"24h",root:"Dyneema strand fraying at bare metal pulley contact point. No PTFE sleeve protection.",status:"resolved",reported:"Feb 28",notes:[{t:"Root cause confirmed. All pulleys across all units now PTFE sleeved. 200-cycle inspection protocol added.",by:"JM",at:"Mar 2"}],acts:["Replaced snapped tendon with new Dyneema strand and sleeve","PTFE sleeved ALL pulley contact points on ALL units (27 pulleys x 4 units)","Added 200-cycle tendon and pulley inspection to maintenance protocol","Updated tendon routing spec to require PTFE sleeve at every contact"],timeline:["Feb 28 10:00 AM - Tendon snap during 25N force profile test on DEV-A","Feb 28 2:00 PM - Fraying identified at index proximal pulley under microscope","Mar 1 - Root cause analysis complete, PTFE sleeve solution designed","Mar 2 9:00 AM - All pulleys sleeved on DEV-A, testing resumed","Mar 2-5 - Remaining 3 units retrofitted with PTFE sleeves"]}
],
milestones:[
{id:"ms1",title:"Genesis Hand v0.7 fully assembled",target:"Mar 30",pct:72,risk:"medium",blockers:["8 components waiting for McKibben batch #5 delivery","Wrist v2.0 redesign needed based on EXP-044 failure"],cr:["All 27 bone phalanges printed and assembled","All 108 tendons routed and tensioned to spec","All 27 McKibben actuators installed and pressure tested","Wrist mechanism integrated with full range of motion","Firmware v2.3 flashed and basic self-test passing"],deps:["t4","ss6"]},
{id:"ms2",title:"6 manipulation skills validated >80%",target:"Apr 15",pct:40,risk:"high",blockers:["Tactile sensor drift blocks sensor-dependent skills","Wrist flexion failure limits key grasp and screw drive"],cr:["Pinch grasp >90% success rate","Power grasp >95% success rate","Key grasp >80% success rate","Pick-place >90% success rate","Assembly >70% success rate","Palletize >85% success rate"],deps:["t1","t7","ss5","ss6"]},
{id:"ms3",title:"ISO/TS 15066 compliance documentation ready",target:"Apr 30",pct:60,risk:"critical",blockers:["Gap analysis not yet started - standard not purchased","No force limit validation testing done","Speed monitoring not implemented in control system"],cr:["Complete gap analysis against ISO/TS 15066:2016","Risk assessment documented per required methodology","Force limits validated for all grasp types","Speed and separation monitoring implemented","Full compliance documentation package assembled"],deps:["t3"]},
{id:"ms4",title:"First factory line analysis complete",target:"Mar 25",pct:65,risk:"low",blockers:[],cr:["All bottleneck stations mapped with process flow","Cycle times measured for target operations","Preliminary ROI estimate calculated"],deps:["t5","p1"]},
{id:"ms5",title:"First pilot proposal delivered",target:"Apr 20",pct:0,risk:"medium",blockers:["Blocked by safety compliance clearance","Blocked by completed line analysis"],cr:["ROI model complete with sensitivity analysis","Safety compliance clearance obtained","Technical deployment specification written","Implementation timeline with milestones defined"],deps:["ms3","ms4","t8"]},
{id:"ms6",title:"Pre-seed round closed",target:"Jun 30",pct:15,risk:"high",blockers:["Zero investor commitments secured to date","Need live demonstration capability","Need pilot LOI or strong customer signal"],cr:["Lead investor term sheet signed","Legal review and documentation complete","Wire transfer received and confirmed"],deps:["t2","inv3"]}
],
safety:[{id:"sf1",name:"ISO 10218-1",cov:85,gaps:["Emergency stop validation testing pending","Safety-rated controller certification needed"]},{id:"sf2",name:"ISO 10218-2",cov:60,gaps:["System integration risk assessment incomplete","Safeguard selection and validation pending"]},{id:"sf3",name:"ISO/TS 15066",cov:40,gaps:["Collaborative force limit validation not done","Speed and separation monitoring not implemented","Human proximity zone mapping needed","Power and force limiting mode not characterized"]},{id:"sf4",name:"NOM-004 STPS",cov:70,gaps:["Spanish language documentation incomplete","STPS formal registration process not started"]}],
supply:[{id:"sp1",item:"McKibben bladders",supplier:"Custom MFG Shenzhen",lead:"4 weeks",risk:"high",note:"Single source. No backup supplier identified. Critical path item."},{id:"sp2",item:"FSR 402 sensors",supplier:"Interlink Electronics",lead:"2 weeks",risk:"medium",note:"Currently backordered. Alternative: FSR 406 (higher cost, lower temp drift)."},{id:"sp3",item:"Dyneema PE line",supplier:"DSM via distributor",lead:"1 week",risk:"low",note:"Stock available at local distributor."},{id:"sp4",item:"ESP32-S3 modules",supplier:"Espressif",lead:"2 weeks",risk:"low",note:"Alternative: ESP32-WROOM-1 pin-compatible."}],
decisions:[{title:"McKibben pneumatic over electric actuators",why:"Superior compliance and force density for biomimetic grasping. 3x force-to-weight ratio.",date:"Jan 2026"},{title:"Industrial pilots before full humanoid deployment",why:"Faster path to revenue validation. Deploy Genesis Hand on existing UR10e arm platform.",date:"Feb 2026"},{title:"Mexico nearshoring as initial market entry",why:"Lower deployment cost, founder network advantage, proximity to US customers.",date:"Dec 2025"}],
fin:{burn:12500,cash:45000,runway:3.6,bom:4280,spend:[{c:"Components & Materials",a:4200},{c:"Lab & Equipment",a:2800},{c:"Software & Cloud",a:600},{c:"Travel & Site Visits",a:1800},{c:"Professional Services",a:1200},{c:"Misc Operating",a:1900}]},
log:[{t:"EXP-047 Tendon cal PASSED",at:"Mar 14 4:30PM"},{t:"Eclipse Ventures advanced to 1st Meeting",at:"Mar 14 2:30PM"},{t:"INC-003 opened: DEV-B actuator leak",at:"Mar 12 4:15PM"},{t:"Amazon MX viability updated to 88%",at:"Mar 12 11:00AM"},{t:"Pinch grasp validated at 92%",at:"Mar 10 3:00PM"},{t:"INC-001 resolved: Tendon snap fix",at:"Mar 2 5:00PM"},{t:"PTFE sleeve retrofit completed on all units",at:"Mar 5 2:00PM"}],
seq:{exp:48,inc:4,task:9},
// Causal dependency chains: source → blocks [targets]
deps:[
{from:"ss10",fromLabel:"Sensor Fusion 38%",blocks:["sk5","sk6"],reason:"Fusion latency 8ms blocks real-time force feedback for precision tasks"},
{from:"ss6",fromLabel:"Wrist Assembly 45%",blocks:["sk3","sk5"],reason:"40deg flex vs 65deg target blocks approach angles for key grasp and screw drive"},
{from:"ss5",fromLabel:"Tactile Sensors 61%",blocks:["sk4","p2"],reason:"Drift >8% after 2hr blocks sensor-dependent skills and Amazon pilot validation"},
{from:"INC-002",fromLabel:"Tactile drift INC-002",blocks:["ss5","t1"],reason:"Unresolved drift incident blocks sensor validation chain"},
{from:"INC-003",fromLabel:"Actuator leak INC-003",blocks:["fl4","t6"],reason:"DEV-B offline, reduces test throughput 50%"},
{from:"t1",fromLabel:"Tactile drift fix",blocks:["ss5","ms2"],reason:"Fix required before sensor revalidation and 6-skill milestone"},
{from:"t3",fromLabel:"ISO/TS 15066 gap",blocks:["ms3","p2","ms5"],reason:"Compliance gap blocks Amazon pilot and first proposal"},
{from:"sf3",fromLabel:"ISO/TS 15066 40%",blocks:["p2","ms3"],reason:"Lowest compliance blocks highest-ROI pilot"},
{from:"ms2",fromLabel:"6 skills validated",blocks:["ms5","p1","p3"],reason:"Skill milestone gates pilot proposals"},
{from:"ms3",fromLabel:"ISO compliance",blocks:["ms5","p2"],reason:"Compliance gates first proposal"},
],
// Incident → entity links
incLinks:{
"INC-002":{ss:["ss5"],tasks:["t1"],fleet:["fl1"],desc:"Tactile sensor drift on GH-001 phalanx 3"},
"INC-003":{ss:["ss4"],tasks:["t6"],fleet:["fl4"],desc:"Actuator #4 pressure leak on DEV-B"},
"INC-001":{ss:["ss2"],tasks:[],fleet:["fl3"],desc:"Tendon snap on DEV-A (RESOLVED)"},
},
// Pilot deadlines tied to runway
pilotDeadlines:{
"p1":{needBy:"Apr 15",reason:"Must close before next raise or runway runs out",gatedBy:["ms2","ms4"]},
"p2":{needBy:"May 1",reason:"Highest ROI but needs ISO compliance first",gatedBy:["ms3","sf3"]},
"p3":{needBy:"Jun 15",reason:"Requires screw drive + assembly skills",gatedBy:["ms2","sk5","sk6"]},
"p4":{needBy:"Apr 30",reason:"Lowest complexity, fastest to close",gatedBy:["ms4"]},
},
};}

// ── Risk Scoring Engine ──
function calcRisks(D){
  var alerts=[];
  // Runway
  if(D.fin.runway<4)alerts.push({sev:"critical",cat:"Finance",msg:"Runway "+D.fin.runway+"mo. Fundraise immediately.",score:10});
  if(D.fin.runway<2)alerts.push({sev:"critical",cat:"Finance",msg:"SURVIVAL: <2 months. All non-revenue tasks should stop.",score:15});
  // Subsystems <50%
  D.ss.forEach(function(s){if(s.mat<50)alerts.push({sev:"high",cat:"R&D",msg:s.name+" at "+s.mat+"% maturity. Blocks downstream.",score:7,id:s.id});});
  // Skills <50%
  D.skills.forEach(function(s){if(s.success<50)alerts.push({sev:"high",cat:"Skills",msg:s.name+" at "+s.success+"%. Dev priority.",score:6,id:s.id});});
  // Stalled pilots (no meetings in 14+ days)
  D.pilots.forEach(function(p){
    var lastMeet=p.meetings&&p.meetings.length>0?p.meetings[p.meetings.length-1].d:"";
    if(!lastMeet&&p.stage!=="Identified")alerts.push({sev:"medium",cat:"Pilots",msg:p.name+" has NO meetings logged. Stalled?",score:5,id:p.id});
  });
  // Open incidents
  D.incidents.forEach(function(i){if(i.status!=="resolved")alerts.push({sev:i.sev==="high"?"critical":"medium",cat:"Incidents",msg:i.id+": "+i.desc.slice(0,50),score:i.sev==="high"?8:4,id:i.id});});
  // Safety gaps
  D.safety.forEach(function(s){if(s.cov<50)alerts.push({sev:"high",cat:"Safety",msg:s.name+" at "+s.cov+"%. Blocks pilots.",score:6,id:s.id});});
  // Milestones at risk
  D.milestones.forEach(function(m){if(m.risk==="critical"||m.risk==="high")alerts.push({sev:m.risk==="critical"?"critical":"high",cat:"Roadmap",msg:m.title+" ("+m.pct+"%) — "+m.risk+" risk",score:m.risk==="critical"?8:5,id:m.id});});
  // Sort by score desc
  alerts.sort(function(a,b){return b.score-a.score;});
  return alerts;
}

// ── Dependency chain resolver ──
function getBlockedBy(entityId,deps){
  return(deps||[]).filter(function(d){return d.blocks.indexOf(entityId)>=0;});
}
function getBlocks(entityId,deps){
  return(deps||[]).filter(function(d){return d.from===entityId;});
}
var ENR=8;var NODES=[{id:"command",label:"COMMAND",pos:[0,0,0],r:1.4,center:true,color:0xC8A74B}];
var NI=["rd","experiments","incidents","fleet","pilots","fundraising","finance","team","roadmap"];
var NM=["R & D","EXPERIMENTS","INCIDENTS","FLEET","PILOTS","FUNDRAISING","FINANCE","TASKS","ROADMAP"];
var NC=[0x2D7A5D,0x3A7A7A,0x8A3333,0x3A5A7A,0xA78530,0x2D7A5D,0xA78530,0x3A5A7A,0x8A3333];
for(var _i=0;_i<9;_i++){var _a=Math.PI/2+_i*2*Math.PI/9;NODES.push({id:NI[_i],label:NM[_i],pos:[ENR*Math.cos(_a),ENR*Math.sin(_a),[0,0.4,-0.4,0.3,-0.3,0.4,-0.4,0.3,-0.3][_i]],r:[1.0,0.85,0.85,0.8,1.0,0.9,0.85,0.9,0.85][_i],color:NC[_i]});}
var LINKS=[["command","rd"],["command","experiments"],["command","incidents"],["command","pilots"],["command","fundraising"],["command","finance"],["command","team"],["command","roadmap"],["command","fleet"],["rd","experiments"],["rd","incidents"],["rd","team"],["experiments","incidents"],["incidents","fleet"],["pilots","fundraising"],["pilots","rd"],["fundraising","finance"],["finance","team"],["roadmap","team"],["roadmap","rd"],["fleet","rd"]];

function getSubs(pid,D){var R=3.5;var items=[];
if(pid==="rd"){items=D.ss.map(function(s){return{id:s.id,label:s.name,metric:s.mat+"%",color:dc(s.status),r:0.45,type:"ss",data:s};}).concat(D.skills.map(function(s){return{id:s.id,label:s.name,metric:s.success+"%",color:dc(s.status),r:0.45,type:"skill",data:s};}));}
else if(pid==="experiments"){items=D.exps.map(function(e){return{id:e.id,label:e.id,metric:e.outcome,color:dc(e.outcome),r:0.4,type:"exp",data:e};});}
else if(pid==="incidents"){items=D.incidents.map(function(i){return{id:i.id,label:i.id,metric:i.status,color:dc(i.status),r:0.4,type:"inc",data:i};});}
else if(pid==="fleet"){items=D.fleet.map(function(f){return{id:f.id,label:f.unit,metric:f.health?f.health+"%":"--",color:dc(f.status),r:0.4,type:"fl",data:f};});}
else if(pid==="pilots"){items=D.pilots.map(function(p){return{id:p.id,label:p.name,metric:p.viab+"%",color:p.viab>80?C.g:C.a,r:0.5,type:"pilot",data:p};});}
else if(pid==="fundraising"){items=D.investors.map(function(v){return{id:v.id,label:v.name,metric:v.prob+"%",color:v.prob>=30?C.g:C.a,r:0.45,type:"inv",data:v};});}
else if(pid==="team"){items=D.tasks.map(function(t){return{id:t.id,label:t.title,metric:t.pri,color:dc(t.pri),r:0.4,type:"task",data:t};});}
else if(pid==="finance"){var fi=D.fin;items=[{id:"fn_b",label:"Burn",metric:"$"+(fi.burn/1000).toFixed(1)+"K",color:C.r,r:0.45,type:"fmet",data:{n:"Monthly Burn Rate",v:"$"+(fi.burn/1000).toFixed(1)+"K/mo",d:fi.spend.map(function(s){return s.c+": $"+(s.a/1000).toFixed(1)+"K";})}},{id:"fn_c",label:"Cash",metric:"$"+(fi.cash/1000).toFixed(0)+"K",color:C.a,r:0.45,type:"fmet",data:{n:"Cash Position",v:"$"+fi.cash,d:["Current bank balance"]}},{id:"fn_r",label:"Runway",metric:fi.runway+"mo",color:fi.runway<4?C.r:C.a,r:0.45,type:"fmet",data:{n:"Runway",v:fi.runway+" months remaining",d:[fi.runway<4?"CRITICAL: Less than 4 months runway. Fundraising is survival priority.":"Manageable but tight. Monitor monthly."]}},{id:"fn_m",label:"BOM",metric:"$"+(fi.bom/1000).toFixed(1)+"K",color:C.gold,r:0.45,type:"fmet",data:{n:"BOM Cost - Genesis Hand v0.7",v:"$"+fi.bom+" per unit",d:["142 unique components","8 components pending from batch #5","Target: sub-$3K at 100-unit volume"]}}].concat(D.supply.map(function(s){return{id:s.id,label:s.item.slice(0,12),metric:s.risk,color:dc(s.risk==="high"?"critical":"active"),r:0.4,type:"sply",data:s};}));}
else if(pid==="roadmap"){items=D.milestones.map(function(m){return{id:m.id,label:m.title,metric:m.pct+"%",color:m.risk==="critical"?C.r:m.risk==="high"?C.a:C.g,r:0.45,type:"ms",data:m};}).concat(D.safety.map(function(sf){return{id:sf.id,label:sf.name,metric:sf.cov+"%",color:sf.cov>70?C.g:sf.cov>50?C.a:C.r,r:0.4,type:"safe",data:sf};}));}
var p=NODES.find(function(n){return n.id===pid;});if(!p)return[];
return items.map(function(it,i){var a=(i/items.length)*6.2832;return Object.assign({},it,{pos:[p.pos[0]+Math.cos(a)*R,p.pos[1]+Math.sin(a)*R*0.6,p.pos[2]+Math.sin(a+1)*0.7],parent:pid});});}

function getSSubs(sub){if(!sub||!sub.data)return[];var d=sub.data;var items=[];
if(sub.type==="ss")items=(d.d||[]).concat(d.risks||[]);else if(sub.type==="skill")items=(d.gaps||[]).concat(d.protocol?[d.protocol]:[]);else if(sub.type==="exp")items=(d.p||[]).concat(d.conclusion?[d.conclusion]:[]);else if(sub.type==="inc")items=(d.acts||[]).concat(d.timeline||[]);else if(sub.type==="pilot")items=(d.qs||[]).concat(d.skills||[]).concat(d.comp||[]).concat(d.blockers||[]);else if(sub.type==="inv")items=(d.tp||[]).concat(d.objections||[]);else if(sub.type==="task")items=(d.sb||[]).concat(d.impact?[d.impact]:[]);else if(sub.type==="fl")items=d.sys||[];else if(sub.type==="ms")items=(d.cr||[]).concat(d.blockers||[]);else if(sub.type==="fmet")items=d.d||[];else if(sub.type==="safe")items=d.gaps||[];else if(sub.type==="sply")items=[d.supplier||"",d.lead||"",d.note||""].filter(Boolean);
var R=1.8;return items.filter(Boolean).map(function(it,i){var a=(i/Math.max(items.length,1))*6.2832;return{id:sub.id+"_"+i,label:String(it).slice(0,18),pos:[sub.pos[0]+Math.cos(a)*R,sub.pos[1]+Math.sin(a)*R*0.6,sub.pos[2]+Math.cos(a+2)*0.5],r:0.18,color:C.tx3,type:"leaf",text:String(it),parentType:sub.type,parentLabel:sub.label};});}

// ── FULL PAGES ──
function MainPage({nid,D,files,onUpload,onRemove}){var oI=D.incidents.filter(function(i){return i.status!=="resolved";}).length;var cr=D.tasks.filter(function(t){return t.pri==="critical"&&t.status!=="done";}).length;var am=Math.round(D.ss.reduce(function(a,s){return a+s.mat;},0)/D.ss.length);
if(nid==="command"){var risks=calcRisks(D);var depChains=D.deps||[];var pDead=D.pilotDeadlines||{};return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>DOGMA Command Center</div><div style={{fontSize:14,color:C.tx2,marginBottom:12}}>Executive overview - {dy()}</div>
<div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:14}}>{[[D.fin.runway+"mo","Runway",D.fin.runway<4?C.r:C.a],[oI,"Open Incidents",oI?C.r:C.g],[cr,"Critical Tasks",cr?C.r:C.g],[am+"%","Avg Maturity",am>60?C.g:C.a],[D.pilots.length,"Pilot Pipeline",C.gold],[D.investors.length,"Investors",C.a]].map(function(x,i){return <div key={i} style={{background:C.bg,padding:8,borderRadius:4,borderLeft:"3px solid "+x[2]}}><div style={{fontSize:18,fontWeight:700,color:x[2],fontFamily:"'JetBrains Mono',monospace"}}>{x[0]}</div><div style={{fontSize:10,color:C.tx3,textTransform:"uppercase"}}>{x[1]}</div></div>;})}</div>

{risks.length>0&&<div><Sec>Risk Alerts ({risks.length})</Sec>{risks.slice(0,8).map(function(r,i){return <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"5px 8px",background:r.sev==="critical"?C.r+"08":C.a+"06",borderLeft:"3px solid "+(r.sev==="critical"?C.r:r.sev==="high"?C.a:C.b),borderRadius:3,marginBottom:3,fontSize:13}}>
<Tag color={r.sev==="critical"?C.r:r.sev==="high"?C.a:C.b}>{r.sev}</Tag>
<Tag>{r.cat}</Tag>
<span style={{flex:1,color:C.tx}}>{r.msg}</span>
<span style={{fontFamily:"'JetBrains Mono',monospace",color:C.tx3,fontSize:11}}>S{r.score}</span>
</div>;})}</div>}

<Sec>Dependency Chain</Sec>
<div style={{fontSize:12,color:C.tx3,marginBottom:6}}>Causal blockers — resolving upstream unblocks downstream</div>
{depChains.map(function(dep,i){return <div key={i} style={{padding:"6px 8px",background:C.bg,borderRadius:3,marginBottom:4,borderLeft:"3px solid "+C.a}}>
<div style={{display:"flex",alignItems:"center",gap:6,fontSize:13}}>
<span style={{color:C.r,fontWeight:600}}>{dep.fromLabel}</span>
<span style={{color:C.tx3}}>{"\u2192"}</span>
<span style={{color:C.a}}>blocks</span>
<span style={{color:C.tx}}>{dep.blocks.join(", ")}</span>
</div>
<div style={{fontSize:11,color:C.tx2,marginTop:2}}>{dep.reason}</div>
</div>;})}

<Sec>Pilot Timeline vs Runway</Sec>
<div style={{fontSize:12,color:C.tx3,marginBottom:6}}>Runway exhausts ~{new Date(Date.now()+D.fin.runway*30*86400000).toLocaleDateString("en-US",{month:"short",day:"numeric"})}. Pilots must close before.</div>
{D.pilots.map(function(p,i){var dl=pDead[p.id];return <div key={i} style={{padding:"5px 8px",background:C.bg,borderRadius:3,marginBottom:3,borderLeft:"3px solid "+(dl&&dl.needBy?"#A78530":C.bd)}}>
<div style={{display:"flex",alignItems:"center",gap:6,fontSize:13}}>
<span style={{fontWeight:600}}>{p.name}</span>
<Tag color={C.gold}>{p.stage}</Tag>
<span style={{color:C.tx2}}>{p.viab}%</span>
{dl&&<span style={{fontFamily:"'JetBrains Mono',monospace",color:C.a,fontSize:12}}>Need by: {dl.needBy}</span>}
</div>
{dl&&<div style={{fontSize:11,color:C.tx2,marginTop:2}}>{dl.reason}</div>}
{dl&&dl.gatedBy&&<div style={{fontSize:11,color:C.tx3}}>Gated by: {dl.gatedBy.join(", ")}</div>}
</div>;})}

<Sec>Incident Links</Sec>
{Object.keys(D.incLinks||{}).map(function(iid,i){var lk=D.incLinks[iid];var inc=D.incidents.find(function(x){return x.id===iid;});if(!inc||inc.status==="resolved")return null;return <div key={i} style={{padding:"5px 8px",background:C.bg,borderRadius:3,marginBottom:3,borderLeft:"3px solid "+C.r,fontSize:13}}>
<span style={{color:C.r,fontWeight:600}}>{iid}</span> <span style={{color:C.tx}}>{lk.desc}</span>
<div style={{fontSize:11,color:C.tx3,marginTop:2}}>Links: {lk.ss.length>0?"SS:"+lk.ss.join(",")+" ":""}{lk.tasks.length>0?"Tasks:"+lk.tasks.join(",")+" ":""}{lk.fleet.length>0?"Fleet:"+lk.fleet.join(","):""}</div>
</div>;})}

<Sec>Recent Activity</Sec>{D.log.map(function(l,i){return <div key={i} style={{fontSize:13,color:C.tx2,padding:"2px 0"}}>{l.t} <span style={{color:C.tx3}}>{l.at}</span></div>;})}
<Sec>Key Decisions</Sec>{D.decisions.map(function(d,i){return <div key={i} style={{fontSize:13,padding:"4px 0",borderBottom:"1px solid "+C.bd+"30"}}><span style={{color:C.gold,fontWeight:600}}>{d.title}</span><div style={{color:C.tx2,fontSize:12}}>{d.why} ({d.date})</div></div>;})}
<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);}
if(nid==="rd")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>Research & Development</div><Row label="Avg Maturity" value={am+"%"} color={am>60?C.g:C.a}/><Row label="Total Issues" value={D.ss.reduce(function(a,s){return a+s.issues;},0)}/><Row label="Skills Validated" value={D.skills.filter(function(s){return s.status==="validated";}).length+"/"+D.skills.length}/><Sec>Subsystems ({D.ss.length})</Sec>{D.ss.map(function(s,i){return <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"5px 0",fontSize:14,borderBottom:"1px solid "+C.bd+"30"}}><Dot s={s.status}/><span style={{flex:1}}>{s.name}</span><PB val={s.mat} w={50}/><span style={{fontFamily:"'JetBrains Mono',monospace",color:C.tx2,minWidth:35}}>{s.mat}%</span><Tag>{s.ver}</Tag></div>;})}<Sec>Skills ({D.skills.length})</Sec>{D.skills.map(function(s,i){return <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"5px 0",fontSize:14,borderBottom:"1px solid "+C.bd+"30"}}><Dot s={s.status}/><span style={{flex:1}}>{s.name}</span><span style={{fontFamily:"'JetBrains Mono',monospace",color:s.success>80?C.g:s.success>60?C.a:C.r}}>{s.success}%</span><span style={{fontSize:11,color:C.tx3}}>{s.tests} tests</span></div>;})}<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);
if(nid==="experiments"){var pr=D.exps.length?Math.round(D.exps.filter(function(e){return e.outcome==="pass";}).length/D.exps.length*100):0;return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>Experiment Log</div><Row label="Total" value={D.exps.length}/><Row label="Pass Rate" value={pr+"%"} color={pr>60?C.g:C.a}/><Row label="Failed" value={D.exps.filter(function(e){return e.outcome==="fail";}).length} color={C.r}/><Sec>All Experiments</Sec>{D.exps.map(function(e,i){return <div key={i} style={{padding:"8px 0",borderBottom:"1px solid "+C.bd+"30"}}><div style={{display:"flex",alignItems:"center",gap:6,fontSize:14}}><Dot s={e.outcome}/><span style={{color:C.gold,fontFamily:"'JetBrains Mono',monospace"}}>{e.id}</span><span style={{flex:1}}>{e.title}</span><Tag color={dc(e.outcome)}>{e.outcome}</Tag><span style={{fontSize:12,color:C.tx3}}>{e.date}</span></div>{e.conclusion&&<div style={{fontSize:12,color:C.tx2,marginTop:3,paddingLeft:20}}>{e.conclusion.slice(0,100)}...</div>}</div>;})}<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);}
if(nid==="incidents")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>Incident Tracker</div><Row label="Open" value={oI} color={oI?C.r:C.g}/><Row label="Investigating" value={D.incidents.filter(function(i){return i.status==="investigating";}).length} color={C.a}/><Row label="Resolved" value={D.incidents.filter(function(i){return i.status==="resolved";}).length} color={C.g}/><Sec>All Incidents</Sec>{D.incidents.map(function(ic,i){return <div key={i} style={{padding:"8px 0",borderBottom:"1px solid "+C.bd+"30"}}><div style={{display:"flex",alignItems:"center",gap:6,fontSize:14}}><Dot s={ic.status}/><span style={{color:C.gold,fontFamily:"'JetBrains Mono',monospace"}}>{ic.id}</span><span style={{flex:1}}>{ic.desc.slice(0,50)}</span><Tag color={dc(ic.sev)}>{ic.sev}</Tag><Tag color={dc(ic.status)}>{ic.status}</Tag></div><div style={{fontSize:12,color:C.tx3,marginTop:2}}>Down: {ic.down} | Root: {ic.root}</div></div>;})}<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);
if(nid==="fleet")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>Fleet Management</div><Row label="Active" value={D.fleet.filter(function(f){return f.status==="active";}).length+"/"+D.fleet.length}/><Row label="Total Hours" value={D.fleet.reduce(function(a,f){return a+f.hours;},0)+"h"}/><Sec>All Units</Sec>{D.fleet.map(function(f,i){return <div key={i} style={{padding:"8px 0",borderBottom:"1px solid "+C.bd+"30"}}><div style={{display:"flex",alignItems:"center",gap:6,fontSize:14}}><Dot s={f.status}/><span style={{fontWeight:600}}>{f.unit}</span><span style={{flex:1,color:C.tx2,fontSize:12}}>{f.type}</span><Tag color={dc(f.status)}>{f.status}</Tag></div><div style={{fontSize:12,color:C.tx3,marginTop:2}}>{f.loc} | {f.hours}h | Next: {f.nextMaint}</div></div>;})}<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);
if(nid==="pilots"){var tr=D.pilots.reduce(function(a,p){return a+(parseInt(String(p.roi).replace(/[^0-9]/g,""))||0);},0);return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>Pilot Pipeline</div><Row label="Opportunities" value={D.pilots.length}/><Row label="Total ROI" value={"~$"+tr+"K/yr"} color={C.g}/><Sec>Pipeline</Sec>{D.pilots.map(function(p,i){return <div key={i} style={{padding:"8px 0",borderBottom:"1px solid "+C.bd+"30"}}><div style={{display:"flex",alignItems:"center",gap:6,fontSize:14}}><span style={{fontWeight:600}}>{p.name}</span><Tag color={C.gold}>{p.stage}</Tag><Tag color={dc(p.risk)}>{p.risk}</Tag></div><div style={{fontSize:13,color:C.tx2,marginTop:2}}>ROI: <span style={{color:C.g}}>{p.roi}</span> | Viab: {p.viab}% | Champ: {p.champ} ({p.champStr})</div></div>;})}<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);}
if(nid==="fundraising"){var wp=Math.round(D.investors.reduce(function(a,v){return a+(parseFloat(v.check.replace(/[^0-9.]/g,""))||0)*(v.prob/100);},0));return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>Fundraising</div><Row label="Investors" value={D.investors.length}/><Row label="Weighted Pipeline" value={"~$"+wp+"K"} color={C.a}/><Row label="Runway Pressure" value={D.fin.runway<4?"HIGH":"Moderate"} color={D.fin.runway<4?C.r:C.a}/><Sec>Pipeline</Sec>{D.investors.map(function(v,i){return <div key={i} style={{padding:"8px 0",borderBottom:"1px solid "+C.bd+"30"}}><div style={{display:"flex",alignItems:"center",gap:6,fontSize:14}}><span style={{fontWeight:600}}>{v.name}</span><Tag color={C.gold}>{v.stage}</Tag><span style={{fontFamily:"'JetBrains Mono',monospace",color:v.prob>=30?C.g:C.a}}>{v.prob}%</span><span style={{color:C.tx2}}>{v.check}</span></div><div style={{fontSize:12,color:C.tx3,marginTop:2}}>Next: {v.next} | {v.thesis&&v.thesis.slice(0,60)}</div></div>;})}<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);}
if(nid==="finance")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>Finance</div><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:10}}>{[["$"+(D.fin.burn/1000).toFixed(1)+"K","Burn/mo",C.r],["$"+(D.fin.cash/1000).toFixed(0)+"K","Cash",C.a],[D.fin.runway+"mo","Runway",D.fin.runway<4?C.r:C.a],["$"+(D.fin.bom/1000).toFixed(1)+"K","BOM",C.gold]].map(function(x,i){return <div key={i} style={{background:C.bg,padding:8,borderRadius:4}}><div style={{fontSize:18,fontWeight:700,color:x[2],fontFamily:"'JetBrains Mono',monospace"}}>{x[0]}</div><div style={{fontSize:10,color:C.tx3}}>{x[1]}</div></div>;})}</div><Sec>Spend Breakdown</Sec>{D.fin.spend.map(function(s,i){return <Row key={i} label={s.c} value={"$"+(s.a/1000).toFixed(1)+"K"}/>;})}<Sec>Supply Risk</Sec>{D.supply.map(function(s,i){return <div key={i} style={{fontSize:14,padding:"4px 0"}}>{s.item} <Tag color={dc(s.risk==="high"?"critical":"active")}>{s.risk}</Tag> <span style={{color:C.tx3}}>{s.lead}</span></div>;})}<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);
if(nid==="team")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>Task Board</div><Row label="Total" value={D.tasks.length}/><Row label="Critical" value={cr} color={cr?C.r:C.g}/><Sec>All Tasks</Sec>{D.tasks.map(function(t,i){return <div key={i} style={{display:"flex",alignItems:"center",gap:6,padding:"5px 0",fontSize:14,borderBottom:"1px solid "+C.bd+"30"}}><Dot s={t.status}/><span style={{flex:1}}>{t.title}</span><Tag color={dc(t.pri)}>{t.pri}</Tag><Tag>{t.ws}</Tag><span style={{fontSize:12,color:C.tx3}}>{t.due}</span></div>;})}<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);
if(nid==="roadmap"){var avgS=Math.round(D.safety.reduce(function(a,s){return a+s.cov;},0)/D.safety.length);return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>Roadmap</div><Sec>Milestones</Sec>{D.milestones.map(function(m,i){return <div key={i} style={{padding:"8px 0",borderBottom:"1px solid "+C.bd+"30"}}><div style={{fontSize:14}}><span style={{fontWeight:600}}>{m.title}</span> <Tag color={dc(m.risk)}>{m.risk}</Tag> <span style={{color:C.tx3}}>{m.target}</span></div><div style={{marginTop:3}}><PB val={m.pct} w={100}/> <span style={{fontFamily:"'JetBrains Mono',monospace"}}>{m.pct}%</span></div>{m.blockers.length>0&&<div style={{fontSize:12,color:C.r,marginTop:2}}>{m.blockers.join(" | ")}</div>}</div>;})}<Sec>Safety ({avgS}%)</Sec>{D.safety.map(function(sf,i){return <div key={i} style={{display:"flex",alignItems:"center",gap:6,padding:"4px 0",fontSize:14}}><span style={{flex:1}}>{sf.name}</span><PB val={sf.cov} w={50} color={sf.cov>70?C.g:sf.cov>50?C.a:C.r}/><span style={{fontFamily:"'JetBrains Mono',monospace"}}>{sf.cov}%</span></div>;})}<FileUpload nodeId={nid} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);}
return null;}

function SubPage({sub,D,acts,files,onUpload,onRemove}){if(!sub)return null;var d=sub.data;var tp=sub.type;var ce=acts.canEdit;var uf=acts.updateField;var uaf=acts.updateArrayField;
// col mapping
var col=tp==="ss"?"ss":tp==="skill"?"skills":tp==="exp"?"exps":tp==="inc"?"incidents":tp==="pilot"?"pilots":tp==="inv"?"investors":tp==="task"?"tasks":tp==="fl"?"fleet":tp==="ms"?"milestones":tp==="safe"?"safety":tp==="sply"?"supply":"";
var F=function(field,val){if(col)uf(col,d.id,field,val);};
var FA=function(field,arr){if(col)uaf(col,d.id,field,arr);};

if(tp==="ss")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>{d.name}</div><div style={{display:"flex",gap:6,marginBottom:8,flexWrap:"wrap"}}><Tag color={dc(d.status)}>{d.status}</Tag><Tag>{d.ver}</Tag><Tag>Owner: {d.owner}</Tag></div>
<Row label="Maturity" value={d.mat+"%"} color={d.mat>70?C.g:d.mat>50?C.a:C.r} canEdit={ce} onSave={function(v){F("mat",parseInt(v)||0);}}/><Row label="Issues" value={d.issues} canEdit={ce} onSave={function(v){F("issues",parseInt(v)||0);}}/><Row label="Status" value={d.status} canEdit={ce} onSave={function(v){F("status",v);}}/><Row label="Version" value={d.ver} canEdit={ce} onSave={function(v){F("ver",v);}}/><Row label="Owner" value={d.owner} canEdit={ce} onSave={function(v){F("owner",v);}}/><Row label="Last Test" value={d.lastTest} canEdit={ce} onSave={function(v){F("lastTest",v);}}/>
<Sec>Technical Specifications</Sec><EList items={d.d||[]} canEdit={ce} onUpdate={function(a){FA("d",a);}}/><Sec>Known Risks</Sec><EList items={d.risks||[]} canEdit={ce} onUpdate={function(a){FA("risks",a);}} color={C.r}/>
<NoteBox notes={d.notes} onAdd={function(t){acts.addNote("ss",d.id,t);}}/>
{getBlocks(d.id,D.deps).length>0&&<div><Sec>Blocks (downstream)</Sec>{getBlocks(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.a,padding:"3px 0"}}>{"\u2192"} {dep.blocks.join(", ")} - {dep.reason}</div>;})}</div>}
{getBlockedBy(d.id,D.deps).length>0&&<div><Sec>Blocked By (upstream)</Sec>{getBlockedBy(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.r,padding:"3px 0"}}>{"\u2190"} {dep.fromLabel} - {dep.reason}</div>;})}</div>}
{D.incLinks&&Object.keys(D.incLinks).filter(function(k){return(D.incLinks[k].ss||[]).indexOf(d.id)>=0;}).length>0&&<div><Sec>Linked Incidents</Sec>{Object.keys(D.incLinks).filter(function(k){return(D.incLinks[k].ss||[]).indexOf(d.id)>=0;}).map(function(k,i){return <div key={i} style={{fontSize:13,color:C.r}}>{k}: {D.incLinks[k].desc}</div>;})}</div>}
<FileUpload nodeId={d.id} files={files} onUpload={onUpload} onRemove={onRemove}/></div>);

if(tp==="skill")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>{d.name}</div><Tag color={dc(d.status)}>{d.status}</Tag>
<Row label="Success Rate" value={d.success+"%"} color={d.success>80?C.g:C.a} canEdit={ce} onSave={function(v){F("success",parseInt(v)||0);}}/><Row label="Tests Run" value={d.tests} canEdit={ce} onSave={function(v){F("tests",parseInt(v)||0);}}/><Row label="Status" value={d.status} canEdit={ce} onSave={function(v){F("status",v);}}/><Row label="Last Tested" value={d.lastTest} canEdit={ce} onSave={function(v){F("lastTest",v);}}/>
<Sec>Test Protocol</Sec><EText text={d.protocol} canEdit={ce} onSave={function(v){F("protocol",v);}}/><Sec>Gaps</Sec><EList items={d.gaps||[]} canEdit={ce} onUpdate={function(a){FA("gaps",a);}} color={C.a}/>
<NoteBox notes={d.notes} onAdd={function(t){acts.addNote("skills",d.id,t);}}/>
{getBlockedBy(d.id,D.deps).length>0&&<div><Sec>Blocked By</Sec>{getBlockedBy(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.r,padding:"3px 0"}}>{"\u2190"} {dep.fromLabel} - {dep.reason}</div>;})}</div>}
{getBlocks(d.id,D.deps).length>0&&<div><Sec>Blocks</Sec>{getBlocks(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.a,padding:"3px 0"}}>{"\u2192"} {dep.blocks.join(", ")} - {dep.reason}</div>;})}</div>}
</div>);

if(tp==="exp")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:6}}>{d.id}</div><div style={{fontSize:16,color:C.tx,marginBottom:8}}>{d.title}</div><div style={{display:"flex",gap:6,marginBottom:8}}><Tag color={dc(d.outcome)}>{d.outcome}</Tag><Tag>Conf {d.conf}/5</Tag><Tag>{d.date}</Tag></div>
<Row label="Outcome" value={d.outcome} canEdit={ce} onSave={function(v){F("outcome",v);}}/><Row label="Confidence" value={d.conf+"/5"} canEdit={ce} onSave={function(v){F("conf",parseInt(v)||0);}}/><Row label="Title" value={d.title} canEdit={ce} onSave={function(v){F("title",v);}}/>
<Sec>Parameters</Sec><EList items={d.p||[]} canEdit={ce} onUpdate={function(a){FA("p",a);}}/>{d.conclusion&&<div><Sec>Conclusion</Sec><EText text={d.conclusion} canEdit={ce} onSave={function(v){F("conclusion",v);}}/></div>}
<NoteBox notes={d.notes} onAdd={function(t){acts.addNote("exps",d.id,t);}}/></div>);

if(tp==="inc")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:6}}>{d.id}</div><div style={{fontSize:16,color:C.tx,marginBottom:8}}>{d.desc}</div><div style={{display:"flex",gap:6,marginBottom:8}}><Tag color={dc(d.sev)}>{d.sev}</Tag><Tag color={dc(d.status)}>{d.status}</Tag></div>
<Row label="Description" value={d.desc} canEdit={ce} onSave={function(v){F("desc",v);}}/><Row label="Severity" value={d.sev} canEdit={ce} onSave={function(v){F("sev",v);}}/><Row label="Status" value={d.status} canEdit={ce} onSave={function(v){F("status",v);}}/><Row label="Downtime" value={d.down} color={C.r} canEdit={ce} onSave={function(v){F("down",v);}}/><Row label="Root Cause" value={d.root} canEdit={ce} onSave={function(v){F("root",v);}}/><Row label="Reported" value={d.reported} canEdit={ce} onSave={function(v){F("reported",v);}}/>
<Sec>Corrective Actions</Sec><EList items={d.acts||[]} canEdit={ce} onUpdate={function(a){FA("acts",a);}}/><Sec>Timeline</Sec><EList items={d.timeline||[]} canEdit={ce} onUpdate={function(a){FA("timeline",a);}} color={C.tx2}/>
{d.status!=="resolved"&&<div style={{marginTop:8}}><Btn v="success" onClick={function(){acts.resInc(d.id);}}>Mark Resolved</Btn></div>}
{D.incLinks&&D.incLinks[d.id]&&<div><Sec>Linked Entities</Sec>
<div style={{fontSize:13}}>{(D.incLinks[d.id].ss||[]).length>0&&<div style={{color:C.tx}}>Subsystems: {(D.incLinks[d.id].ss||[]).map(function(s){var ss=D.ss.find(function(x){return x.id===s;});return ss?ss.name+" ("+ss.mat+"%)":s;}).join(", ")}</div>}
{(D.incLinks[d.id].tasks||[]).length>0&&<div style={{color:C.tx}}>Tasks: {(D.incLinks[d.id].tasks||[]).join(", ")}</div>}
{(D.incLinks[d.id].fleet||[]).length>0&&<div style={{color:C.tx}}>Fleet: {(D.incLinks[d.id].fleet||[]).map(function(f){var fl=D.fleet.find(function(x){return x.id===f;});return fl?fl.unit:f;}).join(", ")}</div>}
</div></div>}
{getBlocks(d.id,D.deps).length>0&&<div><Sec>Downstream Impact</Sec>{getBlocks(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.a,padding:"3px 0"}}>{"\u2192"} blocks {dep.blocks.join(", ")} - {dep.reason}</div>;})}</div>}
<NoteBox notes={d.notes} onAdd={function(t){acts.addNote("incidents",d.id,t);}}/></div>);

if(tp==="pilot")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>{d.name}</div><div style={{display:"flex",gap:6,marginBottom:8,flexWrap:"wrap"}}><Tag color={C.gold}>{d.stage}</Tag><Tag color={dc(d.risk)}>{d.risk} risk</Tag></div>
<Row label="ROI" value={d.roi} color={C.g} canEdit={ce} onSave={function(v){F("roi",v);}}/><Row label="Viability" value={d.viab+"%"} canEdit={ce} onSave={function(v){F("viab",parseInt(v)||0);}}/><Row label="Champion" value={d.champ} canEdit={ce} onSave={function(v){F("champ",v);}}/><Row label="Champ Strength" value={d.champStr} color={d.champStr==="Strong"?C.g:d.champStr==="None"?C.r:C.a} canEdit={ce} onSave={function(v){F("champStr",v);}}/><Row label="Plant" value={d.plant} canEdit={ce} onSave={function(v){F("plant",v);}}/><Row label="PLC" value={d.plc} canEdit={ce} onSave={function(v){F("plc",v);}}/><Row label="Stage" value={d.stage} canEdit={ce} onSave={function(v){F("stage",v);}}/><Row label="Risk" value={d.risk} canEdit={ce} onSave={function(v){F("risk",v);}}/><Row label="Next Step" value={d.nextStep} canEdit={ce} onSave={function(v){F("nextStep",v);}}/><Row label="Follow-up" value={d.fu} canEdit={ce} onSave={function(v){F("fu",v);}}/>
<Sec>Pain Point</Sec><EText text={d.pain} canEdit={ce} onSave={function(v){F("pain",v);}}/><Sec>Required Skills</Sec><EList items={d.skills||[]} canEdit={ce} onUpdate={function(a){FA("skills",a);}} color={C.c}/><Sec>Compliance</Sec><EList items={d.comp||[]} canEdit={ce} onUpdate={function(a){FA("comp",a);}} color={C.r}/><Sec>Blockers</Sec><EList items={d.blockers||[]} canEdit={ce} onUpdate={function(a){FA("blockers",a);}} color={C.r}/><Sec>Open Questions</Sec><EList items={d.qs||[]} canEdit={ce} onUpdate={function(a){FA("qs",a);}} color={C.tx2}/>
{d.meetings&&d.meetings.length>0&&<div><Sec>Meetings</Sec>{d.meetings.map(function(m,i){return <div key={i} style={{fontSize:13,padding:"4px 0"}}><span style={{color:C.gold,fontFamily:"'JetBrains Mono',monospace"}}>{m.d}</span> {m.n}</div>;})}</div>}
{D.pilotDeadlines&&D.pilotDeadlines[d.id]&&<div><Sec>Timeline Constraint</Sec><div style={{padding:"6px 8px",background:C.a+"08",borderLeft:"3px solid "+C.a,borderRadius:3,fontSize:13}}><div style={{fontWeight:600,color:C.a}}>Need by: {D.pilotDeadlines[d.id].needBy}</div><div style={{color:C.tx2,marginTop:2}}>{D.pilotDeadlines[d.id].reason}</div>{D.pilotDeadlines[d.id].gatedBy&&<div style={{color:C.tx3,marginTop:2}}>Gated by: {D.pilotDeadlines[d.id].gatedBy.join(", ")}</div>}</div></div>}
{getBlockedBy(d.id,D.deps).length>0&&<div><Sec>Blocked By</Sec>{getBlockedBy(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.r,padding:"3px 0"}}>{"\u2190"} {dep.fromLabel} - {dep.reason}</div>;})}</div>}
<div style={{marginTop:8}}><Btn v="gold" onClick={function(){acts.advP(d.id);}}>Advance Stage</Btn></div><NoteBox notes={d.notes} onAdd={function(t){acts.addNote("pilots",d.id,t);}}/></div>);

if(tp==="inv")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>{d.name}</div><Tag color={C.gold}>{d.stage}</Tag>
<Row label="Probability" value={d.prob+"%"} color={d.prob>=30?C.g:C.a} canEdit={ce} onSave={function(v){F("prob",parseInt(v)||0);}}/><Row label="Check Size" value={d.check} canEdit={ce} onSave={function(v){F("check",v);}}/><Row label="Stage" value={d.stage} canEdit={ce} onSave={function(v){F("stage",v);}}/><Row label="Next Action" value={d.next} canEdit={ce} onSave={function(v){F("next",v);}}/><Row label="Date" value={d.nextDate} canEdit={ce} onSave={function(v){F("nextDate",v);}}/>
<Sec>Thesis Fit</Sec><EText text={d.thesis} canEdit={ce} onSave={function(v){F("thesis",v);}}/><Sec>Touchpoints</Sec><EList items={d.tp||[]} canEdit={ce} onUpdate={function(a){FA("tp",a);}}/><Sec>Objections</Sec><EList items={d.objections||[]} canEdit={ce} onUpdate={function(a){FA("objections",a);}} color={C.a}/>
<div style={{marginTop:8}}><Btn v="gold" onClick={function(){acts.advI(d.id);}}>Advance Stage</Btn></div><NoteBox notes={d.notes} onAdd={function(t){acts.addNote("investors",d.id,t);}}/></div>);

if(tp==="task")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>{d.title}</div><div style={{display:"flex",gap:6,marginBottom:8,flexWrap:"wrap"}}><Tag color={dc(d.status)}>{d.status}</Tag><Tag color={dc(d.pri)}>{d.pri}</Tag><Tag>{d.ws}</Tag></div>
<Row label="Title" value={d.title} canEdit={ce} onSave={function(v){F("title",v);}}/><Row label="Due" value={d.due} canEdit={ce} onSave={function(v){F("due",v);}}/><Row label="Priority" value={d.pri} canEdit={ce} onSave={function(v){F("pri",v);}}/><Row label="Status" value={d.status} canEdit={ce} onSave={function(v){F("status",v);}}/><Row label="Owner" value={d.owner} canEdit={ce} onSave={function(v){F("owner",v);}}/><Row label="Workspace" value={d.ws} canEdit={ce} onSave={function(v){F("ws",v);}}/>{d.blocked&&<Row label="Blocked By" value={d.blocked} color={C.r} canEdit={ce} onSave={function(v){F("blocked",v);}}/>}
<Sec>Business Impact</Sec><EText text={d.impact} canEdit={ce} onSave={function(v){F("impact",v);}}/><Sec>Subtasks</Sec><EList items={d.sb||[]} canEdit={ce} onUpdate={function(a){FA("sb",a);}}/>
{getBlockedBy(d.id,D.deps).length>0&&<div><Sec>Blocked By</Sec>{getBlockedBy(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.r,padding:"3px 0"}}>{"\u2190"} {dep.fromLabel} - {dep.reason}</div>;})}</div>}
{getBlocks(d.id,D.deps).length>0&&<div><Sec>Unblocks</Sec>{getBlocks(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.a,padding:"3px 0"}}>{"\u2192"} {dep.blocks.join(", ")} - {dep.reason}</div>;})}</div>}
{D.incLinks&&Object.keys(D.incLinks).filter(function(k){return(D.incLinks[k].tasks||[]).indexOf(d.id)>=0;}).length>0&&<div><Sec>Linked Incidents</Sec>{Object.keys(D.incLinks).filter(function(k){return(D.incLinks[k].tasks||[]).indexOf(d.id)>=0;}).map(function(k,i){return <div key={i} style={{fontSize:13,color:C.r}}>{k}: {D.incLinks[k].desc}</div>;})}</div>}
<div style={{marginTop:8,display:"flex",gap:8}}><Btn v={d.status==="done"?"default":"success"} onClick={function(){acts.togTask(d.id);}}>{d.status==="done"?"Reopen":"Mark Done"}</Btn></div><NoteBox notes={d.notes} onAdd={function(t){acts.addNote("tasks",d.id,t);}}/></div>);

if(tp==="fl")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:6}}>{d.unit}</div><div style={{fontSize:15,color:C.tx2,marginBottom:8}}>{d.type}</div><Tag color={dc(d.status)}>{d.status}</Tag>
<Row label="Status" value={d.status} canEdit={ce} onSave={function(v){F("status",v);}}/><Row label="Configuration" value={d.config} canEdit={ce} onSave={function(v){F("config",v);}}/><Row label="Location" value={d.loc} canEdit={ce} onSave={function(v){F("loc",v);}}/><Row label="Hours" value={d.hours+"h"} canEdit={ce} onSave={function(v){F("hours",parseInt(v)||0);}}/>{d.health>0&&<Row label="Health" value={d.health+"%"} color={d.health>80?C.g:C.a} canEdit={ce} onSave={function(v){F("health",parseInt(v)||0);}}/>}<Row label="Last Maintenance" value={d.lastMaint} canEdit={ce} onSave={function(v){F("lastMaint",v);}}/><Row label="Next Maintenance" value={d.nextMaint} canEdit={ce} onSave={function(v){F("nextMaint",v);}}/>
<Sec>Systems Status</Sec><EList items={d.sys||[]} canEdit={ce} onUpdate={function(a){FA("sys",a);}}/></div>);

if(tp==="ms")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>{d.title}</div><div style={{display:"flex",gap:6,marginBottom:8}}><Tag color={dc(d.risk)}>{d.risk}</Tag><Tag>{d.target}</Tag></div><div style={{fontSize:15,marginBottom:8}}>Progress: <PB val={d.pct} w={100}/> <span style={{fontFamily:"'JetBrains Mono',monospace"}}>{d.pct}%</span></div>
<Row label="Title" value={d.title} canEdit={ce} onSave={function(v){F("title",v);}}/><Row label="Progress %" value={d.pct} canEdit={ce} onSave={function(v){F("pct",parseInt(v)||0);}}/><Row label="Risk" value={d.risk} canEdit={ce} onSave={function(v){F("risk",v);}}/><Row label="Target" value={d.target} canEdit={ce} onSave={function(v){F("target",v);}}/>
<Sec>Blockers</Sec><EList items={d.blockers||[]} canEdit={ce} onUpdate={function(a){FA("blockers",a);}} color={C.r}/><Sec>Acceptance Criteria</Sec><EList items={d.cr||[]} canEdit={ce} onUpdate={function(a){FA("cr",a);}}/>{d.deps&&<div><Sec>Dependencies</Sec><EList items={d.deps||[]} canEdit={ce} onUpdate={function(a){FA("deps",a);}} color={C.tx2}/></div>}
{getBlockedBy(d.id,D.deps).length>0&&<div><Sec>Upstream Blockers (causal)</Sec>{getBlockedBy(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.r,padding:"3px 0"}}>{"\u2190"} {dep.fromLabel} - {dep.reason}</div>;})}</div>}
{getBlocks(d.id,D.deps).length>0&&<div><Sec>Downstream (gates)</Sec>{getBlocks(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.a,padding:"3px 0"}}>{"\u2192"} {dep.blocks.join(", ")} - {dep.reason}</div>;})}</div>}
</div>);

if(tp==="safe")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>{d.name}</div><div style={{fontSize:15,marginBottom:8}}>Coverage: <PB val={d.cov} w={100} color={d.cov>70?C.g:d.cov>50?C.a:C.r}/> <span style={{fontFamily:"'JetBrains Mono',monospace"}}>{d.cov}%</span></div>
<Row label="Coverage %" value={d.cov} canEdit={ce} onSave={function(v){F("cov",parseInt(v)||0);}}/>
<Sec>Compliance Gaps</Sec><EList items={d.gaps||[]} canEdit={ce} onUpdate={function(a){FA("gaps",a);}} color={C.r}/>
{getBlocks(d.id,D.deps).length>0&&<div><Sec>Blocks (pilots/milestones)</Sec>{getBlocks(d.id,D.deps).map(function(dep,i){return <div key={i} style={{fontSize:13,color:C.a,padding:"3px 0"}}>{"\u2192"} {dep.blocks.join(", ")} - {dep.reason}</div>;})}</div>}
</div>);

if(tp==="sply")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>{d.item}</div>
<Row label="Supplier" value={d.supplier} canEdit={ce} onSave={function(v){F("supplier",v);}}/><Row label="Lead Time" value={d.lead} canEdit={ce} onSave={function(v){F("lead",v);}}/><Row label="Risk" value={d.risk} canEdit={ce} onSave={function(v){F("risk",v);}}/>{d.note&&<div><Sec>Notes</Sec><EText text={d.note} canEdit={ce} onSave={function(v){F("note",v);}}/></div>}</div>);

if(tp==="fmet")return(<div><div style={{fontSize:22,fontWeight:700,color:C.gold,marginBottom:8}}>{d.n}</div><div style={{fontSize:28,fontWeight:700,fontFamily:"'JetBrains Mono',monospace",marginBottom:10}}>{d.v}</div>{(d.d||[]).filter(Boolean).map(function(x,i){return <div key={i} style={{fontSize:14,color:C.tx2,padding:"3px 0"}}>- {x}</div>;})}</div>);
return null;}

function LeafPage({leaf}){if(!leaf)return null;return(<div><div style={{fontSize:20,fontWeight:700,color:C.gold,marginBottom:8}}>{leaf.text}</div><Row label="Source Node" value={leaf.parentLabel}/><Row label="Category" value={leaf.parentType}/><Sec>Detail</Sec><div style={{fontSize:15,color:C.tx,lineHeight:1.7,padding:"10px 12px",background:C.bg,borderRadius:4,borderLeft:"3px solid "+C.gold+"25"}}>{leaf.text}</div></div>);}

// ── Agents ──
var AGENTS=[
  // ── STRATEGY ──
  {id:"planner",name:"Planner",icon:"📐",color:C.gold,cat:"strategy",desc:"Implementation planner — phased blueprints, milestones, critical path, risk flags"},
  {id:"architect",name:"Architect",icon:"🏗️",color:C.b,cat:"strategy",desc:"Systems architect — boundaries, data flow, ADRs, technology decisions"},
  {id:"researcher",name:"Researcher",icon:"🔍",color:C.c,cat:"strategy",desc:"Research agent — search-first analysis, competitive intel, state-of-the-art"},
  // ── IMPLEMENTATION ──
  {id:"backend-dev",name:"Backend Dev",icon:"⚙️",color:C.g,cat:"implementation",desc:"Senior backend — TDD, APIs, validation, error handling, data layer"},
  {id:"frontend-dev",name:"Frontend Dev",icon:"🎨",color:C.a,cat:"implementation",desc:"Senior frontend — React, Next.js, Tailwind, accessibility, performance"},
  {id:"coder",name:"Coder",icon:"💻",color:C.g,cat:"implementation",desc:"General-purpose coder — any language, TDD-strict, production-grade"},
  {id:"data-engineer",name:"Data Engineer",icon:"🗄️",color:C.c,cat:"implementation",desc:"Data engineer — schemas, migrations, queries, ETL, optimization"},
  {id:"mobile-dev",name:"Mobile Dev",icon:"📱",color:C.b,cat:"implementation",desc:"Mobile dev — React Native, Swift, Kotlin, offline-first"},
  // ── QUALITY ──
  {id:"reviewer",name:"Code Reviewer",icon:"🔎",color:C.a,cat:"quality",desc:"Code reviewer — correctness, security, performance, maintainability scoring"},
  {id:"tester",name:"QA Tester",icon:"🧪",color:C.r,cat:"quality",desc:"QA engineer — adversarial testing, boundary values, error paths"},
  {id:"security-scanner",name:"Security",icon:"🛡️",color:C.r,cat:"quality",desc:"Security auditor — STRIDE, OWASP, CVE audit, threat modeling"},
  {id:"perf-benchmarker",name:"Performance",icon:"📊",color:C.gold,cat:"quality",desc:"Performance engineer — profiling, benchmarks, latency optimization"},
  {id:"e2e-runner",name:"E2E Tester",icon:"🎭",color:C.r,cat:"quality",desc:"E2E test engineer — Playwright/Cypress, user journey testing"},
  // ── OPERATIONS ──
  {id:"build-resolver",name:"Build Fixer",icon:"🔧",color:C.r,cat:"operations",desc:"Build error specialist — compilation, bundling, deployment fixes"},
  {id:"refactor-cleaner",name:"Refactorer",icon:"🧹",color:C.g,cat:"operations",desc:"Code cleanliness — dead code removal, complexity reduction, DRY"},
  {id:"documenter",name:"Documenter",icon:"📚",color:C.b,cat:"operations",desc:"Documentation — READMEs, API docs, runbooks, changelogs, architecture"},
  {id:"cicd-engineer",name:"CI/CD",icon:"🔄",color:C.g,cat:"operations",desc:"CI/CD engineer — pipelines, deployment, monitoring, rollback"},
  {id:"optimizer",name:"Optimizer",icon:"⚡",color:C.gold,cat:"operations",desc:"Cost & perf optimizer — compute, tokens, infra, developer time"},
  {id:"coordinator",name:"Coordinator",icon:"🎯",color:C.gold,cat:"operations",desc:"Swarm coordinator — synthesis, conflict resolution, executive summary"},
];
var AGENT_CATEGORIES=[
  {id:"strategy",label:"Strategy",color:C.gold},
  {id:"implementation",label:"Build",color:C.g},
  {id:"quality",label:"Quality",color:C.r},
  {id:"operations",label:"Ops",color:C.b},
];

export default function Dashboard(){
var _s=useState(seed),D=_s[0],setD=_s[1];
var _xp=useState({}),xp=_xp[0],setXp=_xp[1];
var _xp2=useState({}),xp2=_xp2[0],setXp2=_xp2[1];
var _sel=useState(null),sel=_sel[0],setSel=_sel[1];
var _files=useState({}),files=_files[0],setFiles=_files[1];
var canvasRef=useRef(null);var sceneRef=useRef(null);var camRef=useRef(null);var rendRef=useRef(null);
var zoomRef=useRef(24);var frameRef=useRef(0);
var panRef=useRef({x:0,y:0});var dragRef=useRef({active:false,moved:false,mode:"",sx:0,sy:0,px:0,py:0,rx:0,ry:0});
var _overlay=useState([]),overlay=_overlay[0],setOverlay=_overlay[1];
var overlayRef=useRef({});
var _agent=useState("planner"),agentId=_agent[0],setAgentId=_agent[1];
var _msgs=useState({}),msgs=_msgs[0],setMsgs=_msgs[1];
var _inp=useState(""),inp=_inp[0],setInp=_inp[1];
var _ld=useState(false),ld=_ld[0],setLd=_ld[1];
var _con=useState(false),con=_con[0],setCon=_con[1];
var _search=useState(""),search=_search[0],setSearch=_search[1];
var _searchOpen=useState(false),searchOpen=_searchOpen[0],setSearchOpen=_searchOpen[1];
var _chatW=useState(Math.round(typeof window!=="undefined"?window.innerWidth*0.5:600)),chatW=_chatW[0],setChatW=_chatW[1];
var resizeRef=useRef(null);
var _mode=useState("chat"),mode=_mode[0],setMode=_mode[1]; // "chat" or "swarm"
var _swarmResult=useState(null),swarmResult=_swarmResult[0],setSwarmResult=_swarmResult[1];
var _swarmLoading=useState(false),swarmLoading=_swarmLoading[0],setSwarmLoading=_swarmLoading[1];
var _selWorkflow=useState(""),selWorkflow=_selWorkflow[0],setSelWorkflow=_selWorkflow[1];
var _swarmObjective=useState(""),swarmObjective=_swarmObjective[0],setSwarmObjective=_swarmObjective[1];
var SWARM_WORKFLOWS=[
  {id:"fullstack-dev",name:"Full-Stack Dev",desc:"Plan → Architect → Build → Test → Review → Deploy",agents:13,icon:"🏗️"},
  {id:"code-review",name:"Code Review",desc:"Security + Performance + Quality → Report",agents:5,icon:"🔎"},
  {id:"research-sprint",name:"Research Sprint",desc:"Research → Architect → Plan → Document",agents:4,icon:"🔍"},
  {id:"security-audit",name:"Security Audit",desc:"Scan → Triage → Fix → Validate",agents:7,icon:"🛡️"},
  {id:"optimization",name:"Optimization",desc:"Benchmark → Analyze → Optimize → Validate",agents:8,icon:"⚡"},
  {id:"feature-tdd",name:"TDD Feature",desc:"Plan → Test → Code → Review → Document",agents:6,icon:"🧪"},
  {id:"incident-response",name:"Incident Response",desc:"Diagnose → Fix → Test → Post-mortem",agents:10,icon:"🚨"},
  {id:"deploy-pipeline",name:"Deployment",desc:"Build → Test → Security → Deploy → Validate",agents:8,icon:"🔄"},
];
useEffect(function(){
  var onMove=function(e){if(!resizeRef.current)return;var w=window.innerWidth-e.clientX;setChatW(Math.max(240,Math.min(w,window.innerWidth*0.7)));};
  var onUp=function(){resizeRef.current=false;document.body.style.cursor="";document.body.style.userSelect="";};
  window.addEventListener("mousemove",onMove);window.addEventListener("mouseup",onUp);
  return function(){window.removeEventListener("mousemove",onMove);window.removeEventListener("mouseup",onUp);};
},[]);

// Search index — flatten all entities into searchable list
var searchResults=useMemo(function(){
  if(!search||search.length<2)return[];
  var q=search.toLowerCase();var results=[];
  D.ss.forEach(function(s){if((s.name+s.id+s.status+(s.d||[]).join(" ")).toLowerCase().indexOf(q)>=0)results.push({id:s.id,label:s.name,type:"Subsystem",metric:s.mat+"%",color:dc(s.status),level:"sub",parent:"rd",data:s});});
  D.skills.forEach(function(s){if((s.name+s.id+s.protocol).toLowerCase().indexOf(q)>=0)results.push({id:s.id,label:s.name,type:"Skill",metric:s.success+"%",color:dc(s.status),level:"sub",parent:"rd",data:s});});
  D.exps.forEach(function(e){if((e.id+e.title+e.outcome+e.conclusion).toLowerCase().indexOf(q)>=0)results.push({id:e.id,label:e.title,type:"Experiment",metric:e.outcome,color:dc(e.outcome),level:"sub",parent:"experiments",data:e});});
  D.tasks.forEach(function(t){if((t.id+t.title+t.ws+t.impact).toLowerCase().indexOf(q)>=0)results.push({id:t.id,label:t.title,type:"Task",metric:t.pri,color:dc(t.pri),level:"sub",parent:"team",data:t});});
  D.pilots.forEach(function(p){if((p.id+p.name+p.plant+p.pain+p.champ).toLowerCase().indexOf(q)>=0)results.push({id:p.id,label:p.name,type:"Pilot",metric:p.viab+"%",color:p.viab>80?C.g:C.a,level:"sub",parent:"pilots",data:p});});
  D.investors.forEach(function(v){if((v.id+v.name+v.thesis+v.stage).toLowerCase().indexOf(q)>=0)results.push({id:v.id,label:v.name,type:"Investor",metric:v.prob+"%",color:v.prob>=30?C.g:C.a,level:"sub",parent:"fundraising",data:v});});
  D.incidents.forEach(function(i){if((i.id+i.desc+i.root+i.status).toLowerCase().indexOf(q)>=0)results.push({id:i.id,label:i.desc,type:"Incident",metric:i.status,color:dc(i.status),level:"sub",parent:"incidents",data:i});});
  D.fleet.forEach(function(f){if((f.id+f.unit+f.type+f.loc).toLowerCase().indexOf(q)>=0)results.push({id:f.id,label:f.unit,type:"Fleet",metric:f.health+"%",color:dc(f.status),level:"sub",parent:"fleet",data:f});});
  D.milestones.forEach(function(m){if((m.id+m.title+m.risk).toLowerCase().indexOf(q)>=0)results.push({id:m.id,label:m.title,type:"Milestone",metric:m.pct+"%",color:dc(m.risk),level:"sub",parent:"roadmap",data:m});});
  D.safety.forEach(function(s){if((s.id+s.name+(s.gaps||[]).join(" ")).toLowerCase().indexOf(q)>=0)results.push({id:s.id,label:s.name,type:"Safety",metric:s.cov+"%",color:s.cov>70?C.g:C.r,level:"sub",parent:"roadmap",data:s});});
  D.supply.forEach(function(s){if((s.id+s.item+s.supplier+s.note).toLowerCase().indexOf(q)>=0)results.push({id:s.id,label:s.item,type:"Supply",metric:s.risk,color:dc(s.risk==="high"?"critical":"active"),level:"sub",parent:"finance",data:s});});
  // Also search main nodes
  NODES.forEach(function(n){if(n.label.toLowerCase().indexOf(q)>=0)results.push({id:n.id,label:n.label,type:"Node",metric:"",color:C.gold,level:"main",parent:""});});
  return results.slice(0,12);
},[search,D]);
var chatEnd=useRef(null);

// Auth system
var _auth=useState(false),authed=_auth[0],setAuthed=_auth[1];
var _showLogin=useState(false),showLogin=_showLogin[0],setShowLogin=_showLogin[1];
var _pw=useState(""),pw=_pw[0],setPw=_pw[1];
var _pwErr=useState(false),pwErr=_pwErr[0],setPwErr=_pwErr[1];
var PASS="dogma2026";
var tryLogin=function(){if(pw===PASS){setAuthed(true);setShowLogin(false);setPw("");setPwErr(false);}else{setPwErr(true);}};
var canEdit=authed;
var canGen=true; // Everyone can generate documents

// Generic field updater: updateField("ss","ss1","mat",85) or updateField("pilots","p1","viab",90)
var updateField=function(col,eid,field,val){
  setD(function(d){
    if(!d[col])return d;
    var arr=d[col].slice();
    var idx=arr.findIndex(function(x){return x.id===eid;});
    if(idx<0)return d;
    var updated=Object.assign({},arr[idx]);
    updated[field]=val;
    arr[idx]=updated;
    var out={};out[col]=arr;
    return Object.assign({},d,out);
  });
  addLog("Edited "+col+"/"+eid+"."+field);
};
// Update array field: updateArrayField("ss","ss1","d",["new","items"])
var updateArrayField=function(col,eid,field,arr){
  updateField(col,eid,field,arr);
};
// Update finance directly
var updateFin=function(field,val){
  setD(function(d){var fin=Object.assign({},d.fin);fin[field]=val;return Object.assign({},d,{fin:fin});});
  addLog("Edited finance."+field);
};

var onUpload=function(nodeId,file){setFiles(function(prev){var n=Object.assign({},prev);n[nodeId]=(n[nodeId]||[]).concat([file]);return n;});};
var onRemove=function(nodeId,idx){setFiles(function(prev){var n=Object.assign({},prev);var arr=(n[nodeId]||[]).slice();arr.splice(idx,1);n[nodeId]=arr;return n;});};

var addLog=useCallback(function(t){setD(function(d){return Object.assign({},d,{log:[{t:t,at:nw()}].concat(d.log)});});},[]);
var addNote=function(col,eid,txt){setD(function(d){var a=d[col].slice();var i=a.findIndex(function(x){return x.id===eid;});if(i<0)return d;a[i]=Object.assign({},a[i],{notes:(a[i].notes||[]).concat([{t:txt,by:"JM",at:nw()}])});var u={};u[col]=a;return Object.assign({},d,u);});};
var advP=function(pid){var stg=["Identified","Contact","Site Visit","Line Analysis","Bottleneck Map","Automation Score","Proposal","Pilot"];setD(function(d){var ps=d.pilots.slice();var i=ps.findIndex(function(p){return p.id===pid;});if(i<0)return d;var si=stg.indexOf(ps[i].stage);if(si>=stg.length-1)return d;ps[i]=Object.assign({},ps[i],{stage:stg[si+1]});return Object.assign({},d,{pilots:ps});});addLog("Pilot advanced");};
var advI=function(iid){var stg=["Identified","Researched","Warm Intro","1st Meeting","Follow-up","Due Diligence","Term Sheet","Closed"];setD(function(d){var is=d.investors.slice();var i=is.findIndex(function(x){return x.id===iid;});if(i<0)return d;var si=stg.indexOf(is[i].stage);if(si>=stg.length-1)return d;is[i]=Object.assign({},is[i],{stage:stg[si+1],prob:Math.min(is[i].prob+10,95)});return Object.assign({},d,{investors:is});});addLog("Investor advanced");};
var resInc=function(iid){setD(function(d){var is=d.incidents.slice();var i=is.findIndex(function(x){return x.id===iid;});if(i<0)return d;is[i]=Object.assign({},is[i],{status:"resolved"});return Object.assign({},d,{incidents:is});});addLog("Incident resolved");};
var togTask=function(tid){setD(function(d){var ts=d.tasks.slice();var i=ts.findIndex(function(t){return t.id===tid;});if(i<0)return d;ts[i]=Object.assign({},ts[i],{status:ts[i].status==="done"?"todo":"done"});return Object.assign({},d,{tasks:ts});});addLog("Task toggled");};
var acts={addNote:addNote,advP:advP,advI:advI,resInc:resInc,togTask:togTask,updateField:updateField,updateArrayField:updateArrayField,updateFin:updateFin,canEdit:canEdit,canGen:canGen};

var allSubs=useMemo(function(){var r=[];Object.keys(xp).forEach(function(k){if(xp[k])r=r.concat(getSubs(k,D));});return r;},[xp,D]);
var allSSubs=useMemo(function(){var r=[];Object.keys(xp2).forEach(function(k){if(xp2[k]){var s=allSubs.find(function(x){return x.id===k;});if(s)r=r.concat(getSSubs(s));}});return r;},[xp2,allSubs]);
var oI=D.incidents.filter(function(i){return i.status!=="resolved";}).length;
var cr=D.tasks.filter(function(t){return t.pri==="critical"&&t.status!=="done";}).length;
var am=Math.round(D.ss.reduce(function(a,s){return a+s.mat;},0)/D.ss.length);

// 3D
var makeLabel=function(text,fs,color){var cv=document.createElement("canvas");cv.width=1024;cv.height=512;var ctx=cv.getContext("2d");ctx.font="bold "+(fs||48)+"px monospace";ctx.textAlign="center";ctx.textBaseline="middle";ctx.shadowColor="rgba(0,0,0,0.85)";ctx.shadowBlur=10;ctx.fillStyle=color||"#C8C4BC";ctx.fillText(text,512,256);var tex=new THREE.CanvasTexture(cv);tex.needsUpdate=true;var mat=new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false});var sp=new THREE.Sprite(mat);var sc=3.0*(fs||48)/48;sp.scale.set(sc,sc*0.5,1);sp.userData={dogma:true};return sp;};

useEffect(function(){var el=canvasRef.current;if(!el)return;var W=el.clientWidth;var H=el.clientHeight;var scene=new THREE.Scene();sceneRef.current=scene;var cam=new THREE.PerspectiveCamera(50,W/H,0.1,500);cam.position.set(0,0,24);camRef.current=cam;var rend=new THREE.WebGLRenderer({canvas:el,antialias:true,alpha:true});rend.setSize(W,H);rend.setPixelRatio(Math.min(window.devicePixelRatio,2));rend.setClearColor(0x030308,1);rendRef.current=rend;scene.add(new THREE.AmbientLight(0xffffff,0.4));var dl=new THREE.DirectionalLight(0xC8A74B,0.5);dl.position.set(5,8,15);scene.add(dl);
var anim=function(){frameRef.current=requestAnimationFrame(anim);var t=Date.now()*0.001;
// Animate all dogma meshes
scene.children.forEach(function(c){if(c.userData&&c.userData.dogma){
  if(c.type==="Mesh"){
    // Floating motion — each node oscillates differently based on position
    var ox=c.userData.origX;var oy=c.userData.origY;var oz=c.userData.origZ;
    if(ox!==undefined){
      c.position.x=ox+Math.sin(t*0.5+ox*2)*0.15;
      c.position.y=oy+Math.cos(t*0.4+oy*3)*0.12;
      c.position.z=oz+Math.sin(t*0.3+oz)*0.08;
    }
    // Pulse opacity
    if(c.material&&c.material.opacity!==undefined){c.material.opacity=0.72+Math.sin(t*1.5+c.position.x)*0.1;}
  }
  if(c.type==="Line"){
    // Pulse line opacity
    if(c.material)c.material.opacity=0.15+Math.sin(t*2+c.position.x)*0.08;
  }
  if(c.type==="Sprite"){
    // Subtle label float
    var sx=c.userData.origSX;var sy=c.userData.origSY;
    if(sx!==undefined){
      c.position.x=sx+Math.sin(t*0.5+sx*2)*0.15;
      c.position.y=sy+Math.cos(t*0.4+sy*3)*0.12+0.02*Math.sin(t*2);
    }
  }
}});
rend.render(scene,cam);var rect=el.getBoundingClientRect();var nv=[];var all=[];NODES.forEach(function(n){all.push({id:n.id,pos:n.pos,level:"main",label:n.label,r:n.r});});if(overlayRef.current.subs)(overlayRef.current.subs).forEach(function(s){all.push(s);});if(overlayRef.current.ssubs)(overlayRef.current.ssubs).forEach(function(s){all.push(s);});all.forEach(function(n){var v=new THREE.Vector3(n.pos[0],n.pos[1],n.pos[2]);v.project(cam);if(v.z>0&&v.z<1)nv.push({id:n.id,x:(v.x*0.5+0.5)*rect.width,y:(-v.y*0.5+0.5)*rect.height,level:n.level,label:n.label,r:n.r||0.4});});overlayRef.current.pos=nv;};anim();
var intv=setInterval(function(){if(overlayRef.current.pos)setOverlay(overlayRef.current.pos);},100);
var onR=function(){W=el.clientWidth;H=el.clientHeight;cam.aspect=W/H;cam.updateProjectionMatrix();rend.setSize(W,H);};window.addEventListener("resize",onR);return function(){cancelAnimationFrame(frameRef.current);clearInterval(intv);window.removeEventListener("resize",onR);rend.dispose();};},[]);

useEffect(function(){var scene=sceneRef.current;if(!scene)return;var rem=[];scene.children.forEach(function(c){if(c.userData&&c.userData.dogma)rem.push(c);});rem.forEach(function(c){scene.remove(c);if(c.geometry)c.geometry.dispose();if(c.material){if(c.material.map)c.material.map.dispose();c.material.dispose();}});
NODES.forEach(function(n){var g=new THREE.SphereGeometry(n.r,32,32);var m=new THREE.MeshPhongMaterial({color:n.color,transparent:true,opacity:0.82,shininess:50});var me=new THREE.Mesh(g,m);me.position.set(n.pos[0],n.pos[1],n.pos[2]);me.userData={dogma:true,origX:n.pos[0],origY:n.pos[1],origZ:n.pos[2]};scene.add(me);var l=makeLabel(n.label,n.center?64:48,"#C8A74B");l.position.set(n.pos[0],n.pos[1]+n.r+0.6,n.pos[2]);l.userData.origSX=n.pos[0];l.userData.origSY=n.pos[1]+n.r+0.6;scene.add(l);});
LINKS.forEach(function(lk){var a=NODES.find(function(n){return n.id===lk[0];});var b=NODES.find(function(n){return n.id===lk[1];});if(!a||!b)return;var aExp=lk[0]==="command"||!!xp[lk[0]];var bExp=lk[1]==="command"||!!xp[lk[1]];if(!aExp&&!bExp)return;var mid=new THREE.Vector3((a.pos[0]+b.pos[0])/2,(a.pos[1]+b.pos[1])/2+0.3,(a.pos[2]+b.pos[2])/2);var crv=new THREE.QuadraticBezierCurve3(new THREE.Vector3(a.pos[0],a.pos[1],a.pos[2]),mid,new THREE.Vector3(b.pos[0],b.pos[1],b.pos[2]));var g=new THREE.BufferGeometry().setFromPoints(crv.getPoints(24));var m=new THREE.LineBasicMaterial({color:0xffffff,transparent:true,opacity:0.07});var ln=new THREE.Line(g,m);ln.userData={dogma:true};scene.add(ln);});
allSubs.forEach(function(sub){var cH=typeof sub.color==="string"?parseInt(sub.color.replace("#",""),16):0x6E6A84;var g=new THREE.SphereGeometry(sub.r,20,20);var m=new THREE.MeshPhongMaterial({color:cH||0x6E6A84,transparent:true,opacity:0.72});var me=new THREE.Mesh(g,m);me.position.set(sub.pos[0],sub.pos[1],sub.pos[2]);me.userData={dogma:true,origX:sub.pos[0],origY:sub.pos[1],origZ:sub.pos[2]};scene.add(me);var lt=(sub.label+(sub.metric?" "+sub.metric:"")).slice(0,22);var l=makeLabel(lt,32,"#C8C4BC");l.position.set(sub.pos[0],sub.pos[1]+sub.r+0.3,sub.pos[2]);l.userData.origSX=sub.pos[0];l.userData.origSY=sub.pos[1]+sub.r+0.3;scene.add(l);var p=NODES.find(function(n){return n.id===sub.parent;});if(p){var g2=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(p.pos[0],p.pos[1],p.pos[2]),new THREE.Vector3(sub.pos[0],sub.pos[1],sub.pos[2])]);var m2=new THREE.LineBasicMaterial({color:0xffffff,transparent:true,opacity:0.05});var ln2=new THREE.Line(g2,m2);ln2.userData={dogma:true};scene.add(ln2);}});
allSSubs.forEach(function(ssn){var g=new THREE.SphereGeometry(ssn.r,10,10);var m=new THREE.MeshPhongMaterial({color:0x444060,transparent:true,opacity:0.45});var me=new THREE.Mesh(g,m);me.position.set(ssn.pos[0],ssn.pos[1],ssn.pos[2]);me.userData={dogma:true,origX:ssn.pos[0],origY:ssn.pos[1],origZ:ssn.pos[2]};scene.add(me);var l=makeLabel(ssn.label.slice(0,18),24,"#6E6A84");l.position.set(ssn.pos[0],ssn.pos[1]+ssn.r+0.15,ssn.pos[2]);l.userData.origSX=ssn.pos[0];l.userData.origSY=ssn.pos[1]+ssn.r+0.15;scene.add(l);scene.add(l);var ps=allSubs.find(function(s){return ssn.id.startsWith(s.id+"_");});if(ps){var g2=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(ps.pos[0],ps.pos[1],ps.pos[2]),new THREE.Vector3(ssn.pos[0],ssn.pos[1],ssn.pos[2])]);var m2=new THREE.LineBasicMaterial({color:0xffffff,transparent:true,opacity:0.03});var ln2=new THREE.Line(g2,m2);ln2.userData={dogma:true};scene.add(ln2);}});
overlayRef.current.subs=allSubs.map(function(s){return{id:s.id,pos:s.pos,level:"sub",label:s.label,r:s.r};});
overlayRef.current.ssubs=allSSubs.map(function(s){return{id:s.id,pos:s.pos,level:"ssub",label:s.label,r:s.r};});
},[allSubs,allSSubs,oI,xp]);

// Controls
var onWheel=function(e){e.preventDefault();var cam=camRef.current;if(!cam)return;zoomRef.current=Math.max(1.5,Math.min(120,zoomRef.current+e.deltaY*0.03));var dr=dragRef.current;var d=zoomRef.current;cam.position.x=-panRef.current.x+d*Math.sin(dr.ry||0)*Math.cos(dr.rx||0);cam.position.y=-panRef.current.y+d*Math.sin(dr.rx||0);cam.position.z=d*Math.cos(dr.ry||0)*Math.cos(dr.rx||0);cam.lookAt(-panRef.current.x,-panRef.current.y,0);};
var onDown=function(e){var isOrbit=e.button===2||e.shiftKey;dragRef.current=Object.assign({},dragRef.current,{active:true,moved:false,mode:isOrbit?"orbit":"pan",sx:e.clientX,sy:e.clientY,px:panRef.current.x,py:panRef.current.y});};
var onMove=function(e){var dr=dragRef.current;if(!dr.active)return;if(Math.abs(e.clientX-dr.sx)<4&&Math.abs(e.clientY-dr.sy)<4)return;dr.moved=true;var cam=camRef.current;if(!cam)return;if(dr.mode==="orbit"){var dx=(e.clientX-dr.sx)*0.005;var dy=(e.clientY-dr.sy)*0.005;dr.ry=(dr.ry||0)+dx;dr.rx=Math.max(-1.2,Math.min(1.2,(dr.rx||0)+dy));dr.sx=e.clientX;dr.sy=e.clientY;var d=zoomRef.current;cam.position.x=-panRef.current.x+d*Math.sin(dr.ry)*Math.cos(dr.rx);cam.position.y=-panRef.current.y+d*Math.sin(dr.rx);cam.position.z=d*Math.cos(dr.ry)*Math.cos(dr.rx);cam.lookAt(-panRef.current.x,-panRef.current.y,0);}else{var el=canvasRef.current;if(!el)return;var fov=cam.fov*Math.PI/180;var hVis=2*Math.tan(fov/2)*zoomRef.current;var sc=hVis/el.clientHeight;panRef.current={x:dr.px+(e.clientX-dr.sx)*sc,y:dr.py-(e.clientY-dr.sy)*sc};cam.position.x=-panRef.current.x+zoomRef.current*Math.sin(dr.ry||0)*Math.cos(dr.rx||0);cam.position.y=-panRef.current.y+zoomRef.current*Math.sin(dr.rx||0);cam.position.z=zoomRef.current*Math.cos(dr.ry||0)*Math.cos(dr.rx||0);cam.lookAt(-panRef.current.x,-panRef.current.y,0);}};
var onUp=function(){dragRef.current.active=false;};
// Single click = expand/collapse sub-nodes. Double click = open page.
var lastClickRef=useRef({id:"",time:0});
var onNodeClick=function(id,level){
  var now2=Date.now();var last=lastClickRef.current;
  var isDbl=(last.id===id&&now2-last.time<400);
  lastClickRef.current={id:id,time:now2};
  if(isDbl){
    // DOUBLE CLICK — open full page
    setSel({level:level,id:id});
  }else{
    // SINGLE CLICK — expand/collapse children
    if(level==="main"&&id!=="command"){setXp(function(p){var n=Object.assign({},p);n[id]=!p[id];return n;});}
    else if(level==="sub"){setXp2(function(p){var n=Object.assign({},p);n[id]=!p[id];return n;});}
  }
};

useEffect(function(){var h=function(e){if(e.key==="Escape"){setSel(null);setSearchOpen(false);setSearch("");}};window.addEventListener("keydown",h);return function(){window.removeEventListener("keydown",h);};},[]);
useEffect(function(){if(chatEnd.current)chatEnd.current.scrollIntoView({behavior:"smooth"});},[msgs,agentId]);

var curAgent=AGENTS.find(function(a){return a.id===agentId;})||AGENTS[0];
var curMsgs=(msgs[agentId]||[]);
// ── File generators ──
var _gf=useState([]),genFiles=_gf[0],setGF=_gf[1];
var dlAndStore=function(blob,name,icon){
  var url=URL.createObjectURL(blob);
  var a=document.createElement("a");a.href=url;a.download=name;document.body.appendChild(a);a.click();document.body.removeChild(a);
  setGF(function(p){return[{name:name,url:url,icon:icon||"\uD83D\uDCC1",at:nw()}].concat(p);});
  return name;
};
var genCSV=function(title,headers,rows){
  var csv="\uFEFF"+headers.join(",")+"\n"+rows.map(function(r){return r.map(function(c){return'"'+String(c).replace(/"/g,'""')+'"';}).join(",");}).join("\n");
  return dlAndStore(new Blob([csv],{type:"text/csv;charset=utf-8"}),title+".csv","\uD83D\uDCC8");
};
var genDOCX=function(title,html){
  var h='<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><style>body{font-family:Calibri,sans-serif;font-size:11pt;max-width:700px;margin:auto}h1{font-size:18pt;color:#C8A74B;border-bottom:2px solid #C8A74B}h2{font-size:14pt;margin-top:16px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #CBD5E0;padding:6px 10px}th{background:#EDF2F7}</style></head><body><h1>'+title+'</h1><p style="font-size:9pt;color:#718096">DOGMA Robotics | '+nw()+'</p>'+html+'</body></html>';
  return dlAndStore(new Blob([h],{type:"application/msword"}),title.replace(/\s+/g,"_")+".doc","\uD83D\uDCC4");
};
var genPDF=function(title,html){
  var w=window.open("","_blank");if(!w)return title+".pdf (popup blocked)";
  w.document.write('<html><head><title>'+title+'</title><style>body{font-family:Helvetica,sans-serif;padding:40px;max-width:700px;margin:auto}h1{color:#C8A74B;border-bottom:2px solid #C8A74B}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:5px 8px}th{background:#f5f5f5}</style></head><body><h1>'+title+'</h1><p style="font-size:8pt;color:#999">'+nw()+'</p>'+html+'<script>setTimeout(function(){window.print()},500)<\/script></body></html>');
  w.document.close();setGF(function(p){return[{name:title+".pdf",url:"#",icon:"\uD83D\uDCCB",at:nw()}].concat(p);});return title+".pdf";
};
var genPPTX=function(title,slides){
  var sh=(slides||[]).map(function(s,i){return'<div style="page-break-after:always;width:960px;height:540px;padding:60px;box-sizing:border-box;background:'+(i===0?'#0A0A18':'#fff')+';color:'+(i===0?'#C8A74B':'#1a1a2e')+'"><h1>'+s.title+'</h1><div style="font-size:14pt">'+s.body+'</div></div>';}).join("");
  return dlAndStore(new Blob(['<html><head><style>@page{size:960px 540px;margin:0}body{margin:0}</style></head><body>'+sh+'</body></html>'],{type:"application/vnd.ms-powerpoint"}),title+".ppt","\uD83D\uDCCA");
};
var genLatex=function(title,content){
  var tex="\\documentclass{article}\n\\usepackage[margin=1in]{geometry}\n\\usepackage{booktabs,hyperref}\n\\title{"+title+"}\n\\author{DOGMA Robotics}\n\\date{\\today}\n\\begin{document}\n\\maketitle\n"+content+"\n\\end{document}";
  return dlAndStore(new Blob([tex],{type:"application/x-tex"}),title.replace(/\s/g,"_")+".tex","\uD83D\uDCDD");
};

function FileCard({file}){
  return <div style={{display:"flex",alignItems:"center",gap:8,padding:"8px 10px",background:C.bg,border:"1px solid "+C.gold+"30",borderRadius:4,marginTop:4,cursor:"pointer"}} onClick={function(){if(file.url&&file.url!=="#"){var a=document.createElement("a");a.href=file.url;a.download=file.name;a.click();}}}>
    <span style={{fontSize:20}}>{file.icon}</span>
    <div style={{flex:1}}><div style={{fontSize:13,fontWeight:600,color:C.tx}}>{file.name}</div><div style={{fontSize:10,color:C.tx3}}>Click to re-download | {file.at}</div></div>
    <span style={{fontSize:12,color:C.gold,fontWeight:700}}>\u2B07</span>
  </div>;
}


// Tool definitions
// Data tools (require admin auth)
var DATA_TOOLS=[
{name:"update_field",description:"Update any field on any entity",input_schema:{type:"object",properties:{collection:{type:"string"},entity_id:{type:"string"},field:{type:"string"},value:{type:"string"}},required:["collection","entity_id","field","value"]}},
{name:"add_note",description:"Add note to entity",input_schema:{type:"object",properties:{collection:{type:"string"},entity_id:{type:"string"},text:{type:"string"}},required:["collection","entity_id","text"]}},
{name:"advance_pilot",description:"Advance pilot stage",input_schema:{type:"object",properties:{pilot_id:{type:"string"}},required:["pilot_id"]}},
{name:"advance_investor",description:"Advance investor stage",input_schema:{type:"object",properties:{investor_id:{type:"string"}},required:["investor_id"]}},
{name:"resolve_incident",description:"Resolve incident",input_schema:{type:"object",properties:{incident_id:{type:"string"}},required:["incident_id"]}},
{name:"complete_task",description:"Complete task",input_schema:{type:"object",properties:{task_id:{type:"string"}},required:["task_id"]}},
];
// File tools (always available to everyone)
var FILE_TOOLS=[
{name:"generate_csv",description:"Generate+download CSV spreadsheet",input_schema:{type:"object",properties:{title:{type:"string"},headers:{type:"array",items:{type:"string"}},rows:{type:"array",items:{type:"array",items:{type:"string"}}}},required:["title","headers","rows"]}},
{name:"generate_docx",description:"Generate+download Word .doc",input_schema:{type:"object",properties:{title:{type:"string"},html:{type:"string"}},required:["title","html"]}},
{name:"generate_pdf",description:"Generate PDF via print dialog",input_schema:{type:"object",properties:{title:{type:"string"},html:{type:"string"}},required:["title","html"]}},
{name:"generate_pptx",description:"Generate+download PowerPoint .ppt",input_schema:{type:"object",properties:{title:{type:"string"},slides:{type:"array",items:{type:"object",properties:{title:{type:"string"},body:{type:"string"}},required:["title","body"]}}},required:["title","slides"]}},
{name:"generate_latex",description:"Generate+download LaTeX .tex",input_schema:{type:"object",properties:{title:{type:"string"},content:{type:"string"}},required:["title","content"]}},
];

var execLocal=function(name,input){
  // File tools — always allowed for everyone
  if(name==="generate_csv"){return"FILE:"+genCSV(input.title,input.headers,input.rows);}
  if(name==="generate_docx"){return"FILE:"+genDOCX(input.title,input.html);}
  if(name==="generate_pdf"){return"FILE:"+genPDF(input.title,input.html);}
  if(name==="generate_pptx"){return"FILE:"+genPPTX(input.title,input.slides);}
  if(name==="generate_latex"){return"FILE:"+genLatex(input.title,input.content);}
  // Data tools — require admin password
  if(!canEdit)return"DENIED: Admin login required to modify data.";
  if(name==="update_field"){var v=input.value;var nv=isNaN(Number(v))?v:Number(v);acts.updateField(input.collection,input.entity_id,input.field,nv);return"Updated "+input.collection+"/"+input.entity_id+"."+input.field+"="+v;}
  if(name==="add_note"){acts.addNote(input.collection,input.entity_id,input.text);return"Note added";}
  if(name==="advance_pilot"){acts.advP(input.pilot_id);return"Pilot advanced";}
  if(name==="advance_investor"){acts.advI(input.investor_id);return"Investor advanced";}
  if(name==="resolve_incident"){acts.resInc(input.incident_id);return"Incident resolved";}
  if(name==="complete_task"){acts.togTask(input.task_id);return"Task completed";}
  return"OK";
};

// Multi-turn tool_use loop
// Launch swarm workflow
var launchSwarm=function(){
  if(!swarmObjective.trim()||swarmLoading)return;
  setSwarmLoading(true);setSwarmResult(null);
  var dataSnap="SS:"+D.ss.map(function(s){return s.id+":"+s.name+" "+s.mat+"%";}).join(",")+"|Pilots:"+D.pilots.map(function(p){return p.name+" "+p.viab+"%";}).join(",")+"|Runway:"+D.fin.runway+"mo|Burn:$"+D.fin.burn;
  fetch("/api/orchestrate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({workflow:selWorkflow,objective:swarmObjective,dataContext:dataSnap})})
  .then(function(r){return r.json();})
  .then(function(data){setSwarmResult(data);setSwarmLoading(false);})
  .catch(function(e){setSwarmResult({error:String(e)});setSwarmLoading(false);});
};

var sendAgent=function(){if(!inp.trim()||ld)return;var userTxt=inp.trim();setInp("");
  setMsgs(function(prev){var n=Object.assign({},prev);n[agentId]=(n[agentId]||[]).concat([{role:"user",text:userTxt}]);return n;});
  setLd(true);

  var dataSnap="SS:"+D.ss.map(function(s){return s.id+":"+s.name+" "+s.mat+"%";}).join(",")+
  "|Skills:"+D.skills.map(function(s){return s.id+":"+s.name+" "+s.success+"%";}).join(",")+
  "|Tasks:"+D.tasks.map(function(t){return t.id+":"+t.title+"("+t.pri+"/"+t.status+")";}).join(",")+
  "|Pilots:"+D.pilots.map(function(p){return p.id+":"+p.name+" "+p.viab+"%";}).join(",")+
  "|Inv:"+D.investors.map(function(v){return v.id+":"+v.name+" "+v.prob+"%";}).join(",")+
  "|Inc:"+D.incidents.map(function(i){return i.id+":"+i.status;}).join(",")+
  "|Fleet:"+D.fleet.map(function(f){return f.id+":"+f.unit+" "+f.health+"%";}).join(",")+
  "|Fin:burn=$"+D.fin.burn+",cash=$"+D.fin.cash+",runway="+D.fin.runway+"mo";

  var agentRisks=calcRisks(D);
  if(agentRisks.length>0)dataSnap+="|RISKS:"+agentRisks.slice(0,5).map(function(r){return"["+r.sev+"]"+r.msg;}).join(",");
  if(D.deps&&D.deps.length>0)dataSnap+="|DEPS:"+D.deps.map(function(d){return d.from+"->"+d.blocks.join("+");}).join(",");
  if(D.pilotDeadlines)dataSnap+="|DEADLINES:"+Object.keys(D.pilotDeadlines).map(function(k){return k+":"+D.pilotDeadlines[k].needBy;}).join(",");

  // Backend handles tool_use loop + MCP connections
  fetch("/api/chat",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({message:userTxt,agentId:agentId,dataContext:dataSnap})
  })
  .then(function(r){return r.json();})
  .then(function(data){
    var text=data.text||"(empty)";
    var files=(data.files||[]).map(function(f){return{name:f.name,icon:f.type==="csv"?"\uD83D\uDCC8":f.type==="doc"?"\uD83D\uDCC4":f.type==="ppt"?"\uD83D\uDCCA":f.type==="tex"?"\uD83D\uDCDD":f.type==="pdf"?"\uD83D\uDCC4":"\uD83D\uDCCB",url:f.url,at:nw()};});
    var mutations=data.mutations||[];
    setMsgs(function(prev){var n=Object.assign({},prev);n[agentId]=(n[agentId]||[]).concat([{role:"ai",text:text,files:files,mutations:mutations}]);return n;});
    // If agent made data mutations, refresh local state from Supabase
    if(mutations.length>0){
      fetch("/api/data").then(function(r){return r.json();}).then(function(fresh){if(fresh&&fresh.data)setD(fresh.data);}).catch(function(){});
    }
  })
  .catch(function(err){
    setMsgs(function(prev){var n=Object.assign({},prev);n[agentId]=(n[agentId]||[]).concat([{role:"ai",text:"Network error: "+String(err)}]);return n;});
  })
  .finally(function(){setLd(false);});
};

// Page content
var pageTitle="";var pageContent=null;
if(sel){
  if(sel.level==="main"){pageTitle=sel.id.toUpperCase();pageContent=<MainPage nid={sel.id} D={D} files={files} onUpload={onUpload} onRemove={onRemove} acts={acts}/>;}
  else if(sel.level==="sub"){var sn=allSubs.find(function(s){return s.id===sel.id;});if(sn){pageTitle=sn.label;pageContent=<SubPage sub={sn} D={D} acts={acts} files={files} onUpload={onUpload} onRemove={onRemove}/>;}}
  else if(sel.level==="ssub"){var ssn2=allSSubs.find(function(s){return s.id===sel.id;});if(ssn2){pageTitle=ssn2.label;pageContent=<LeafPage leaf={ssn2}/>;}}
}

return(<div style={{width:"100vw",height:"100vh",overflow:"hidden",background:C.bg,display:"flex",flexDirection:"column",fontFamily:"'Instrument Sans',sans-serif",color:C.tx}}>
  {/* Top Bar */}
  <div style={{height:42,background:C.bg1,borderBottom:"1px solid "+C.bd,display:"flex",alignItems:"center",padding:"0 16px",gap:12,flexShrink:0,zIndex:30}}>
    <div style={{display:"flex",alignItems:"center",gap:6}}><div style={{width:22,height:22,background:C.gold,borderRadius:3,display:"flex",alignItems:"center",justifyContent:"center"}}><span style={{color:C.bg,fontWeight:900,fontSize:12,fontFamily:"monospace"}}>D</span></div><span style={{fontSize:13,fontWeight:700,color:C.gold}}>DOGMA OS</span></div><a href="/settings" style={{color:C.tx3,fontSize:11,textDecoration:"none"}}>⚙ Connections</a>
    <div style={{width:1,height:18,background:C.bd}}/><span style={{fontSize:12,color:C.tx2}}>{dy()}</span>
    <div style={{position:"relative"}}>
      <input value={search} onChange={function(e){setSearch(e.target.value);setSearchOpen(e.target.value.length>=2);}} onFocus={function(){if(search.length>=2)setSearchOpen(true);}} placeholder="Search nodes, tasks, pilots..." style={{width:220,padding:"4px 10px 4px 26px",fontSize:12,background:C.bg,border:"1px solid "+C.bd,borderRadius:3,color:C.tx,outline:"none"}}/>
      <span style={{position:"absolute",left:8,top:5,fontSize:12,color:C.tx3}}>{"\uD83D\uDD0D"}</span>
      {searchOpen&&searchResults.length>0&&<div style={{position:"absolute",top:30,left:0,width:350,maxHeight:400,overflowY:"auto",background:C.bg1,border:"1px solid "+C.bd,borderRadius:6,zIndex:50,boxShadow:"0 8px 24px rgba(0,0,0,0.5)"}}>
        {searchResults.map(function(r,i){return <div key={i} onClick={function(){
          if(r.level==="main"){setSel({level:"main",id:r.id});if(r.id!=="command")setXp(function(p){var n=Object.assign({},p);n[r.id]=true;return n;});}
          else{setXp(function(p){var n=Object.assign({},p);n[r.parent]=true;return n;});setSel({level:"sub",id:r.id});}
          setSearch("");setSearchOpen(false);
        }} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 12px",cursor:"pointer",borderBottom:"1px solid "+C.bd+"40"}} onMouseEnter={function(e){e.currentTarget.style.background=C.bg3;}} onMouseLeave={function(e){e.currentTarget.style.background="transparent";}}>
          <div style={{width:8,height:8,borderRadius:"50%",background:r.color,flexShrink:0}}/>
          <div style={{flex:1}}>
            <div style={{fontSize:13,color:C.tx,fontWeight:500}}>{r.label}</div>
            <div style={{fontSize:10,color:C.tx3}}>{r.type}{r.parent?" \u2022 "+r.parent:""}</div>
          </div>
          <span style={{fontSize:12,fontFamily:"'JetBrains Mono',monospace",color:r.color}}>{r.metric}</span>
        </div>;})}
      </div>}
    </div>
    <div style={{flex:1}}/>
    {[["RUN",D.fin.runway+"mo",D.fin.runway<4?C.r:C.a],["INC",oI,oI?C.r:C.g],["CRIT",cr,cr?C.r:C.g],["MAT",am+"%",am>60?C.g:C.a],["PILOTS",D.pilots.length,C.gold]].map(function(x,i){return <div key={i} style={{display:"flex",alignItems:"center",gap:4,padding:"0 6px"}}><span style={{fontSize:9,color:C.tx3}}>{x[0]}</span><span style={{fontSize:14,fontWeight:600,color:x[2],fontFamily:"monospace"}}>{x[1]}</span></div>;})}
    <div style={{width:1,height:18,background:C.bd}}/>
    <div onClick={function(){if(authed){setAuthed(false);}else{setShowLogin(true);}}} style={{display:"flex",alignItems:"center",gap:4,padding:"3px 10px",borderRadius:3,cursor:"pointer",background:authed?C.g+"15":C.bg3,border:"1px solid "+(authed?C.g+"30":C.bd)}}>
      <span style={{fontSize:12}}>{authed?"\uD83D\uDD13":"\uD83D\uDD12"}</span>
      <span style={{fontSize:10,color:authed?C.g:C.a,fontWeight:600}}>{authed?"ADMIN":"\uD83D\uDCC4 DOCS"}</span>
    </div>
  </div>

  {/* Main area — 3D/Page left + Chat right */}
  <div style={{flex:1,display:"flex",overflow:"hidden",position:"relative"}}>
    {/* Left: 3D always visible + Page overlay */}
    <div style={{flex:2,position:"relative",display:"flex",flexDirection:"column",overflow:"hidden"}}>
      {/* 3D always rendered */}
      <div style={{position:"absolute",inset:0}}>
      <canvas ref={canvasRef} style={{width:"100%",height:"100%",cursor:"grab"}} onWheel={onWheel} onMouseDown={onDown} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp} onContextMenu={function(e){e.preventDefault();}}/>
      <div style={{position:"absolute",inset:0,pointerEvents:"none",overflow:"hidden"}}>
        {overlay.map(function(ov){var sz=ov.level==="main"?30:ov.level==="sub"?20:14;return <div key={ov.id} onClick={function(e){e.stopPropagation();onNodeClick(ov.id,ov.level);}} style={{position:"absolute",left:ov.x-sz/2,top:ov.y-sz/2,width:sz,height:sz,borderRadius:"50%",cursor:"pointer",pointerEvents:"auto"}} title={ov.label}/>;})}</div>
      <div style={{position:"absolute",bottom:8,left:12,fontSize:10,color:C.tx3,fontFamily:"monospace",background:C.bg1+"cc",padding:"3px 8px",borderRadius:2}}>Drag=pan | Shift+drag=orbit | Scroll=zoom | Click=expand | Double-click=open page</div>
      </div>

      {/* Page overlay on top of 3D */}
      {sel&&<div style={{position:"absolute",inset:0,background:C.bg+"f0",zIndex:5,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        <div style={{padding:"10px 20px",borderBottom:"1px solid "+C.bd,display:"flex",alignItems:"center",gap:10,flexShrink:0,background:C.bg1}}>
          <div onClick={function(){
            if(sel.level==="ssub"){var pid=sel.id.split("_").slice(0,-1).join("_");var ps=allSubs.find(function(s){return s.id===pid;});if(ps){setSel({level:"sub",id:ps.id});return;}}
            if(sel.level==="sub"){var sn=allSubs.find(function(s){return s.id===sel.id;});if(sn&&sn.parent){setSel({level:"main",id:sn.parent});return;}}
            setSel(null);
          }} style={{cursor:"pointer",padding:"4px 10px",background:C.bg3,border:"1px solid "+C.bd,borderRadius:3,fontSize:13,color:C.tx2}}>
            {sel.level==="main"?"\u2190 Back to Network":"\u2190 Back"}
          </div>
          <span style={{fontSize:14,fontWeight:700,color:C.gold,textTransform:"uppercase",letterSpacing:"0.06em"}}>{pageTitle}</span>
          <div style={{flex:1}}/>
          <span onClick={function(){setSel(null);}} style={{cursor:"pointer",color:C.tx3,fontSize:18}}>x</span>
        </div>
        <div style={{flex:1,overflowY:"auto",padding:"16px 24px",maxWidth:800}}>{pageContent||<div style={{color:C.tx3}}>No data available.</div>}</div>
      </div>}
    </div>

    {/* Right: Agent Panel (resizable) */}
    <div style={{width:chatW,minWidth:240,borderLeft:"1px solid "+C.bd,background:C.bg1,display:"flex",flexShrink:0,position:"relative"}}>
      {/* Resize handle */}
      <div onMouseDown={function(e){e.preventDefault();resizeRef.current=true;document.body.style.cursor="col-resize";document.body.style.userSelect="none";}} style={{position:"absolute",left:-3,top:0,bottom:0,width:6,cursor:"col-resize",zIndex:10,background:"transparent"}} onMouseEnter={function(e){e.currentTarget.style.background=C.gold+"30";}} onMouseLeave={function(e){if(!resizeRef.current)e.currentTarget.style.background="transparent";}}/>
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>

      {/* Mode toggle: Chat / Swarm */}
      <div style={{display:"flex",borderBottom:"1px solid "+C.bd,flexShrink:0}}>
        <div onClick={function(){setMode("chat");}} style={{flex:1,padding:"8px 0",textAlign:"center",fontSize:12,fontWeight:600,cursor:"pointer",color:mode==="chat"?C.gold:C.tx3,borderBottom:mode==="chat"?"2px solid "+C.gold:"2px solid transparent",background:mode==="chat"?C.gold+"08":"transparent"}}>💬 Chat</div>
        <div onClick={function(){setMode("swarm");}} style={{flex:1,padding:"8px 0",textAlign:"center",fontSize:12,fontWeight:600,cursor:"pointer",color:mode==="swarm"?C.gold:C.tx3,borderBottom:mode==="swarm"?"2px solid "+C.gold:"2px solid transparent",background:mode==="swarm"?C.gold+"08":"transparent"}}>🐝 Swarm</div>
      </div>

      {/* ═══ CHAT MODE ═══ */}
      {mode==="chat"&&<>
      <div style={{padding:"6px 8px",borderBottom:"1px solid "+C.bd,flexShrink:0,maxHeight:160,overflowY:"auto"}}>
        {AGENT_CATEGORIES.map(function(cat){var catAgents=AGENTS.filter(function(a){return a.cat===cat.id;});return <div key={cat.id} style={{marginBottom:4}}>
          <div style={{fontSize:9,color:cat.color,textTransform:"uppercase",letterSpacing:"0.08em",fontWeight:700,marginBottom:2}}>{cat.label}</div>
          <div style={{display:"flex",flexWrap:"wrap",gap:2}}>
          {catAgents.map(function(ag){var isA=agentId===ag.id;return <div key={ag.id} onClick={function(){setAgentId(ag.id);}} title={ag.desc} style={{display:"flex",alignItems:"center",gap:2,padding:"3px 6px",borderRadius:3,cursor:"pointer",background:isA?ag.color+"15":"transparent",border:"1px solid "+(isA?ag.color+"30":C.bd+"50"),transition:"all 0.15s"}}><span style={{fontSize:11}}>{ag.icon}</span><span style={{fontSize:9,fontWeight:600,color:isA?ag.color:C.tx3}}>{ag.name}</span></div>;})}
          </div>
        </div>;})}
      </div>
      <div style={{padding:"8px 10px",borderBottom:"1px solid "+C.bd,flexShrink:0}}>
        <div style={{fontSize:13,fontWeight:700,color:curAgent.color}}>{curAgent.icon} {curAgent.name}</div>
        <div style={{fontSize:11,color:C.tx2,lineHeight:1.4,marginTop:2}}>{curAgent.desc}</div>
      </div>
      <div style={{flex:1,overflowY:"auto",padding:10,display:"flex",flexDirection:"column",gap:4}}>
        {curMsgs.length===0&&<div style={{fontSize:13,color:C.tx3,textAlign:"center",padding:20}}>Ask {curAgent.name}<br/><span style={{fontSize:11}}>Single agent — direct conversation</span></div>}
        {curMsgs.map(function(msg,i){return <div key={i} style={{maxWidth:"90%",alignSelf:msg.role==="user"?"flex-end":"flex-start"}}><div style={{padding:"6px 10px",borderRadius:6,background:msg.role==="user"?C.bg3:C.bg2,borderLeft:msg.role==="ai"?"2px solid "+curAgent.color:"none",fontSize:13,color:C.tx,lineHeight:1.5,whiteSpace:"pre-wrap"}}>{msg.text}</div>{msg.files&&msg.files.length>0&&msg.files.map(function(f,j){return <div key={j} onClick={function(){if(f.url&&f.url!=="#"){var dl=document.createElement("a");dl.href=f.url;dl.download=f.name||"file";document.body.appendChild(dl);dl.click();document.body.removeChild(dl);}}} style={{display:"flex",alignItems:"center",gap:6,padding:"6px 8px",background:C.bg,border:"1px solid "+C.gold+"30",borderRadius:4,marginTop:3,cursor:"pointer"}}><span style={{fontSize:16}}>{f.icon||"\uD83D\uDCC1"}</span><div style={{flex:1}}><div style={{fontSize:12,fontWeight:600,color:C.tx}}>{f.name}</div><div style={{fontSize:9,color:C.tx3}}>Click to download</div></div><span style={{color:C.gold}}>{"\u2B07"}</span></div>;})}</div>;})}
        {ld&&<div style={{fontSize:12,color:curAgent.color,fontStyle:"italic",padding:4}}>{curAgent.name} working...</div>}
        <div ref={chatEnd}/>
      </div>
      <div style={{padding:"8px 10px",borderTop:"1px solid "+C.bd,display:"flex",gap:4,flexShrink:0}}>
        <input value={inp} onChange={function(e){setInp(e.target.value);}} onKeyDown={function(e){if(e.key==="Enter")sendAgent();}} placeholder={"Ask "+curAgent.name+"..."} style={{flex:1,padding:"6px 10px",fontSize:13,background:C.bg,border:"1px solid "+C.bd,borderRadius:3,color:C.tx,outline:"none"}}/>
        <Btn v="gold" onClick={sendAgent}>{"\u2191"}</Btn>
      </div>
      </>}

      {/* ═══ SWARM MODE ═══ */}
      {mode==="swarm"&&<>
      {/* Workflow selector */}
      <div style={{padding:"10px",borderBottom:"1px solid "+C.bd,flexShrink:0}}>
        <div style={{fontSize:11,color:C.tx3,textTransform:"uppercase",marginBottom:6}}>Select Workflow</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:4}}>
          {SWARM_WORKFLOWS.map(function(w){var isSel=selWorkflow===w.id;return <div key={w.id} onClick={function(){setSelWorkflow(w.id);}} style={{padding:"6px 8px",borderRadius:4,cursor:"pointer",background:isSel?C.gold+"12":C.bg,border:"1px solid "+(isSel?C.gold+"40":C.bd),transition:"all 0.15s"}}>
            <div style={{fontSize:12,fontWeight:600,color:isSel?C.gold:C.tx}}>{w.icon} {w.name}</div>
            <div style={{fontSize:9,color:C.tx3,marginTop:2}}>{w.agents} agents</div>
          </div>;})}
        </div>
        {selWorkflow&&<div style={{fontSize:10,color:C.tx2,marginTop:6,padding:"4px 6px",background:C.bg,borderRadius:3}}>{SWARM_WORKFLOWS.find(function(w){return w.id===selWorkflow;})?.desc}</div>}
      </div>

      {/* Objective input */}
      <div style={{padding:"8px 10px",borderBottom:"1px solid "+C.bd,flexShrink:0}}>
        <div style={{fontSize:10,color:C.tx3,textTransform:"uppercase",marginBottom:4}}>20 Agents — unified across Chat & Swarm</div>
        <div style={{display:"flex",flexWrap:"wrap",gap:2,marginBottom:6}}>
          {AGENTS.map(function(a){return <span key={a.id} title={a.desc} style={{fontSize:9,padding:"2px 5px",borderRadius:2,background:a.color+"10",color:a.color,border:"1px solid "+a.color+"20"}}>{a.icon} {a.name}</span>;})}
        </div>
        <textarea value={swarmObjective} onChange={function(e){setSwarmObjective(e.target.value);}} placeholder="Describe the objective for the swarm..." rows={3} style={{width:"100%",padding:"6px 10px",fontSize:13,background:C.bg,border:"1px solid "+C.bd,borderRadius:3,color:C.tx,outline:"none",resize:"vertical",fontFamily:"inherit"}}/>
        <Btn v="gold" onClick={launchSwarm} style={{marginTop:4,width:"100%",opacity:selWorkflow&&swarmObjective.trim()?1:0.4}}>{swarmLoading?"🐝 Swarm running...":"🐝 Launch Swarm"}</Btn>
      </div>

      {/* Swarm results */}
      <div style={{flex:1,overflowY:"auto",padding:10}}>
        {!swarmResult&&!swarmLoading&&<div style={{textAlign:"center",padding:20,color:C.tx3}}>
          <div style={{fontSize:32,marginBottom:8}}>🐝</div>
          <div style={{fontSize:14,fontWeight:600,color:C.tx2}}>Multi-Agent Swarm</div>
          <div style={{fontSize:12,marginTop:4}}>Select a workflow, describe your objective, and launch. Same 20 agents available in Chat mode — here they collaborate in stages.</div>
          <div style={{fontSize:11,marginTop:8,color:C.tx3}}>20 agents • 8 workflows • parallel execution • automatic handoffs</div>
        </div>}

        {swarmLoading&&<div style={{textAlign:"center",padding:20}}>
          <div style={{fontSize:24,marginBottom:8,animation:"pulse 1.5s ease-in-out infinite"}}>🐝</div>
          <div style={{fontSize:13,color:C.gold,fontWeight:600}}>Swarm executing...</div>
          <div style={{fontSize:11,color:C.tx3,marginTop:4}}>Multiple agents working in parallel. This may take 2-5 minutes.</div>
        </div>}

        {swarmResult&&swarmResult.error&&<div style={{padding:10,background:C.r+"15",border:"1px solid "+C.r+"30",borderRadius:4,color:C.r,fontSize:12}}>{swarmResult.error}</div>}

        {swarmResult&&swarmResult.stages&&<div>
          {/* Summary */}
          <div style={{padding:10,background:C.gold+"08",border:"1px solid "+C.gold+"20",borderRadius:6,marginBottom:10}}>
            <div style={{fontSize:12,fontWeight:700,color:C.gold,marginBottom:4}}>🎯 {swarmResult.workflow} — Summary</div>
            <div style={{fontSize:12,color:C.tx,lineHeight:1.6,whiteSpace:"pre-wrap"}}>{swarmResult.summary}</div>
            <div style={{fontSize:10,color:C.tx3,marginTop:6}}>{swarmResult.totalAgents} agents • {swarmResult.totalStages} stages • {swarmResult.topology}</div>
          </div>

          {/* Generated files from swarm */}
          {swarmResult.files&&swarmResult.files.length>0&&<div style={{padding:8,background:C.bg2,borderRadius:4,marginBottom:10,border:"1px solid "+C.gold+"20"}}>
            <div style={{fontSize:10,fontWeight:700,color:C.gold,marginBottom:4}}>📁 Generated Files ({swarmResult.files.length})</div>
            {swarmResult.files.map(function(f,fi){return <div key={fi} onClick={function(){if(f.url){var dl=document.createElement("a");dl.href=f.url;dl.download=f.name||"file";document.body.appendChild(dl);dl.click();document.body.removeChild(dl);}}} style={{display:"flex",alignItems:"center",gap:6,padding:"4px 6px",background:C.bg,border:"1px solid "+C.gold+"20",borderRadius:3,marginBottom:2,cursor:"pointer"}}>
              <span style={{fontSize:14}}>{f.type==="csv"?"\uD83D\uDCC8":f.type==="doc"?"\uD83D\uDCC4":f.type==="ppt"?"\uD83D\uDCCA":f.type==="tex"?"\uD83D\uDCDD":f.type==="pdf"?"\uD83D\uDCC4":"\uD83D\uDCCB"}</span>
              <span style={{fontSize:11,color:C.tx,flex:1}}>{f.name}</span>
              <span style={{color:C.gold,fontSize:11}}>⬇</span>
            </div>;})}
          </div>}

          {/* Stage results */}
          {swarmResult.stages.map(function(stage,si){return <div key={si} style={{marginBottom:8}}>
            <div style={{fontSize:11,fontWeight:700,color:C.gold,padding:"4px 8px",background:C.bg3,borderRadius:3,marginBottom:4}}>Stage {stage.stage}: {stage.name} [{stage.strategy}]</div>
            {stage.agents.map(function(a,ai){return <div key={ai} style={{marginBottom:4,padding:"6px 8px",background:C.bg2,borderRadius:4,borderLeft:"3px solid "+(a.color||C.bd)}}>
              <div style={{fontSize:11,fontWeight:600,color:a.color||C.tx}}>{a.icon} {a.name}</div>
              <div style={{fontSize:12,color:C.tx,lineHeight:1.5,marginTop:3,whiteSpace:"pre-wrap",maxHeight:200,overflowY:"auto"}}>{a.output}</div>
              {a.files&&a.files.length>0&&a.files.map(function(f,fi){return <div key={fi} onClick={function(){if(f.url){var dl=document.createElement("a");dl.href=f.url;dl.download=f.name;document.body.appendChild(dl);dl.click();document.body.removeChild(dl);}}} style={{display:"inline-flex",alignItems:"center",gap:4,padding:"3px 8px",background:C.bg,border:"1px solid "+C.gold+"25",borderRadius:3,marginTop:4,marginRight:4,cursor:"pointer",fontSize:10,color:C.gold}}>📄 {f.name} ⬇</div>;})}
            </div>;})}
          </div>;})}
        </div>}
      </div>
      </>}

    </div>{/* close inner flex */}
    </div>{/* close chat panel */}
  </div>{/* close main area */}
  {/* Login Modal */}
  {showLogin&&<div onClick={function(){setShowLogin(false);setPwErr(false);setPw("");}} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",zIndex:100,display:"flex",alignItems:"center",justifyContent:"center"}}>
    <div onClick={function(e){e.stopPropagation();}} style={{width:320,background:C.bg2,border:"1px solid "+C.bd,borderRadius:6,padding:20}}>
      <div style={{fontSize:16,fontWeight:700,color:C.gold,marginBottom:4}}>Authenticate</div>
      <div style={{fontSize:12,color:C.tx2,marginBottom:12}}>Enter admin password to enable data editing. Document creation is available without login.</div>
      <input value={pw} onChange={function(e){setPw(e.target.value);setPwErr(false);}} onKeyDown={function(e){if(e.key==="Enter")tryLogin();}} type="password" placeholder="Password" autoFocus style={{width:"100%",padding:"8px 12px",fontSize:14,background:C.bg,border:"1px solid "+(pwErr?C.r:C.bd),borderRadius:3,color:C.tx,outline:"none",marginBottom:8}}/>
      {pwErr&&<div style={{fontSize:12,color:C.r,marginBottom:6}}>Incorrect password.</div>}
      <div style={{display:"flex",gap:8}}><Btn v="gold" onClick={tryLogin}>Login</Btn><Btn onClick={function(){setShowLogin(false);setPw("");setPwErr(false);}}>Cancel</Btn></div>
      <div style={{fontSize:10,color:C.tx3,marginTop:10}}>Default: dogma2026</div>
    </div>
  </div>}
  <style>{"@import url('https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&display=swap');*{box-sizing:border-box;margin:0;padding:0}::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:"+C.bg+"}::-webkit-scrollbar-thumb{background:"+C.bd+";border-radius:3px}button:hover{opacity:0.88}input::placeholder{color:"+C.tx3+"}"}</style>
</div>);}
