import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/services'
import { AGENTS, WORKFLOWS, getAgentList, getWorkflowList } from '@/lib/agents'
import { put } from '@vercel/blob'

const API_KEY = process.env.ANTHROPIC_API_KEY!

// ══════════════════════════════════════════════════════════════════
// FILE GENERATION (same as chat route — shared logic)
// ══════════════════════════════════════════════════════════════════

async function storeFile(name: string, type: string, content: string | Buffer, contentType: string): Promise<string> {
  const blob = await put(name, content, { access: 'public', contentType })
  try { await supabase.from('generated_files').insert({ filename: name, filetype: type, blob_url: blob.url, size_bytes: typeof content === 'string' ? content.length : content.length, generated_by: 'swarm' }) } catch (e) {}
  return blob.url
}

// Tool definitions for swarm agents
const SWARM_TOOLS = [
  { name: 'generate_csv', description: 'Generate CSV. Returns download URL.', input_schema: { type: 'object' as const, properties: { title: { type: 'string' }, headers: { type: 'array', items: { type: 'string' } }, rows: { type: 'array', items: { type: 'array', items: { type: 'string' } } } }, required: ['title', 'headers', 'rows'] } },
  { name: 'generate_docx', description: 'Generate Word doc. Returns download URL.', input_schema: { type: 'object' as const, properties: { title: { type: 'string' }, html: { type: 'string' } }, required: ['title', 'html'] } },
  { name: 'generate_pdf', description: 'Generate PDF. Returns download URL.', input_schema: { type: 'object' as const, properties: { title: { type: 'string' }, html: { type: 'string' } }, required: ['title', 'html'] } },
  { name: 'generate_pptx', description: 'Generate PowerPoint. Returns download URL.', input_schema: { type: 'object' as const, properties: { title: { type: 'string' }, slides: { type: 'array', items: { type: 'object', properties: { title: { type: 'string' }, body: { type: 'string' } }, required: ['title', 'body'] } } }, required: ['title', 'slides'] } },
  { name: 'generate_latex', description: 'Generate LaTeX. Returns download URL.', input_schema: { type: 'object' as const, properties: { title: { type: 'string' }, content: { type: 'string' } }, required: ['title', 'content'] } },
]

async function execSwarmTool(name: string, input: any): Promise<{ result: string; fileUrl?: string; fileName?: string }> {
  if (name === 'generate_csv') {
    const csv = '\uFEFF' + input.headers.join(',') + '\n' + input.rows.map((r: string[]) => r.map((c: string) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n')
    const url = await storeFile(input.title + '.csv', 'csv', csv, 'text/csv')
    return { result: 'CSV created', fileUrl: url, fileName: input.title + '.csv' }
  }
  if (name === 'generate_docx') {
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><style>body{font-family:Calibri;font-size:11pt}h1{color:#C8A74B;border-bottom:2px solid #C8A74B}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:6px}th{background:#f5f5f5}</style></head><body><h1>${input.title}</h1><p style="color:#999">DOGMA Robotics | ${new Date().toLocaleDateString()}</p>${input.html}</body></html>`
    const url = await storeFile(input.title.replace(/\s+/g, '_') + '.doc', 'doc', html, 'application/msword')
    return { result: 'Word doc created', fileUrl: url, fileName: input.title + '.doc' }
  }
  if (name === 'generate_pdf') {
    const html = `<!DOCTYPE html><html><head><title>${input.title}</title><style>body{font-family:Helvetica;padding:40px;max-width:700px;margin:auto}h1{color:#C8A74B;border-bottom:2px solid #C8A74B}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:5px}th{background:#f5f5f5}</style></head><body><h1>${input.title}</h1>${input.html}</body></html>`
    const url = await storeFile(input.title + '.html', 'pdf', html, 'text/html')
    return { result: 'PDF created', fileUrl: url, fileName: input.title + '.pdf' }
  }
  if (name === 'generate_pptx') {
    const slides = (input.slides || []).map((s: any, i: number) =>
      `<div style="page-break-after:always;width:960px;height:540px;padding:60px;background:${i === 0 ? '#0A0A18' : '#fff'};color:${i === 0 ? '#C8A74B' : '#1a1a2e'}"><h1>${s.title}</h1><div style="font-size:14pt">${s.body}</div></div>`
    ).join('')
    const html = `<html><head><style>@page{size:960px 540px;margin:0}body{margin:0}</style></head><body>${slides}</body></html>`
    const url = await storeFile(input.title + '.ppt', 'ppt', html, 'application/vnd.ms-powerpoint')
    return { result: 'Presentation created', fileUrl: url, fileName: input.title + '.ppt' }
  }
  if (name === 'generate_latex') {
    const tex = `\\documentclass{article}\n\\usepackage[margin=1in]{geometry}\n\\usepackage{booktabs,hyperref}\n\\title{${input.title}}\n\\author{DOGMA Robotics}\n\\date{\\today}\n\\begin{document}\n\\maketitle\n${input.content}\n\\end{document}`
    const url = await storeFile(input.title.replace(/\s/g, '_') + '.tex', 'tex', tex, 'application/x-tex')
    return { result: 'LaTeX created', fileUrl: url, fileName: input.title + '.tex' }
  }
  return { result: 'Unknown tool: ' + name }
}

// ══════════════════════════════════════════════════════════════════
// AGENT CALL — with tool_use loop for file generation
// ══════════════════════════════════════════════════════════════════

async function callAgent(agentId: string, task: string, ctx: string, prev: string): Promise<{ text: string; files: { name: string; url: string; type: string }[] }> {
  const a = AGENTS[agentId]
  if (!a) return { text: 'Unknown agent: ' + agentId, files: [] }

  const prompt = a.sys + '\n\n--- CONTEXT ---\n' + ctx +
    (prev ? '\n\n--- PREVIOUS AGENTS (build on this) ---\n' + prev : '') +
    '\n\n--- YOUR TASK ---\n' + task

  const messages: any[] = [{ role: 'user', content: prompt }]
  const allText: string[] = []
  const allFiles: { name: string; url: string; type: string }[] = []
  let loops = 0

  while (loops < 4) {
    loops++
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 3000,
        messages,
        tools: SWARM_TOOLS,
      }),
    })
    const d = await r.json()
    if (d.error) return { text: 'Error: ' + (d.error.message || JSON.stringify(d.error)), files: [] }

    const toolResults: any[] = []
    for (const block of (d.content || [])) {
      if (block.type === 'text') allText.push(block.text)
      if (block.type === 'tool_use') {
        const { result, fileUrl, fileName } = await execSwarmTool(block.name, block.input)
        if (fileUrl && fileName) allFiles.push({ name: fileName, url: fileUrl, type: block.name.replace('generate_', '') })
        toolResults.push({ type: 'tool_result', tool_use_id: block.id, content: fileUrl ? `${result}\nDownload: ${fileUrl}` : result })
      }
    }

    if (d.stop_reason === 'tool_use' && toolResults.length > 0) {
      messages.push({ role: 'assistant', content: d.content })
      messages.push({ role: 'user', content: toolResults })
      continue
    }
    break
  }

  return { text: allText.join('\n'), files: allFiles }
}

// ══════════════════════════════════════════════════════════════════
// ENDPOINTS
// ══════════════════════════════════════════════════════════════════

export async function POST(req: NextRequest) {
  try {
    const { objective, workflow, dataContext, agent } = await req.json()

    // Single agent mode
    if (agent) {
      const a = AGENTS[agent]
      if (!a) return NextResponse.json({ error: 'Unknown agent: ' + agent })
      const out = await callAgent(agent, objective, dataContext || '', '')
      return NextResponse.json({ type: 'single', agent: { id: agent, ...a }, output: out.text, files: out.files })
    }

    // Swarm workflow mode
    const wf = WORKFLOWS[workflow]
    if (!wf) return NextResponse.json({ error: 'Unknown workflow', available: Object.keys(WORKFLOWS) })

    console.log('🐝 SWARM:', wf.name, '|', objective?.slice(0, 60))
    const stageResults: any[] = []
    const allSwarmFiles: { name: string; url: string; type: string }[] = []
    let allPrev = ''

    for (let i = 0; i < wf.stages.length; i++) {
      const stage = wf.stages[i]
      console.log(`  Stage ${i + 1}/${wf.stages.length}: ${stage.name} [${stage.strategy}] — ${stage.agents.join(', ')}`)
      const outs: any[] = []

      if (stage.strategy === 'parallel') {
        const ps = stage.agents.map(id =>
          callAgent(id, `[${wf.name} → ${stage.name}] ${objective}`, dataContext || '', allPrev).then(o => ({ id, ...o }))
        )
        for (const r of await Promise.all(ps)) {
          const a = AGENTS[r.id]
          outs.push({ id: r.id, name: a?.name, icon: a?.icon, color: a?.color, output: r.text, files: r.files })
          allSwarmFiles.push(...r.files)
        }
      } else {
        let chain = allPrev
        for (const id of stage.agents) {
          const o = await callAgent(id, `[${wf.name} → ${stage.name}] ${objective}`, dataContext || '', chain)
          const a = AGENTS[id]
          outs.push({ id, name: a?.name, icon: a?.icon, color: a?.color, output: o.text, files: o.files })
          allSwarmFiles.push(...o.files)
          chain += '\n\n### ' + a?.name + ':\n' + o.text
        }
      }

      const stageOut = outs.map(a => '### ' + a.name + ':\n' + a.output).join('\n\n')
      allPrev += '\n\n## STAGE: ' + stage.name + '\n' + stageOut
      stageResults.push({ stage: i + 1, name: stage.name, strategy: stage.strategy, agents: outs })
    }

    const summaryResult = await callAgent('coordinator',
      'Synthesize all outputs into 5-7 bullet executive summary. Key decisions, risks, next actions.',
      dataContext || '', allPrev)
    allSwarmFiles.push(...summaryResult.files)

    try { await supabase.from('activity_log').insert({ action: 'swarm', details: { workflow, objective: objective?.slice(0, 100), stages: stageResults.length, files: allSwarmFiles.length } }) } catch (e) {}

    return NextResponse.json({
      type: 'swarm', workflow: wf.name, topology: wf.topology, objective,
      stages: stageResults, summary: summaryResult.text,
      files: allSwarmFiles,
      totalAgents: stageResults.reduce((a, s) => a + s.agents.length, 0),
      totalStages: stageResults.length,
    })
  } catch (e: any) {
    console.log('SWARM ERR:', e.message)
    return NextResponse.json({ error: e.message })
  }
}

export async function GET() {
  return NextResponse.json({ agents: getAgentList(), workflows: getWorkflowList() })
}
