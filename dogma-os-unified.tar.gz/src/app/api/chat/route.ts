import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { getToken, getConnections, SERVICES, supabase } from '@/lib/services'
import { AGENTS } from '@/lib/agents'
import { put } from '@vercel/blob'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! })

// ══════════════════════════════════════════════════════════════════
// TOOL DEFINITIONS — every agent gets the full set
// ══════════════════════════════════════════════════════════════════

const LOCAL_TOOLS: Anthropic.Tool[] = [
  // ── Data mutation tools ──
  {
    name: 'edit_node',
    description: `Edit any node/entity in the DOGMA data graph. Supports: update a field, add a note, add a list item, remove a list item, or change status.
Collections: ss (subsystems), skills, exps (experiments), tasks, pilots, investors, incidents, fleet, safety.
Examples:
- Update field: {collection:"tasks", entity_id:"t1", action:"update_field", field:"status", value:"done"}
- Add note: {collection:"ss", entity_id:"ss1", action:"add_note", text:"Passed QC review"}
- Add list item: {collection:"ss", entity_id:"ss1", action:"add_list_item", field:"risks", value:"New risk identified"}
- Remove list item: {collection:"ss", entity_id:"ss1", action:"remove_list_item", field:"risks", index:0}
- Advance stage: {collection:"pilots", entity_id:"p1", action:"advance_stage"}`,
    input_schema: {
      type: 'object' as const,
      properties: {
        collection: { type: 'string', description: 'Data collection: ss, skills, exps, tasks, pilots, investors, incidents, fleet, safety' },
        entity_id: { type: 'string', description: 'ID of the entity to edit' },
        action: { type: 'string', enum: ['update_field', 'add_note', 'add_list_item', 'remove_list_item', 'advance_stage'] },
        field: { type: 'string', description: 'Field name to update (for update_field, add_list_item, remove_list_item)' },
        value: { type: 'string', description: 'New value (for update_field, add_list_item, add_note text)' },
        text: { type: 'string', description: 'Note text (for add_note)' },
        index: { type: 'number', description: 'Index to remove (for remove_list_item)' },
      },
      required: ['collection', 'entity_id', 'action'],
    },
  },
  {
    name: 'upload_file',
    description: 'Upload a file to storage and optionally attach it to an entity. Accepts base64-encoded file content.',
    input_schema: {
      type: 'object' as const,
      properties: {
        filename: { type: 'string', description: 'Name of the file including extension' },
        content_base64: { type: 'string', description: 'Base64-encoded file content' },
        content_type: { type: 'string', description: 'MIME type (e.g., application/pdf, image/png)' },
        attach_to_collection: { type: 'string', description: 'Optional: collection to attach file to' },
        attach_to_id: { type: 'string', description: 'Optional: entity ID to attach file to' },
      },
      required: ['filename', 'content_base64', 'content_type'],
    },
  },

  // ── Document generation tools ──
  {
    name: 'generate_csv',
    description: 'Generate a CSV spreadsheet file. Returns download URL.',
    input_schema: {
      type: 'object' as const,
      properties: {
        title: { type: 'string' },
        headers: { type: 'array', items: { type: 'string' } },
        rows: { type: 'array', items: { type: 'array', items: { type: 'string' } } },
      },
      required: ['title', 'headers', 'rows'],
    },
  },
  {
    name: 'generate_docx',
    description: 'Generate a Word document from rich HTML. Returns download URL.',
    input_schema: {
      type: 'object' as const,
      properties: {
        title: { type: 'string' },
        html: { type: 'string', description: 'Rich HTML content for the document body' },
      },
      required: ['title', 'html'],
    },
  },
  {
    name: 'generate_pdf',
    description: 'Generate a PDF document. Returns download URL.',
    input_schema: {
      type: 'object' as const,
      properties: {
        title: { type: 'string' },
        html: { type: 'string' },
      },
      required: ['title', 'html'],
    },
  },
  {
    name: 'generate_pptx',
    description: 'Generate a PowerPoint presentation. Returns download URL.',
    input_schema: {
      type: 'object' as const,
      properties: {
        title: { type: 'string' },
        slides: {
          type: 'array',
          items: {
            type: 'object',
            properties: { title: { type: 'string' }, body: { type: 'string' } },
            required: ['title', 'body'],
          },
        },
      },
      required: ['title', 'slides'],
    },
  },
  {
    name: 'generate_latex',
    description: 'Generate a LaTeX document. Returns download URL.',
    input_schema: {
      type: 'object' as const,
      properties: {
        title: { type: 'string' },
        content: { type: 'string' },
      },
      required: ['title', 'content'],
    },
  },
  {
    name: 'web_search',
    description: 'Search the web for current information. Use for research, fact-checking, market data, competitor analysis, technical docs, standards lookup.',
    input_schema: {
      type: 'object' as const,
      properties: {
        query: { type: 'string', description: 'Search query (short and specific, 1-6 words)' },
      },
      required: ['query'],
    },
  },
]

// ══════════════════════════════════════════════════════════════════
// FILE STORAGE (Vercel Blob)
// ══════════════════════════════════════════════════════════════════

async function storeFile(
  name: string, type: string, content: string | Buffer, contentType: string
): Promise<string> {
  const blob = await put(name, content, { access: 'public', contentType })
  try {
    await supabase.from('generated_files').insert({
      filename: name, filetype: type, blob_url: blob.url,
      size_bytes: typeof content === 'string' ? content.length : content.length,
      generated_by: 'agent',
    })
  } catch (e) { /* non-critical */ }
  return blob.url
}

// ══════════════════════════════════════════════════════════════════
// TOOL EXECUTION
// ══════════════════════════════════════════════════════════════════

async function execTool(
  name: string, input: any
): Promise<{ result: string; fileUrl?: string; fileName?: string; mutation?: any }> {

  // ── edit_node: unified data mutation ──
  if (name === 'edit_node') {
    const { data: row } = await supabase.from('dogma_data').select('data').eq('user_id', 'jero').single()
    if (!row) return { result: 'No data found' }
    const D = row.data
    const col = D[input.collection]
    if (!Array.isArray(col)) return { result: `Collection "${input.collection}" not found` }

    const idx = col.findIndex((x: any) => x.id === input.entity_id)
    if (idx < 0) return { result: `Entity "${input.entity_id}" not found in ${input.collection}` }

    const entity = col[idx]

    switch (input.action) {
      case 'update_field': {
        const val = isNaN(Number(input.value)) ? input.value : Number(input.value)
        entity[input.field] = val
        break
      }
      case 'add_note': {
        if (!entity.notes) entity.notes = []
        entity.notes.push({ t: input.text || input.value, by: 'Agent', at: new Date().toLocaleString() })
        break
      }
      case 'add_list_item': {
        if (!entity[input.field]) entity[input.field] = []
        if (Array.isArray(entity[input.field])) entity[input.field].push(input.value)
        break
      }
      case 'remove_list_item': {
        if (Array.isArray(entity[input.field]) && typeof input.index === 'number')
          entity[input.field].splice(input.index, 1)
        break
      }
      case 'advance_stage': {
        const stages: Record<string, string[]> = {
          pilots: ['Identified', 'Auto Score', 'Manual Score', 'Proposal Sent', 'Negotiation', 'Signed'],
          investors: ['Cold', 'Warm Intro', 'Meeting', 'DD', 'Term Sheet', 'Closed'],
          tasks: ['todo', 'progress', 'done'],
          incidents: ['open', 'investigating', 'resolved'],
        }
        const stageList = stages[input.collection]
        if (stageList) {
          const stageField = input.collection === 'pilots' ? 'stage' : 'status'
          const curIdx = stageList.indexOf(entity[stageField])
          if (curIdx >= 0 && curIdx < stageList.length - 1) entity[stageField] = stageList[curIdx + 1]
        }
        break
      }
    }

    await supabase.from('dogma_data').update({ data: D, updated_at: new Date().toISOString() }).eq('user_id', 'jero')
    return {
      result: `✏️ ${input.action} on ${input.collection}/${input.entity_id}${input.field ? '.' + input.field : ''}`,
      mutation: { collection: input.collection, entity_id: input.entity_id, action: input.action, field: input.field, value: input.value },
    }
  }

  // ── upload_file ──
  if (name === 'upload_file') {
    try {
      const buf = Buffer.from(input.content_base64, 'base64')
      const url = await storeFile(input.filename, input.content_type.split('/')[1] || 'bin', buf, input.content_type)
      if (input.attach_to_collection && input.attach_to_id) {
        const { data: row } = await supabase.from('dogma_data').select('data').eq('user_id', 'jero').single()
        if (row) {
          const D = row.data
          const col = D[input.attach_to_collection]
          if (Array.isArray(col)) {
            const entity = col.find((x: any) => x.id === input.attach_to_id)
            if (entity) {
              if (!entity.files) entity.files = []
              entity.files.push({ name: input.filename, url, at: new Date().toLocaleString() })
              await supabase.from('dogma_data').update({ data: D }).eq('user_id', 'jero')
            }
          }
        }
      }
      return { result: `File uploaded: ${input.filename}`, fileUrl: url, fileName: input.filename }
    } catch (e: any) {
      return { result: `Upload failed: ${e.message}` }
    }
  }

  // ── File generation ──
  if (name === 'generate_csv') {
    const csv = '\uFEFF' + input.headers.join(',') + '\n' +
      input.rows.map((r: string[]) => r.map((c: string) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n')
    const url = await storeFile(input.title + '.csv', 'csv', csv, 'text/csv')
    return { result: 'CSV created', fileUrl: url, fileName: input.title + '.csv' }
  }

  if (name === 'generate_docx') {
    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word">
      <head><meta charset="utf-8"><style>body{font-family:Calibri;font-size:11pt}h1{color:#C8A74B;border-bottom:2px solid #C8A74B}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:6px}th{background:#f5f5f5}</style></head>
      <body><h1>${input.title}</h1><p style="color:#999">DOGMA Robotics | ${new Date().toLocaleDateString()}</p>${input.html}</body></html>`
    const url = await storeFile(input.title.replace(/\s+/g, '_') + '.doc', 'doc', html, 'application/msword')
    return { result: 'Word doc created', fileUrl: url, fileName: input.title + '.doc' }
  }

  if (name === 'generate_pdf') {
    const html = `<!DOCTYPE html><html><head><title>${input.title}</title><style>body{font-family:Helvetica;padding:40px;max-width:700px;margin:auto}h1{color:#C8A74B;border-bottom:2px solid #C8A74B}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:5px}th{background:#f5f5f5}</style></head><body><h1>${input.title}</h1>${input.html}</body></html>`
    const url = await storeFile(input.title + '.html', 'pdf', html, 'text/html')
    return { result: 'PDF created', fileUrl: url, fileName: input.title + '.pdf' }
  }

  if (name === 'generate_pptx') {
    const slides = (input.slides || []).map((s: any, i: number) =>
      `<div style="page-break-after:always;width:960px;height:540px;padding:60px;background:${i === 0 ? '#0A0A18' : '#fff'};color:${i === 0 ? '#C8A74B' : '#1a1a2e'}"><h1>${s.title}</h1><div style="font-size:14pt">${s.body}</div></div>`
    ).join('')
    const html = `<html><head><style>@page{size:960px 540px;margin:0}body{margin:0}</style></head><body>${slides}</body></html>`
    const url = await storeFile(input.title + '.ppt', 'ppt', html, 'application/vnd.ms-powerpoint')
    return { result: 'Presentation created', fileUrl: url, fileName: input.title + '.ppt' }
  }

  if (name === 'generate_latex') {
    const tex = `\\documentclass{article}\n\\usepackage[margin=1in]{geometry}\n\\usepackage{booktabs,hyperref}\n\\title{${input.title}}\n\\author{DOGMA Robotics}\n\\date{\\today}\n\\begin{document}\n\\maketitle\n${input.content}\n\\end{document}`
    const url = await storeFile(input.title.replace(/\s/g, '_') + '.tex', 'tex', tex, 'application/x-tex')
    return { result: 'LaTeX created', fileUrl: url, fileName: input.title + '.tex' }
  }

  return { result: 'Unknown tool: ' + name }
}

// ══════════════════════════════════════════════════════════════════
// MAIN HANDLER
// ══════════════════════════════════════════════════════════════════

export async function POST(req: NextRequest) {
  const { message, agentId, dataContext } = await req.json()

  const agent = AGENTS[agentId]
  if (!agent) return NextResponse.json({ text: `Unknown agent: ${agentId}. Available: ${Object.keys(AGENTS).join(', ')}`, files: [] })

  // Build authenticated MCP servers
  const connections = await getConnections()
  const mcpServers: any[] = []
  for (const conn of connections) {
    const svc = SERVICES[conn.service]
    if (svc?.mcp_url) {
      const token = await getToken(conn.service)
      if (token) mcpServers.push({ type: 'url', url: svc.mcp_url, name: conn.service, authorization_token: token })
    }
  }

  const messages: Anthropic.MessageParam[] = [{
    role: 'user',
    content: `${agent.sys}\n\n--- COMPANY DATA ---\n${dataContext}\nDate: ${new Date().toLocaleDateString()}\n\nUser: ${message}`,
  }]

  const allText: string[] = []
  const allFiles: { name: string; url: string; type: string }[] = []
  const allMutations: any[] = []
  let loopCount = 0

  while (loopCount < 8) {
    loopCount++

    const requestParams: any = {
      model: 'claude-sonnet-4-20250514',
      max_tokens: 4096,
      messages,
      tools: LOCAL_TOOLS,
    }
    if (mcpServers.length > 0) requestParams.mcp_servers = mcpServers

    const response = await client.messages.create(requestParams)
    const toolResults: Anthropic.ToolResultBlockParam[] = []

    for (const block of response.content) {
      if (block.type === 'text') allText.push(block.text)
      if (block.type === 'tool_use') {
        if (block.name === 'web_search') continue // handled natively
        const { result, fileUrl, fileName, mutation } = await execTool(block.name, block.input)
        allText.push(`✅ ${result}`)
        if (fileUrl && fileName) allFiles.push({ name: fileName, url: fileUrl, type: block.name.replace('generate_', '') })
        if (mutation) allMutations.push(mutation)
        toolResults.push({ type: 'tool_result', tool_use_id: block.id, content: fileUrl ? `${result}\nDownload: ${fileUrl}` : result })
      }
    }

    if (response.stop_reason === 'tool_use' && toolResults.length > 0) {
      messages.push({ role: 'assistant', content: response.content })
      messages.push({ role: 'user', content: toolResults })
      continue
    }
    break
  }

  try { await supabase.from('activity_log').insert({ action: 'agent_chat', details: { agent: agentId, message, files: allFiles.length, mutations: allMutations.length }, agent_id: agentId }) } catch (e) {}

  return NextResponse.json({ text: allText.join('\n'), files: allFiles, mutations: allMutations, mcpConnected: mcpServers.map(m => m.name) })
}

export async function GET() {
  return NextResponse.json({
    agents: Object.entries(AGENTS).map(([id, a]) => ({ id, name: a.name, icon: a.icon, color: a.color, category: a.category })),
    tools: LOCAL_TOOLS.map(t => t.name),
  })
}
