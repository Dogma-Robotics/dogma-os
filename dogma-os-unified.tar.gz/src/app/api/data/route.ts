import { NextResponse } from 'next/server'
import { supabase } from '@/lib/services'

export async function GET() {
  const { data: row } = await supabase
    .from('dogma_data')
    .select('data, updated_at')
    .eq('user_id', 'jero')
    .single()

  if (!row) return NextResponse.json({ error: 'No data found' }, { status: 404 })

  return NextResponse.json({ data: row.data, updated_at: row.updated_at })
}
