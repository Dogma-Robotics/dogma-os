// ══════════════════════════════════════════════════════════════════
// DOGMA OS v2 — useOpenClaw React Hook (client-side)
//
// This hook runs IN THE BROWSER and connects directly to the
// OpenClaw gateway on the user's machine (http://localhost:18789).
//
// When gateway is available:  Browser → localhost:18789 → Claude
// When gateway is down:       Browser → Vercel API → Claude
//
// The Vercel API routes are the FALLBACK, not the primary path.
// ══════════════════════════════════════════════════════════════════
'use client'

import { useState, useEffect, useCallback, useRef } from 'react'

// ── Types ──

export interface GatewayStatus {
  connected: boolean
  version: string
  model: string
  activeSessions: number
  lastChecked: number
}

export interface ChatMessage {
  role: 'user' | 'ai'
  text: string
  files?: ChatFile[]
  toolCalls?: ToolCall[]
  model?: string
  via?: 'gateway' | 'vercel'
}

export interface ChatFile {
  name: string
  url: string
  path?: string
  type: string
}

export interface ToolCall {
  tool: string
  input: string
  output?: string
  status: 'executed' | 'pending' | 'denied'
}

export interface ChatResponse {
  text: string
  files: ChatFile[]
  toolCalls: ToolCall[]
  sessionId: string
  model: string
  via: 'gateway' | 'vercel'
}

// ── Configuration ──

const GATEWAY_URL = 'http://localhost:18789'
const GATEWAY_CHECK_INTERVAL = 15_000 // 15s
const GATEWAY_TIMEOUT = 2000 // 2s timeout for health checks

// ── Hook ──

export function useOpenClaw() {
  const [gateway, setGateway] = useState<GatewayStatus>({
    connected: false, version: '', model: '', activeSessions: 0, lastChecked: 0,
  })
  const [toolLog, setToolLog] = useState<ToolCall[]>([])
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const abortRef = useRef<AbortController | null>(null)

  // ── Gateway health check ──
  const checkGateway = useCallback(async () => {
    try {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), GATEWAY_TIMEOUT)

      const res = await fetch(`${GATEWAY_URL}/api/status`, {
        signal: controller.signal,
        mode: 'cors',
      })
      clearTimeout(timer)

      if (res.ok) {
        const data = await res.json()
        setGateway({
          connected: true,
          version: data.version || 'unknown',
          model: data.model || 'claude-sonnet-4-20250514',
          activeSessions: data.sessions?.active || 0,
          lastChecked: Date.now(),
        })
        return true
      }
    } catch {
      // Gateway unreachable — that's fine, we fall back to Vercel
    }
    setGateway(prev => ({
      ...prev,
      connected: false,
      lastChecked: Date.now(),
    }))
    return false
  }, [])

  // Check on mount + interval
  useEffect(() => {
    checkGateway()
    const iv = setInterval(checkGateway, GATEWAY_CHECK_INTERVAL)
    return () => clearInterval(iv)
  }, [checkGateway])

  // ── Send message ──
  const sendMessage = useCallback(async (
    agentId: string,
    message: string,
    options: {
      dataContext?: string
      mode?: 'advisory' | 'execute'
    } = {}
  ): Promise<ChatResponse> => {
    setLoading(true)

    try {
      // Try local gateway first
      if (gateway.connected) {
        try {
          const result = await sendViaGateway(agentId, message, sessionId, options)
          if (result.sessionId) setSessionId(result.sessionId)
          if (result.toolCalls.length > 0) {
            setToolLog(prev => [...result.toolCalls, ...prev].slice(0, 100))
          }
          setLoading(false)
          return result
        } catch (e) {
          console.warn('[OpenClaw] Gateway call failed, falling back to Vercel:', e)
          // Mark gateway as potentially down, will recheck on next interval
          setGateway(prev => ({ ...prev, connected: false }))
        }
      }

      // Fallback: Vercel API route (no computer access)
      const result = await sendViaVercel(agentId, message, options)
      setLoading(false)
      return result
    } catch (e: any) {
      setLoading(false)
      return {
        text: `Error: ${e.message}`,
        files: [],
        toolCalls: [],
        sessionId: sessionId || '',
        model: 'error',
        via: 'vercel',
      }
    }
  }, [gateway.connected, sessionId])

  // ── Cancel ongoing request ──
  const cancel = useCallback(() => {
    abortRef.current?.abort()
    setLoading(false)
  }, [])

  // ── Clear session ──
  const clearSession = useCallback(() => {
    setSessionId(null)
    setToolLog([])
  }, [])

  return {
    gateway,
    toolLog,
    sessionId,
    loading,
    sendMessage,
    cancel,
    clearSession,
    checkGateway,
  }
}

// ══════════════════════════════════════════════════════════════════
// PATH A: Send via local OpenClaw Gateway (full computer access)
// ══════════════════════════════════════════════════════════════════

async function sendViaGateway(
  agentId: string,
  message: string,
  sessionId: string | null,
  options: { dataContext?: string; mode?: string }
): Promise<ChatResponse> {
  const payload: Record<string, any> = {
    agent: agentId,
    message,
    model: 'claude-sonnet-4-20250514',
    max_tokens: 8192,
  }

  if (sessionId) payload.session = sessionId
  if (options.dataContext) payload.context = options.dataContext
  if (options.mode === 'advisory') payload.tool_policy = 'ask'

  const res = await fetch(`${GATEWAY_URL}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    mode: 'cors',
  })

  if (!res.ok) {
    throw new Error(`Gateway error: ${res.status}`)
  }

  const data = await res.json()

  return {
    text: extractText(data),
    files: extractFiles(data),
    toolCalls: extractToolCalls(data),
    sessionId: data.session_id || sessionId || '',
    model: data.model || 'claude-sonnet-4-20250514',
    via: 'gateway',
  }
}

// ══════════════════════════════════════════════════════════════════
// PATH B: Send via Vercel API route (text-only fallback)
// ══════════════════════════════════════════════════════════════════

async function sendViaVercel(
  agentId: string,
  message: string,
  options: { dataContext?: string; mode?: string }
): Promise<ChatResponse> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message,
      agentId,
      dataContext: options.dataContext,
      mode: options.mode || 'advisory',
    }),
  })

  if (!res.ok) {
    const err = await res.text().catch(() => 'Unknown error')
    throw new Error(`Vercel API error: ${err.slice(0, 200)}`)
  }

  const data = await res.json()

  return {
    text: data.text || '(no response)',
    files: (data.files || []).map((f: any) => ({
      name: f.name, url: f.url, type: f.type || 'file',
    })),
    toolCalls: (data.toolCalls || []).map((tc: any) => ({
      tool: tc.tool, input: tc.input, output: tc.output, status: tc.status || 'executed',
    })),
    sessionId: data.sessionId || '',
    model: data.gateway?.model || data.model || 'unknown',
    via: 'vercel' as const,
  }
}

// ── Helpers ──

function extractText(data: any): string {
  if (typeof data.text === 'string') return data.text
  if (typeof data.reply === 'string') return data.reply
  if (Array.isArray(data.content)) {
    return data.content
      .filter((b: any) => b.type === 'text')
      .map((b: any) => b.text)
      .join('\n')
  }
  return data.message || ''
}

function extractFiles(data: any): ChatFile[] {
  if (!Array.isArray(data.files)) return []
  return data.files.map((f: any) => ({
    name: f.name || 'file',
    url: f.url || f.path || '',
    path: f.path,
    type: f.mime || f.type || 'file',
  }))
}

function extractToolCalls(data: any): ToolCall[] {
  const calls: ToolCall[] = []
  if (Array.isArray(data.tool_calls)) {
    for (const tc of data.tool_calls) {
      calls.push({
        tool: tc.tool || tc.name || 'unknown',
        input: typeof tc.input === 'string' ? tc.input : JSON.stringify(tc.input || {}).slice(0, 120),
        output: typeof tc.output === 'string' ? tc.output.slice(0, 200) : undefined,
        status: tc.status || 'executed',
      })
    }
  }
  return calls
}
