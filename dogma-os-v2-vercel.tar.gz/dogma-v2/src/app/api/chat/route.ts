// ══════════════════════════════════════════════════════════════════
// DOGMA OS v2 — Chat Route (Vercel Deployment)
//
// ON VERCEL: This is the FALLBACK path. No computer access.
//   Browser tries localhost:18789 first (via useOpenClaw hook).
//   If gateway is down, browser falls back here → direct Claude API.
//
// This route handles: auth, domain context from Supabase, Claude API call.
// It does NOT proxy to OpenClaw (can't reach localhost from Vercel).
// ══════════════════════════════════════════════════════════════════

import { NextRequest, NextResponse } from 'next/server'
import { resolveSession, canUseAgent, getAgentTier, logActivity } from '@/lib/auth'
import { AGENTS } from '@/lib/agents'
import { getSupabase } from '@/lib/auth'

const API_KEY = process.env.ANTHROPIC_API_KEY || ''

export async function POST(req: NextRequest) {
  try {
    const auth = await resolveSession()
    if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status })
    const ctx = auth.ctx

    const { message, agentId = 'coder', dataContext } = await req.json()
    if (!message) return NextResponse.json({ error: 'Missing message' }, { status: 400 })

    const agent = AGENTS[agentId]
    if (!agent) return NextResponse.json({ text: `Unknown agent: ${agentId}`, files: [], toolCalls: [] })
    if (!canUseAgent(ctx, agentId)) {
      return NextResponse.json({ text: `Permission denied: ${ctx.role} cannot use ${agent.name}`, files: [], toolCalls: [] })
    }

    const domainContext = dataContext || await buildDomainContext(ctx.organizationId)

    // System prompt for cloud fallback mode (no computer access)
    const systemPrompt = [
      agent.soulPrompt,
      '\nYou are in CLOUD FALLBACK mode — no OpenClaw gateway detected.',
      'You do NOT have computer access (no shell, no browser, no file ops).',
      'You can reason, plan, analyze, and write code for the user to run.',
      'If they need execution, tell them: start OpenClaw gateway locally.',
      domainContext ? `\n--- DOGMA CONTEXT ---\n${domainContext}` : '',
    ].join('\n')

    if (!API_KEY) {
      return NextResponse.json({
        text: 'No ANTHROPIC_API_KEY set. Add it in Vercel → Settings → Environment Variables.',
        files: [], toolCalls: [], gateway: { connected: false, mode: 'cloud-fallback' },
      })
    }

    const startTime = Date.now()
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 4096,
        system: systemPrompt,
        messages: [{ role: 'user', content: `User: ${ctx.name} (${ctx.role})\nDate: ${new Date().toLocaleDateString()}\n\n${message}` }],
        tools: [{ type: 'web_search_20250305', name: 'web_search' }],
      }),
    })

    if (!res.ok) {
      const err = await res.text().catch(() => 'unknown')
      return NextResponse.json({ text: `Claude API error (${res.status}): ${err.slice(0, 300)}`, files: [], toolCalls: [] })
    }

    const data = await res.json()
    const text = (data.content || []).filter((b: any) => b.type === 'text').map((b: any) => b.text).join('\n') || '(no response)'

    await logActivity(ctx, 'agent_chat', 'agent', agentId, {
      agent: agentId, tier: getAgentTier(agentId), message: message.slice(0, 100),
      duration_ms: Date.now() - startTime, mode: 'cloud-fallback', model: data.model,
    })

    return NextResponse.json({
      text, files: [], toolCalls: [],
      model: data.model || 'claude-sonnet-4-20250514',
      gateway: { connected: false, mode: 'cloud-fallback' },
      agent: { id: agentId, name: agent.name, icon: agent.icon, tier: getAgentTier(agentId) },
      user: { name: ctx.name, role: ctx.role },
    })
  } catch (e: any) {
    return NextResponse.json({ text: `Error: ${e.message}`, files: [], toolCalls: [] })
  }
}

export async function GET() {
  const auth = await resolveSession()
  if (!auth.ok) return NextResponse.json({ error: auth.error })
  const ctx = auth.ctx
  const agents = Object.entries(AGENTS).map(([id, a]) => ({
    id, name: a.name, icon: a.icon, color: a.color, category: a.category,
    description: a.description, tier: getAgentTier(id), canUse: canUseAgent(ctx, id),
    computerAccess: a.computerAccess,
  }))
  return NextResponse.json({ agents, gateway: { connected: false, mode: 'cloud-fallback' }, user: { name: ctx.name, role: ctx.role } })
}

async function buildDomainContext(orgId: string): Promise<string> {
  const sb = getSupabase()
  if (!sb) return ''
  try {
    const [{ data: ss }, { data: tasks }, { data: pilots }, { data: fin }] = await Promise.all([
      sb.from('subsystems').select('name, maturity_level, status').eq('organization_id', orgId),
      sb.from('tasks').select('title, status, priority').eq('organization_id', orgId).neq('status', 'done').limit(15),
      sb.from('pilots').select('company_name, stage, viability_score').eq('organization_id', orgId).limit(5),
      sb.from('finance_snapshots').select('burn_rate, cash_on_hand, runway_months').eq('organization_id', orgId).order('month', { ascending: false }).limit(1),
    ])
    const p = ['DOGMA Robotics — Current State']
    if (ss?.length) p.push('Subsystems: ' + ss.map(s => `${s.name}(${s.maturity_level}%)`).join(', '))
    if (tasks?.length) p.push('Tasks: ' + tasks.map(t => `[${t.priority}] ${t.title}`).join(', '))
    if (pilots?.length) p.push('Pilots: ' + pilots.map(x => `${x.company_name}(${x.stage})`).join(', '))
    if (fin?.[0]) p.push(`Finance: Burn $${fin[0].burn_rate}/mo, Runway ${fin[0].runway_months}mo`)
    return p.join('\n')
  } catch { return '' }
}
